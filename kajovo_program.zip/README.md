# Kájovo — Kája (desktop orchestrátor pro OpenAI Responses)

Tento projekt implementuje desktop aplikaci **Kája** pro Windows 10/11 (PySide6), která umí:
- Generovat projekt do OUT (A: GENERATE)
- Upravit existující projekt (B: MODIFY) s volitelným `file_search` (vector store), fallback bez tools
- Spouštět QA dotazy (QA)
- Spustit dávkový režim (C: SEND AS C / Batch API)
- Ukládat logy per-run do `LOG/RUN_.../` + evidenci nákladů do SQLite (receipts)

## Rychlý start (Windows)
1) Instalace:
- `scripts\install.bat` (nebo `scripts\install.ps1`)
2) Nastav API klíč:
- v aplikaci tlačítko **API-KEY** (uloží `OPENAI_API_KEY` do user env proměnné a do aktuálního běhu)
3) Spuštění:
- `scripts\run.bat` (nebo `scripts\run.ps1`)

## Běžné použití
- **MODE = GENERATE**: vyplň prompt, nastav OUT. IN je volitelný. Aplikace vygeneruje soubory do OUT.
- **MODE = MODIFY**: vyplň prompt, nastav IN i OUT. (IN = OUT je podporováno.) Aplikace udělá *IN mirror* (scan+upload), pak vytvoří plán a přepíše/ vytvoří soubory v OUT.
- **MODE = QA**: pouze odešle prompt (volitelně s attached files) a vrátí text.
- **SEND AS C (BATCH)**: vygeneruje 1 požadavek do JSONL, vytvoří batch, polling, stáhne výstup JSONL, uloží výsledné soubory do OUT.

## Files API panel
Záložka **FILES API** umožní:
- Refresh files (list)
- Upload lokální soubor do Files API
- Delete file
- Attach file_id do běhu (přidá se do requestu jako `input_file`)

## Diagnostika (IN / OUT)
- **Windows IN**: spustí `diagnostics/windows_collect.ps1`, uloží výstup do `LOG/<RUN>/manifests/diagnostics/*` a best-effort upload do Files API.
- **SSH IN**: připojí se přes Paramiko, vytvoří `/root/Diag_<timestamp>`, stáhne `diag.tar.gz`.
- **Diagnostics OUT**: po dokončení běhu aplikace zkontroluje v OUT přítomnost `readmerepair.txt` a známých repair skriptů a nabídne jejich spuštění (log ukládá do `_repair_exec_log.txt`).

## VERSING snapshot
Pokud je zapnutý **VERSING**, před první změnou v OUT se vytvoří snapshot složka:
`<OUT_BASENAME><DDMMYYYYHHMM>` (např. `MyProj090120261030`)

## Logování
Každý RUN má složku: `LOG/RUN_DDMMYYYYHHMM_XXXX/`:
- `events.jsonl` (události)
- `run_state.json`
- `requests/*.json`, `responses/*.json`, `manifests/*.json`

## Náklady (Pricing / Receipts)
- Aplikace ukládá token usage z response do `kajovo.sqlite` (tabulka `receipts`).
- Cena se počítá z cache tabulky v `cache/price_table.json` (pokud existuje) nebo z builtin fallback.

## Poznámky
- Pokud není dostupný `file_search` / vector store v daném prostředí, MODIFY jede bez tools (pouze s přiloženými file_id).
- Program je navržen tak, aby byl robustní: retry + circuit breaker, logování request/response.

