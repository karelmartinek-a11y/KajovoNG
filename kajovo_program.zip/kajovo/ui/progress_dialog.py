from __future__ import annotations

import time
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit, QProgressBar
from PySide6.QtCore import Qt

class ProgressDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("RUN")
        self.setModal(False)
        self.resize(720, 520)
        self._start = time.time()

        v = QVBoxLayout(self)

        self.lbl = QLabel("Running...")
        v.addWidget(self.lbl)

        self.pb = QProgressBar()
        self.pb_sub = QProgressBar()
        v.addWidget(self.pb)
        v.addWidget(self.pb_sub)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        v.addWidget(self.log, 1)

        row = QHBoxLayout()
        self.btn_stop = QPushButton("STOP")
        self.btn_close = QPushButton("Hide")
        row.addWidget(self.btn_stop)
        row.addStretch(1)
        row.addWidget(self.btn_close)
        v.addLayout(row)

        self.btn_close.clicked.connect(self.hide)

    def set_progress(self, p: int):
        self.pb.setValue(p)
        self._update_eta()

    def set_subprogress(self, p: int):
        self.pb_sub.setValue(p)

    def set_status(self, s: str):
        self.lbl.setText(s)
        self._update_eta()

    def add_log(self, line: str):
        self.log.appendPlainText(line)

    def _update_eta(self):
        p = self.pb.value()
        if p <= 1:
            return
        elapsed = time.time() - self._start
        total = elapsed * (100.0 / p)
        eta = max(0.0, total - elapsed)
        self.setWindowTitle(f"RUN — ETA {int(eta)}s")
