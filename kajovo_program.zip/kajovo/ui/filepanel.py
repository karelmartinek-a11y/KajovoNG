from __future__ import annotations

import os
from typing import List
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QFileDialog, QMessageBox
from PySide6.QtCore import Signal

from ..core.openai_client import OpenAIClient
from ..core.retry import with_retry, CircuitBreaker

class FilesPanel(QWidget):
    attached_changed = Signal(list)  # list[str]
    logline = Signal(str)

    def __init__(self, settings, api_key: str, parent=None):
        super().__init__(parent)
        self.s = settings
        self.api_key = api_key
        self.client = OpenAIClient(api_key) if api_key else None
        self.breaker = CircuitBreaker(settings.retry.circuit_breaker_failures, settings.retry.circuit_breaker_cooldown_s)

        v = QVBoxLayout(self)

        top = QHBoxLayout()
        top.addWidget(QLabel("Files API"))
        top.addStretch(1)
        self.btn_refresh = QPushButton("Refresh")
        self.btn_upload = QPushButton("Upload")
        self.btn_delete = QPushButton("Delete")
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_upload)
        top.addWidget(self.btn_delete)
        v.addLayout(top)

        lists = QHBoxLayout()
        self.lst_files = QListWidget()
        self.lst_files.setSelectionMode(QListWidget.MultiSelection)
        self.lst_attached = QListWidget()
        self.lst_attached.setSelectionMode(QListWidget.MultiSelection)
        lists.addWidget(self._wrap("Files", self.lst_files))
        lists.addWidget(self._wrap("Attached to request", self.lst_attached))
        v.addLayout(lists, 1)

        btns = QHBoxLayout()
        self.btn_attach = QPushButton("Attach →")
        self.btn_detach = QPushButton("← Detach")
        btns.addStretch(1)
        btns.addWidget(self.btn_attach)
        btns.addWidget(self.btn_detach)
        v.addLayout(btns)

        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_upload.clicked.connect(self.upload)
        self.btn_delete.clicked.connect(self.delete_selected)
        self.btn_attach.clicked.connect(self.attach_selected)
        self.btn_detach.clicked.connect(self.detach_selected)

        self.refresh()

    def _wrap(self, title: str, widget: QWidget) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0,0,0,0)
        v.addWidget(QLabel(title))
        v.addWidget(widget, 1)
        return w

    def set_api_key(self, api_key: str):
        self.api_key = api_key
        self.client = OpenAIClient(api_key) if api_key else None

    def _need_client(self) -> bool:
        if not self.api_key:
            QMessageBox.warning(self, "Files", "Chybí OPENAI_API_KEY.")
            return False
        if self.client is None:
            self.client = OpenAIClient(self.api_key)
        return True

    def refresh(self):
        if not self._need_client():
            return
        try:
            files = with_retry(lambda: self.client.list_files(), self.s.retry, self.breaker)
        except Exception as e:
            QMessageBox.critical(self, "Files", str(e))
            return

        self.lst_files.clear()
        for f in files:
            fid = f.get("id","")
            name = f.get("filename","")
            item = QListWidgetItem(f"{fid}  |  {name}")
            item.setData(32, fid)
            self.lst_files.addItem(item)

    def upload(self):
        if not self._need_client():
            return
        fp, _ = QFileDialog.getOpenFileName(self, "Upload file", "", "All (*.*)")
        if not fp:
            return
        try:
            up = with_retry(lambda: self.client.upload_file(fp, purpose="user_data"), self.s.retry, self.breaker)
            self.logline.emit(f"Uploaded {os.path.basename(fp)} -> {up.get('id')}")
            self.refresh()
        except Exception as e:
            QMessageBox.critical(self, "Upload", str(e))

    def delete_selected(self):
        if not self._need_client():
            return
        sel = self.lst_files.selectedItems()
        if not sel:
            return
        if QMessageBox.question(self, "Delete", "Smazat vybrané soubory z OpenAI Files?") != QMessageBox.Yes:
            return
        for it in sel:
            fid = it.data(32)
            try:
                with_retry(lambda f=fid: self.client.delete_file(f), self.s.retry, self.breaker)
                self.logline.emit(f"Deleted file {fid}")
            except Exception as e:
                self.logline.emit(f"Delete failed {fid}: {e}")
        self.refresh()

    def attach_selected(self):
        sel = self.lst_files.selectedItems()
        for it in sel:
            fid = it.data(32)
            if not fid:
                continue
            if not any(self.lst_attached.item(i).data(32)==fid for i in range(self.lst_attached.count())):
                ni = QListWidgetItem(f"{fid}")
                ni.setData(32, fid)
                self.lst_attached.addItem(ni)
        self._emit_attached()

    def detach_selected(self):
        for it in self.lst_attached.selectedItems():
            row = self.lst_attached.row(it)
            self.lst_attached.takeItem(row)
        self._emit_attached()

    def attached_ids(self) -> List[str]:
        out = []
        for i in range(self.lst_attached.count()):
            out.append(self.lst_attached.item(i).data(32))
        return out

    def _emit_attached(self):
        self.attached_changed.emit(self.attached_ids())
