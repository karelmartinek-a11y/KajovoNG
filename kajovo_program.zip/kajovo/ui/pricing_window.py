from __future__ import annotations

import os, json, time
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox
from PySide6.QtCore import Qt

from ..core.pricing import PriceTable
from ..core.receipt import ReceiptDB

class PricingWindow(QWidget):
    def __init__(self, settings, price_table: PriceTable, receipt_db: ReceiptDB, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pricing ($)")
        self.resize(980, 720)
        self.s = settings
        self.pt = price_table
        self.db = receipt_db

        v = QVBoxLayout(self)

        top = QHBoxLayout()
        self.lbl_status = QLabel("")
        self.btn_refresh = QPushButton("Refresh pricing")
        self.btn_reload_receipts = QPushButton("Reload receipts")
        self.btn_export = QPushButton("Export receipts JSON")
        self.btn_delete = QPushButton("Delete selected receipts")
        top.addWidget(self.lbl_status)
        top.addStretch(1)
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_reload_receipts)
        top.addWidget(self.btn_export)
        top.addWidget(self.btn_delete)
        v.addLayout(top)

        self.tbl_prices = QTableWidget(0, 6)
        self.tbl_prices.setHorizontalHeaderLabels(["Model","Input/1k","Output/1k","Batch In/1k","Batch Out/1k","Verified"])
        v.addWidget(QLabel("Price table"))
        v.addWidget(self.tbl_prices, 1)

        self.tbl_receipts = QTableWidget(0, 10)
        self.tbl_receipts.setHorizontalHeaderLabels(["ID","Created","Project","Model","Mode","Flow","InTok","OutTok","Total($)","Verified"])
        self.tbl_receipts.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl_receipts.setSelectionMode(QTableWidget.MultiSelection)
        v.addWidget(QLabel("Receipts (last 1000)"))
        v.addWidget(self.tbl_receipts, 2)

        self.btn_refresh.clicked.connect(self.on_refresh)
        self.btn_reload_receipts.clicked.connect(self.load_receipts)
        self.btn_export.clicked.connect(self.on_export)
        self.btn_delete.clicked.connect(self.on_delete)

        self.load_prices()
        self.load_receipts()

    def _set_status(self):
        ver = "VERIFIED" if self.pt.verified else "UNVERIFIED"
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.pt.last_updated or 0)) if self.pt.last_updated else "n/a"
        self.lbl_status.setText(f"Pricing: {ver} | updated: {ts}")

    def load_prices(self):
        self._set_status()
        rows = list(self.pt.rows.values())
        rows.sort(key=lambda r: r.model)
        self.tbl_prices.setRowCount(len(rows))
        for i, r in enumerate(rows):
            def item(x): 
                it = QTableWidgetItem(str(x))
                it.setFlags(it.flags() ^ Qt.ItemIsEditable)
                return it
            self.tbl_prices.setItem(i,0,item(r.model))
            self.tbl_prices.setItem(i,1,item(r.input_per_1k))
            self.tbl_prices.setItem(i,2,item(r.output_per_1k))
            self.tbl_prices.setItem(i,3,item("" if r.batch_input_per_1k is None else r.batch_input_per_1k))
            self.tbl_prices.setItem(i,4,item("" if r.batch_output_per_1k is None else r.batch_output_per_1k))
            self.tbl_prices.setItem(i,5,item("1" if self.pt.verified else "0"))
        self.tbl_prices.resizeColumnsToContents()

    def load_receipts(self):
        rows = self.db.query()
        self.tbl_receipts.setRowCount(len(rows))
        for i, r in enumerate(rows):
            def item(x):
                it = QTableWidgetItem(str(x))
                it.setFlags(it.flags() ^ Qt.ItemIsEditable)
                return it
            self.tbl_receipts.setItem(i,0,item(r["id"]))
            self.tbl_receipts.setItem(i,1,item(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r["created_at"]))))
            self.tbl_receipts.setItem(i,2,item(r.get("project","")))
            self.tbl_receipts.setItem(i,3,item(r.get("model","")))
            self.tbl_receipts.setItem(i,4,item(r.get("mode","")))
            self.tbl_receipts.setItem(i,5,item(r.get("flow_type","")))
            self.tbl_receipts.setItem(i,6,item(r.get("input_tokens",0)))
            self.tbl_receipts.setItem(i,7,item(r.get("output_tokens",0)))
            self.tbl_receipts.setItem(i,8,item(r.get("total_cost",0.0)))
            self.tbl_receipts.setItem(i,9,item(r.get("pricing_verified",0)))
        self.tbl_receipts.resizeColumnsToContents()

    def on_refresh(self):
        ok, msg = self.pt.refresh_from_url(self.s.pricing.source_url)
        if not ok:
            QMessageBox.warning(self, "Pricing", f"Refresh failed: {msg}\nPoužije se cache nebo builtin fallback.")
        self.load_prices()

    def on_export(self):
        rows = self.db.query()
        data = self.db.export_rows(rows)
        fp, _ = QFileDialog.getSaveFileName(self, "Export receipts", "receipts.json", "JSON (*.json)")
        if not fp:
            return
        with open(fp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        QMessageBox.information(self, "Export", f"Uloženo: {fp}")

    def on_delete(self):
        sel = self.tbl_receipts.selectionModel().selectedRows()
        ids = []
        for idx in sel:
            try:
                rid = int(self.tbl_receipts.item(idx.row(), 0).text())
                ids.append(rid)
            except Exception:
                pass
        if not ids:
            QMessageBox.information(self, "Delete", "Nic nevybráno.")
            return
        self.db.delete_ids(ids)
        self.load_receipts()
