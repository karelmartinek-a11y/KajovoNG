from __future__ import annotations

import os, sys, time, subprocess, json
from typing import Optional, List

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton,
    QPlainTextEdit, QComboBox, QCheckBox, QFileDialog, QMessageBox, QTabWidget, QGroupBox, QProgressBar
)
from PySide6.QtCore import Qt

from ..core.config import AppSettings
from ..core.utils import new_run_id, ensure_dir
from ..core.runlog import RunLogger, find_last_incomplete_run
from ..core.pipeline import UiRunConfig, RunWorker
from ..core.receipt import ReceiptDB
from ..core.pricing import PriceTable
from ..core.openai_client import OpenAIClient
from ..core.retry import with_retry, CircuitBreaker

from .theme import DARK_STYLESHEET
from .widgets import TitleBar
from .apikey_dialog import ApiKeyDialog
from .settings_dialog import SettingsDialog
from .pricing_window import PricingWindow
from .batch_window import BatchMonitorWindow
from .filepanel import FilesPanel
from .progress_dialog import ProgressDialog

EXPECTED_REPAIR_README = "readmerepair.txt"

class MainWindow(QMainWindow):
    def __init__(self, settings: AppSettings):
        super().__init__()
        self.setWindowTitle("Kája")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.resize(1280, 820)

        self.s = settings
        self.api_key = os.environ.get("OPENAI_API_KEY","")
        self.breaker = CircuitBreaker(self.s.retry.circuit_breaker_failures, self.s.retry.circuit_breaker_cooldown_s)

        ensure_dir(self.s.log_dir)
        ensure_dir(self.s.cache_dir)

        self.db = ReceiptDB(self.s.db_path)
        self.price_table = PriceTable(os.path.join(self.s.cache_dir, "price_table.json"))
        self.price_table.load_cache()
        if getattr(self.s.pricing, "auto_refresh_on_start", True) and self.api_key and self.s.pricing.source_url:
            # best-effort refresh (non-blocking would be ideal; keep it simple)
            try:
                self.price_table.refresh_from_url(self.s.pricing.source_url)
            except Exception:
                pass
        if not self.price_table.rows:
            self.price_table = PriceTable.builtin_fallback()

        self.worker: Optional[RunWorker] = None
        self.progress_dialog: Optional[ProgressDialog] = None
        self.run_logger: Optional[RunLogger] = None

        root = QWidget()
        root.setStyleSheet(DARK_STYLESHEET)
        v = QVBoxLayout(root)
        v.setContentsMargins(10,10,10,10)
        v.setSpacing(8)

        self.titlebar = TitleBar("Kája")
        self.titlebar.request_close.connect(self.close)
        self.titlebar.request_minimize.connect(self.showMinimized)
        v.addWidget(self.titlebar)

        self.tabs = QTabWidget()
        v.addWidget(self.tabs, 1)

        self.tab_run = QWidget()
        self.tab_files = QWidget()
        self.tab_help = QWidget()
        self.tabs.addTab(self.tab_run, "RUN")
        self.tabs.addTab(self.tab_files, "FILES API")
        self.tabs.addTab(self.tab_help, "HELP")

        self._build_run_tab()
        self._build_files_tab()
        self._build_help_tab()

        self.setCentralWidget(root)

        self._maybe_resume_hint()
        self._refresh_models_best_effort()

    # ---------- build tabs ----------
    def _build_run_tab(self):
        w = self.tab_run
        outer = QVBoxLayout(w)
        outer.setContentsMargins(10,10,10,10)
        outer.setSpacing(10)

        # top controls
        top = QGridLayout()
        row = 0

        top.addWidget(QLabel("Project"), row, 0)
        self.ed_project = QLineEdit()
        self.ed_project.setPlaceholderText("Název projektu (log + účtenky)")
        top.addWidget(self.ed_project, row, 1, 1, 3)

        row += 1
        top.addWidget(QLabel("Mode"), row, 0)
        self.cb_mode = QComboBox()
        self.cb_mode.addItems(["GENERATE","MODIFY","QA"])
        top.addWidget(self.cb_mode, row, 1)

        self.chk_send_as_c = QCheckBox("SEND AS C (BATCH)")
        top.addWidget(self.chk_send_as_c, row, 2)

        top.addWidget(QLabel("Previous response_id"), row, 3)
        self.ed_response_id = QLineEdit()
        self.ed_response_id.setPlaceholderText("Volitelné: navázat na existující response")
        top.addWidget(self.ed_response_id, row, 4)

        row += 1
        top.addWidget(QLabel("Model"), row, 0)
        self.cb_model = QComboBox()
        top.addWidget(self.cb_model, row, 1)
        self.btn_models = QPushButton("Refresh models")
        top.addWidget(self.btn_models, row, 2)
        self.btn_models.clicked.connect(self._refresh_models_best_effort)

        self.btn_apikey = QPushButton("API-KEY")
        top.addWidget(self.btn_apikey, row, 3)
        self.btn_apikey.clicked.connect(self.on_apikey)

        self.btn_settings = QPushButton("SETTINGS")
        top.addWidget(self.btn_settings, row, 4)
        self.btn_settings.clicked.connect(self.on_settings)

        outer.addLayout(top)

        # prompt + dirs
        mid = QHBoxLayout()

        left = QVBoxLayout()
        left.addWidget(QLabel("Prompt"))
        self.txt_prompt = QPlainTextEdit()
        self.txt_prompt.setPlaceholderText("Sem vlož zadání / prompt.")
        left.addWidget(self.txt_prompt, 2)

        g_dirs = QGroupBox("IN/OUT")
        gd = QGridLayout(g_dirs)
        gd.addWidget(QLabel("IN (root)"), 0, 0)
        self.ed_in = QLineEdit()
        gd.addWidget(self.ed_in, 0, 1)
        self.btn_in = QPushButton("Browse")
        gd.addWidget(self.btn_in, 0, 2)
        self.btn_in.clicked.connect(lambda: self._browse_dir(self.ed_in))

        gd.addWidget(QLabel("OUT (root)"), 1, 0)
        self.ed_out = QLineEdit()
        gd.addWidget(self.ed_out, 1, 1)
        self.btn_out = QPushButton("Browse")
        gd.addWidget(self.btn_out, 1, 2)
        self.btn_out.clicked.connect(lambda: self._browse_dir(self.ed_out))

        self.chk_in_eq_out = QCheckBox("IN = OUT")
        self.chk_versing = QCheckBox("VERSING snapshot (before first write)")
        self.chk_in_eq_out.stateChanged.connect(self.on_in_eq_out_changed)
        self.chk_versing.setChecked(True)

        gd.addWidget(self.chk_in_eq_out, 2, 1)
        gd.addWidget(self.chk_versing, 2, 2)

        left.addWidget(g_dirs)

        # run controls
        runrow = QHBoxLayout()
        self.btn_go = QPushButton("KÁJO GO'")
        self.btn_go.setObjectName("PrimaryButton")
        self.btn_stop = QPushButton("STOP")
        self.btn_price = QPushButton("$")
        self.btn_batch = QPushButton("Batch monitor")
        runrow.addWidget(self.btn_go)
        runrow.addWidget(self.btn_stop)
        runrow.addStretch(1)
        runrow.addWidget(self.btn_price)
        runrow.addWidget(self.btn_batch)
        left.addLayout(runrow)

        self.btn_go.clicked.connect(self.on_go)
        self.btn_stop.clicked.connect(self.on_stop)
        self.btn_price.clicked.connect(self.on_pricing)
        self.btn_batch.clicked.connect(self.on_batch_monitor)

        self.pb = QProgressBar()
        self.pb_sub = QProgressBar()
        left.addWidget(self.pb)
        left.addWidget(self.pb_sub)

        mid.addLayout(left, 2)

        # right: diagnostics + log
        right = QVBoxLayout()

        g_diag = QGroupBox("Diagnostics")
        dg = QGridLayout(g_diag)

        self.chk_diag_win_in = QCheckBox("Windows IN (collect)")
        self.chk_diag_win_out = QCheckBox("Windows OUT (execute repair script if present)")
        self.chk_diag_ssh_in = QCheckBox("SSH IN (collect)")
        self.chk_diag_ssh_out = QCheckBox("SSH OUT (execute repair script if present)")

        dg.addWidget(self.chk_diag_win_in, 0, 0, 1, 2)
        dg.addWidget(self.chk_diag_win_out, 1, 0, 1, 2)
        dg.addWidget(self.chk_diag_ssh_in, 2, 0, 1, 2)
        dg.addWidget(self.chk_diag_ssh_out, 3, 0, 1, 2)

        dg.addWidget(QLabel("SSH user"), 4, 0)
        self.ed_ssh_user = QLineEdit()
        self.ed_ssh_user.setPlaceholderText("root")
        dg.addWidget(self.ed_ssh_user, 4, 1)

        dg.addWidget(QLabel("SSH host"), 5, 0)
        self.ed_ssh_host = QLineEdit()
        self.ed_ssh_host.setPlaceholderText("10.0.0.1")
        dg.addWidget(self.ed_ssh_host, 5, 1)

        dg.addWidget(QLabel("SSH key"), 6, 0)
        self.ed_ssh_key = QLineEdit()
        dg.addWidget(self.ed_ssh_key, 6, 1)
        self.btn_ssh_key = QPushButton("Browse")
        dg.addWidget(self.btn_ssh_key, 6, 2)
        self.btn_ssh_key.clicked.connect(lambda: self._browse_file(self.ed_ssh_key))

        dg.addWidget(QLabel("SSH key password"), 7, 0)
        self.ed_ssh_pwd = QLineEdit()
        self.ed_ssh_pwd.setEchoMode(QLineEdit.Password)
        dg.addWidget(self.ed_ssh_pwd, 7, 1)

        right.addWidget(g_diag)

        right.addWidget(QLabel("Log"))
        self.txt_log = QPlainTextEdit()
        self.txt_log.setReadOnly(True)
        right.addWidget(self.txt_log, 1)

        mid.addLayout(right, 1)

        outer.addLayout(mid, 1)

    def _build_files_tab(self):
        v = QVBoxLayout(self.tab_files)
        v.setContentsMargins(10,10,10,10)
        self.files_panel = FilesPanel(self.s, self.api_key)
        self.files_panel.attached_changed.connect(self.on_attached_changed)
        self.files_panel.logline.connect(self.log)
        v.addWidget(self.files_panel, 1)

    def _build_help_tab(self):
        v = QVBoxLayout(self.tab_help)
        v.setContentsMargins(10,10,10,10)
        txt = QPlainTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(
            "Základní použití:\n"
            "1) Nastav API-KEY.\n"
            "2) Vyber MODE (GENERATE/MODIFY/QA) nebo zapni SEND AS C (BATCH).\n"
            "3) Vyplň IN/OUT. Pro MODIFY se skenuje IN, pro GENERATE je IN volitelný.\n"
            "4) Volitelně připoj files přes FILES API panel.\n"
            "5) Stiskni KÁJO GO'.\n\n"
            "OUT zapisuje bez dotazů. Pokud je zapnutý VERSING, vytvoří se snapshot složka <OUTNAME><DDMMYYYYHHMM>.\n"
            "Diagnostics IN sbírá informace a připojí je do promptu přes Files API.\n"
            "Diagnostics OUT: pokud v OUT vznikne readmerepair.txt a repair script, aplikace nabídne spuštění."
        )
        v.addWidget(txt, 1)

    # ---------- helpers ----------
    def log(self, msg: str):
        self.txt_log.appendPlainText(msg)

    def _browse_dir(self, target: QLineEdit):
        d = QFileDialog.getExistingDirectory(self, "Select directory", target.text() or os.getcwd())
        if d:
            target.setText(d)
            if self.chk_in_eq_out.isChecked() and target is self.ed_in:
                self.ed_out.setText(d)

    def _browse_file(self, target: QLineEdit):
        fp, _ = QFileDialog.getOpenFileName(self, "Select file", target.text() or os.getcwd(), "All (*.*)")
        if fp:
            target.setText(fp)

    def on_in_eq_out_changed(self):
        if self.chk_in_eq_out.isChecked():
            self.ed_out.setText(self.ed_in.text())
            self.ed_out.setEnabled(False)
            self.btn_out.setEnabled(False)
        else:
            self.ed_out.setEnabled(True)
            self.btn_out.setEnabled(True)

    def on_attached_changed(self, ids: List[str]):
        self.log(f"Attached file_ids: {', '.join(ids) if ids else '(none)'}")

    def on_apikey(self):
        dlg = ApiKeyDialog(self)
        dlg.exec()
        self.api_key = os.environ.get("OPENAI_API_KEY","")
        self.files_panel.set_api_key(self.api_key)
        self._refresh_models_best_effort()

    def on_settings(self):
        dlg = SettingsDialog(self.s, self)
        dlg.exec()
        # refresh price table reference (settings may change URL)
        try:
            from ..core.config import load_settings
            self.s = load_settings()
        except Exception:
            pass

    def on_pricing(self):
        w = PricingWindow(self.s, self.price_table, self.db, self)
        w.show()

    def on_batch_monitor(self):
        w = BatchMonitorWindow(self.s, self.api_key, self)
        w.show()

    def _refresh_models_best_effort(self):
        self.cb_model.clear()
        if self.api_key:
            try:
                client = OpenAIClient(self.api_key)
                models = with_retry(lambda: client.list_models(), self.s.retry, self.breaker)
                names = sorted({m.get("id","") for m in models if m.get("id")})
                if names:
                    self.cb_model.addItems(names)
            except Exception as e:
                self.log(f"Model refresh failed: {e}")
        if self.cb_model.count() == 0:
            self.cb_model.addItems(["gpt-4o-mini","gpt-4o"])
        # prefer default_model if set
        if getattr(self.s, "default_model", ""):
            i = self.cb_model.findText(self.s.default_model)
            if i >= 0:
                self.cb_model.setCurrentIndex(i)

    def _maybe_resume_hint(self):
        rid = find_last_incomplete_run(self.s.log_dir)
        if rid:
            self.log(f"Pozn.: nalezen nedokončený RUN: {rid} (viz {os.path.join(self.s.log_dir, rid)})")

    # ---------- run ----------
    def _validate_paths(self, mode: str, send_as_c: bool) -> bool:
        in_dir = self.ed_in.text().strip()
        out_dir = self.ed_out.text().strip()
        if send_as_c or mode == "GENERATE":
            # IN optional
            pass
        else:
            if not in_dir or not os.path.isdir(in_dir):
                QMessageBox.warning(self, "Paths", "IN musí existovat (pro MODIFY).")
                return False
        if not out_dir:
            QMessageBox.warning(self, "Paths", "OUT není nastaven.")
            return False
        if not os.path.isdir(out_dir):
            try:
                os.makedirs(out_dir, exist_ok=True)
            except Exception as e:
                QMessageBox.critical(self, "Paths", f"Nelze vytvořit OUT: {e}")
                return False
        return True

    def on_go(self):
        if self.worker is not None:
            QMessageBox.information(self, "Run", "Běží jiný RUN.")
            return
        if not self.api_key:
            QMessageBox.warning(self, "API-KEY", "Nejdřív nastav OPENAI_API_KEY.")
            return

        mode = self.cb_mode.currentText()
        send_as_c = bool(self.chk_send_as_c.isChecked())
        if not self._validate_paths(mode, send_as_c):
            return

        run_id = new_run_id()
        self.run_logger = RunLogger(self.s.log_dir, run_id, project_name=self.ed_project.text().strip())
        self.log(f"RUN started: {run_id}")
        # persist UI state snapshot
        try:
            self.run_logger.save_json("misc", f"UI_STATE_{int(time.time())}", {"ui": "snapshot", "cfg_preview": {"project": self.ed_project.text().strip(), "mode": mode, "send_as_c": send_as_c, "model": self.cb_model.currentText().strip()}})
        except Exception:
            pass

        cfg = UiRunConfig(
            project=self.ed_project.text().strip(),
            prompt=self.txt_prompt.toPlainText(),
            mode=mode,
            send_as_c=send_as_c,
            model=self.cb_model.currentText().strip(),
            response_id=self.ed_response_id.text().strip(),
            attached_file_ids=self.files_panel.attached_ids(),
            in_dir=self.ed_in.text().strip(),
            out_dir=self.ed_out.text().strip(),
            in_equals_out=bool(self.chk_in_eq_out.isChecked()),
            versing=bool(self.chk_versing.isChecked()),
            diag_windows_in=bool(self.chk_diag_win_in.isChecked()),
            diag_windows_out=bool(self.chk_diag_win_out.isChecked()),
            diag_ssh_in=bool(self.chk_diag_ssh_in.isChecked()),
            diag_ssh_out=bool(self.chk_diag_ssh_out.isChecked()),
            ssh_user=self.ed_ssh_user.text().strip(),
            ssh_host=self.ed_ssh_host.text().strip(),
            ssh_key=self.ed_ssh_key.text().strip(),
            ssh_password=self.ed_ssh_pwd.text(),
        )
        try:
            self.run_logger.save_json("misc", f"UI_STATE_{int(time.time())}", {"cfg": cfg.__dict__})
        except Exception:
            pass


        self.worker = RunWorker(cfg, self.s, self.api_key, self.run_logger, self.db, self.price_table)

        self.progress_dialog = ProgressDialog(self)
        self.progress_dialog.btn_stop.clicked.connect(self.on_stop)
        self.progress_dialog.show()
        self.worker.progress.connect(self.pb.setValue)
        self.worker.progress.connect(lambda v: self.progress_dialog.set_progress(v) if self.progress_dialog else None)
        self.worker.subprogress.connect(self.pb_sub.setValue)
        self.worker.subprogress.connect(lambda v: self.progress_dialog.set_subprogress(v) if self.progress_dialog else None)
        self.worker.status.connect(lambda s: self.titlebar.lbl.setText(f"Kája — {s}"))
        self.worker.status.connect(lambda s: self.progress_dialog.set_status(s) if self.progress_dialog else None)
        self.worker.logline.connect(self.log)
        self.worker.logline.connect(lambda s: self.progress_dialog.add_log(s) if self.progress_dialog else None)
        self.worker.finished_ok.connect(self.on_run_ok)
        self.worker.finished_err.connect(self.on_run_err)
        self.worker.start()

    def on_stop(self):
        if self.worker is not None:
            self.worker.request_stop()
            self.log("Stop requested.")

    def on_run_ok(self, result: dict):
        rid = self.run_logger.run_id if self.run_logger else ""
        self.log(f"RUN completed: {rid}")
        self.worker = None
        if self.progress_dialog:
            self.progress_dialog.close()
            self.progress_dialog = None
        self.titlebar.lbl.setText("Kája")
        self.pb.setValue(100)
        self.pb_sub.setValue(100)

        # Diagnostics OUT optional: check for repair files
        if self.chk_diag_win_out.isChecked() or self.chk_diag_ssh_out.isChecked():
            self._maybe_execute_repair(self.ed_out.text().strip())

        # Open OUT folder
        out_dir = self.ed_out.text().strip()
        if out_dir and os.path.isdir(out_dir):
            if QMessageBox.question(self, "Open OUT", "Otevřít OUT složku?") == QMessageBox.Yes:
                try:
                    if os.name == "nt":
                        os.startfile(out_dir)  # type: ignore
                    else:
                        subprocess.Popen(["xdg-open", out_dir])
                except Exception:
                    pass

    def on_run_err(self, err: str):
        rid = self.run_logger.run_id if self.run_logger else ""
        self.log(f"RUN failed: {rid} -> {err}")
        self.worker = None
        if self.progress_dialog:
            self.progress_dialog.close()
            self.progress_dialog = None
        self.titlebar.lbl.setText("Kája")
        QMessageBox.critical(self, "RUN failed", err)

    def _maybe_execute_repair(self, out_dir: str):
        if not out_dir or not os.path.isdir(out_dir):
            return
        readme = os.path.join(out_dir, EXPECTED_REPAIR_README)
        if not os.path.exists(readme):
            self.log("Diagnostics OUT: readmerepair.txt not found.")
            return
        try:
            with open(readme, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception:
            content = "(nelze načíst readmerepair.txt)"
        self.log("Diagnostics OUT: readmerepair.txt detected.")
        if QMessageBox.question(self, "Repair", f"Nalezen {EXPECTED_REPAIR_README}. Spustit repair script?") != QMessageBox.Yes:
            return

        # Find script
        candidates = [
            os.path.join(out_dir, "RUN_THIS_SCRIPT_REPAIRME_KAJOVO_WINDOWS.bat"),
            os.path.join(out_dir, "run_this_script_repairme_kajovo_windows.bat"),
            os.path.join(out_dir, "run_this_script_repairme_kajovo.sh"),
            os.path.join(out_dir, "RUN_THIS_SCRIPT_REPAIRME_KAJOVO.sh"),
        ]
        script = next((p for p in candidates if os.path.exists(p)), None)
        if not script:
            QMessageBox.warning(self, "Repair", "Repair script nebyl nalezen.")
            return

        log_path = os.path.join(out_dir, "_repair_exec_log.txt")
        try:
            if os.name == "nt" and script.lower().endswith(".bat"):
                p = subprocess.run([script], cwd=out_dir, capture_output=True, text=True, shell=True)
            else:
                p = subprocess.run(["bash", script], cwd=out_dir, capture_output=True, text=True)
            with open(log_path, "w", encoding="utf-8") as f:
                f.write("READMEREPAIR:\n" + content + "\n\nRETURN_CODE:\n" + str(getattr(p, "returncode", "")) + "\n\nSTDOUT:\n" + (p.stdout or "") + "\n\nSTDERR:\n" + (p.stderr or ""))
            QMessageBox.information(self, "Repair", f"Hotovo. Log: {log_path}")
        except Exception as e:
            QMessageBox.critical(self, "Repair", f"Nelze spustit: {e}")
