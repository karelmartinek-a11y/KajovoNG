from __future__ import annotations

from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton
from PySide6.QtCore import Qt, QPoint, Signal

class TitleBar(QWidget):
    request_close = Signal()
    request_minimize = Signal()

    def __init__(self, title: str = "Kája", parent=None):
        super().__init__(parent)
        self.setFixedHeight(38)
        self._drag_pos: QPoint | None = None

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 10, 0)
        layout.setSpacing(8)

        self.lbl = QLabel(title)
        self.lbl.setStyleSheet("font-weight: 600;")
        layout.addWidget(self.lbl)
        layout.addStretch(1)

        self.btn_min = QPushButton("—")
        self.btn_min.setFixedSize(36, 26)
        self.btn_min.clicked.connect(self.request_minimize.emit)
        layout.addWidget(self.btn_min)

        self.btn_close = QPushButton("✕")
        self.btn_close.setFixedSize(36, 26)
        self.btn_close.clicked.connect(self.request_close.emit)
        layout.addWidget(self.btn_close)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPosition().toPoint()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag_pos is None:
            return
        if e.buttons() & Qt.LeftButton:
            w = self.window()
            delta = e.globalPosition().toPoint() - self._drag_pos
            w.move(w.pos() + delta)
            self._drag_pos = e.globalPosition().toPoint()
            e.accept()

    def mouseReleaseEvent(self, e):
        self._drag_pos = None
        e.accept()
