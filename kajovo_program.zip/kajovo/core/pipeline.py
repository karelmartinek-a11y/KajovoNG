from __future__ import annotations

import os, time, json, shutil
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from PySide6.QtCore import QObject, Signal, QThread

from .utils import ts_code, ensure_dir, is_versing_snapshot_dir, sha256_file
from .filescan import scan_tree, build_manifest
from .openai_client import OpenAIClient
from .retry import with_retry, CircuitBreaker
from .contracts import extract_text_from_response, parse_json_strict, ContractError, validate_paths
from .pricing import PriceTable, compute_cost
from .receipt import Receipt, ReceiptDB

@dataclass
class UiRunConfig:
    project: str
    prompt: str
    mode: str  # GENERATE|MODIFY|QA
    send_as_c: bool
    model: str
    response_id: str
    attached_file_ids: List[str]
    in_dir: str
    out_dir: str
    in_equals_out: bool
    versing: bool
    diag_windows_in: bool
    diag_windows_out: bool
    diag_ssh_in: bool
    diag_ssh_out: bool
    ssh_user: str
    ssh_host: str
    ssh_key: str
    ssh_password: str

class RunWorker(QThread):
    progress = Signal(int)
    subprogress = Signal(int)
    status = Signal(str)
    logline = Signal(str)
    finished_ok = Signal(dict)
    finished_err = Signal(str)

    def __init__(self, cfg: UiRunConfig, settings, api_key: str, run_logger, receipt_db: ReceiptDB, price_table: PriceTable, parent: Optional[QObject]=None):
        super().__init__(parent)
        self.cfg = cfg
        self.settings = settings
        self.api_key = api_key
        self.log = run_logger
        self.db = receipt_db
        self.price_table = price_table
        self.breaker = CircuitBreaker(settings.retry.circuit_breaker_failures, settings.retry.circuit_breaker_cooldown_s)
        self._stop = False

    def request_stop(self):
        self._stop = True

    def _check_stop(self):
        if self._stop:
            raise RuntimeError("STOP_REQUESTED")

    def _set(self, p: int, sp: int, msg: str):
        self.progress.emit(p)
        self.subprogress.emit(sp)
        self.status.emit(msg)
        self.logline.emit(msg)
        try:
            self.log.event("ui.progress", {"p": p, "sp": sp, "msg": msg})
        except Exception:
            pass

    def run(self):
        try:
            self.log.update_state({"status":"running","started_at":time.time(),"mode":self.cfg.mode,"send_as_c":self.cfg.send_as_c,"model":self.cfg.model})
            client = OpenAIClient(self.api_key)

            diag_file_ids = self._maybe_collect_diagnostics(client)

            if self.cfg.send_as_c:
                result = self._run_c_batch(client, diag_file_ids)
            else:
                if self.cfg.mode == "GENERATE":
                    result = self._run_a_generate(client, diag_file_ids)
                elif self.cfg.mode == "MODIFY":
                    result = self._run_b_modify(client, diag_file_ids)
                else:
                    result = self._run_qa(client, diag_file_ids)

            self.log.update_state({"status":"completed","completed_at":time.time()})
            self.finished_ok.emit(result)
        except Exception as e:
            if str(e) == "STOP_REQUESTED":
                self.log.update_state({"status":"stopped","stopped_at":time.time()})
                self.finished_err.emit("STOPPED")
            else:
                try:
                    self.log.exception("run", e)
                except Exception:
                    pass
                self.log.update_state({"status":"failed","failed_at":time.time(),"error":str(e)})
                self.finished_err.emit(str(e))

    # ---------- common ----------
    def _input_parts(self, text: str, file_ids: List[str]) -> List[Dict[str, Any]]:
        parts: List[Dict[str, Any]] = [{"type":"input_text","text":text}]
        for fid in file_ids:
            parts.append({"type":"input_file","file_id":fid})
        return parts

    def _maybe_collect_diagnostics(self, client: OpenAIClient) -> List[str]:
        diag_file_ids: List[str] = []
        if not (self.cfg.diag_windows_in or self.cfg.diag_ssh_in):
            return diag_file_ids

        self._set(2, 0, "Diagnostics IN: collecting...")
        diag_root = os.path.join(self.log.paths.manifests_dir, "diagnostics")
        ensure_dir(diag_root)
        diag_files: List[str] = []

        if self.cfg.diag_windows_in:
            from .diagnostics.windows import collect_windows_diagnostics
            folder, files = collect_windows_diagnostics(diag_root)
            diag_files.extend(files)
            try:
                self.log.event("diagnostics.windows.collected", {"folder": folder, "count": len(files)})
            except Exception:
                pass

        if self.cfg.diag_ssh_in:
            from .diagnostics.ssh import collect_ssh_diagnostics
            folder, files = collect_ssh_diagnostics(diag_root, self.cfg.ssh_host, self.cfg.ssh_user, self.cfg.ssh_key, self.cfg.ssh_password)
            diag_files.extend(files)
            try:
                self.log.event("diagnostics.ssh.collected", {"folder": folder, "count": len(files)})
            except Exception:
                pass

        for i, fp in enumerate(diag_files):
            self._check_stop()
            self.subprogress.emit(int((i+1)*100/max(1,len(diag_files))))
            try:
                up = with_retry(lambda p=fp: client.upload_file(p, purpose="user_data"), self.settings.retry, self.breaker)
                diag_file_ids.append(up["id"])
                self.log.event("upload.diagnostics", {"local": fp, "file_id": up["id"], "purpose": "user_data", "bytes": os.path.getsize(fp)})
            except Exception as e:
                try:
                    self.log.exception("upload.diagnostics", e)
                except Exception:
                    pass

        return diag_file_ids

    def _create_snapshot(self, root: str) -> str:
        root = os.path.abspath(root)
        root_name = os.path.basename(root)
        snap_name = f"{root_name}{ts_code()}"
        snap_dir = os.path.join(root, snap_name)
        deny = {"venv",".venv","LOG",snap_name}

        def ignore(dirpath, names):
            ignored = set()
            for n in names:
                if n in deny:
                    ignored.add(n)
                elif is_versing_snapshot_dir(n, root_name):
                    ignored.add(n)
            return ignored

        shutil.copytree(root, snap_dir, ignore=ignore, dirs_exist_ok=True)
        try:
            self.log.event("versing.snapshot.created", {"snap_dir": snap_dir})
        except Exception:
            pass
        return snap_dir

    def _save_out_files(self, files: List[Dict[str, Any]]) -> Dict[str, Any]:
        out_dir = self.cfg.out_dir
        ensure_dir(out_dir)

        if self.cfg.versing and files:
            self._set(80, 0, "VERSING: snapshot before write...")
            self._create_snapshot(out_dir)

        saved: List[Dict[str, Any]] = []
        for i, f in enumerate(files):
            self._check_stop()
            rel = f["path"]
            content = f.get("content","")
            dst = os.path.join(out_dir, rel.replace("/", os.sep))
            ensure_dir(os.path.dirname(dst))
            before_size = os.path.getsize(dst) if os.path.exists(dst) else None
            before = sha256_file(dst, max_bytes=2*1024*1024) if os.path.exists(dst) else None
            with open(dst, "w", encoding="utf-8", newline="\n") as fp:
                fp.write(content)
            after_size = os.path.getsize(dst)
            after = sha256_file(dst, max_bytes=2*1024*1024)
            self.log.record_fs_change("write", src=rel, dst=dst, before=before, after=after, before_size=before_size, after_size=after_size)
            saved.append({"path": rel, "dst": dst, "bytes": after_size})
            self.subprogress.emit(int((i+1)*100/max(1,len(files))))
        self.log.save_json("manifests", "out_saved_map", {"saved": saved, "out_dir": out_dir})
        return {"saved": saved}

    def _usage_from_resp(self, resp: Dict[str, Any]) -> Tuple[int,int,Dict[str,Any]]:
        usage = resp.get("usage") or {}
        if not isinstance(usage, dict):
            return 0,0,{}
        inp = int(usage.get("input_tokens") or usage.get("prompt_tokens") or 0)
        out = int(usage.get("output_tokens") or usage.get("completion_tokens") or 0)
        return inp, out, usage

    def _record_receipt(self, resp: Dict[str, Any], mode: str, flow_type: str, response_id: Optional[str]=None, batch_id: Optional[str]=None, is_batch: bool=False):
        inp, out, usage = self._usage_from_resp(resp or {})
        row = self.price_table.get(self.cfg.model)
        verified = bool(self.price_table.verified and row is not None)
        if row is None:
            row = PriceTable.builtin_fallback().get("gpt-4o-mini")
            verified = False
        total = compute_cost(row, inp, out, is_batch=is_batch) if row else 0.0
        r = Receipt(
            run_id=self.log.run_id,
            created_at=time.time(),
            project=self.cfg.project,
            model=self.cfg.model,
            mode=mode,
            flow_type=flow_type,
            response_id=response_id,
            batch_id=batch_id,
            input_tokens=inp,
            output_tokens=out,
            tool_cost=0.0,
            storage_cost=0.0,
            total_cost=float(total),
            pricing_verified=verified,
            notes=self.cfg.prompt[:4000],
            log_paths={"run_dir": self.log.paths.run_dir},
            usage=usage
        )
        self.db.insert(r)

    # ---------- A: GENERATE ----------
    def _run_a_generate(self, client: OpenAIClient, diag_file_ids: List[str]) -> Dict[str, Any]:
        self._set(5, 0, "A1: PLAN request...")
        a1_schema = (
            '{"contract":"A1_PLAN","project":{"name":"string","one_liner":"string","target_os":"string","language":"string","runtime":"string"},'
            '"assumptions":["string"],"requirements":{"functional":["string"],"non_functional":["string"],"constraints":["string"]},'
            '"architecture":{"modules":[{"name":"string","responsibility":"string"}],"data_flow":["string"],"error_handling":["string"],"security_notes":["string"]},'
            '"build_run":{"prerequisites":["string"],"commands":["string"],"verification":["string"]},"deliverable_policy":{"max_lines_per_chunk":500}}'
        )
        instructions = (
            "Jsi senior software architekt a implementátor. "
            "OUTPUT: VRAŤ POUZE validní JSON. ŽÁDNÝ markdown ani další text. "
            f"KONTRAKT A1_PLAN: {a1_schema}"
        )
        payload = {
            "model": self.cfg.model,
            "previous_response_id": (self.cfg.response_id or None),
            "temperature": 0.2,
            "instructions": instructions,
            "input": self._input_parts(self.cfg.prompt, self.cfg.attached_file_ids + diag_file_ids),
        }
        self.log.save_json("requests", f"A1_request_{ts_code()}", {"payload": payload, "ui_state": self.cfg.__dict__})
        resp1 = with_retry(lambda: client.create_response(payload), self.settings.retry, self.breaker)
        self.log.save_json("responses", f"A1_response_{resp1.get('id','NOID')}_{ts_code()}", resp1)
        resp1_id = resp1.get("id","")
        plan = parse_json_strict(extract_text_from_response(resp1))
        if plan.get("contract") != "A1_PLAN":
            raise ContractError("A1_PLAN contract mismatch")

        self._set(15, 0, "A2: STRUCTURE request...")
        a2_schema = '{"contract":"A2_STRUCTURE","root":"string","files":[{"path":"string","purpose":"string","language":"string","generated_in_phase":"A3"}]}'
        instructions2 = (
            "OUTPUT: VRAŤ POUZE validní JSON. ŽÁDNÝ markdown ani další text. "
            f"KONTRAKT A2_STRUCTURE: {a2_schema}"
        )
        payload2 = {
            "model": self.cfg.model,
            "previous_response_id": resp1_id or None,
            "temperature": 0.2,
            "instructions": instructions2,
            "input": self._input_parts("Vygeneruj strukturu souborů podle A1 planu.", self.cfg.attached_file_ids + diag_file_ids),
        }
        self.log.save_json("requests", f"A2_request_{ts_code()}", {"payload": payload2, "ui_state": self.cfg.__dict__})
        resp2 = with_retry(lambda: client.create_response(payload2), self.settings.retry, self.breaker)
        self.log.save_json("responses", f"A2_response_{resp2.get('id','NOID')}_{ts_code()}", resp2)
        resp2_id = resp2.get("id","")
        struct = parse_json_strict(extract_text_from_response(resp2))
        if struct.get("contract") != "A2_STRUCTURE":
            raise ContractError("A2_STRUCTURE contract mismatch")

        files = struct.get("files", []) or []
        out_files: List[Dict[str, Any]] = []
        for idx, f in enumerate(files):
            self._check_stop()
            path = f.get("path")
            if not isinstance(path, str) or not path:
                continue
            self._set(25 + int(45*idx/max(1,len(files))), 0, f"A3: FILE {path}")
            content = self._gen_file_chunks(client, prev_id=resp2_id, contract="A3_FILE", path=path, action=None, diag_file_ids=diag_file_ids)
            out_files.append({"path": path, "content": content, "purpose": f.get("purpose","")})

        saved_map = self._save_out_files(out_files)
        self._record_receipt(resp2, mode="GENERATE", flow_type="A", response_id=resp2_id)
        return {"mode":"GENERATE","plan":plan,"structure":struct,"saved":saved_map,"response_id":resp2_id}

    # ---------- B: MODIFY ----------
    def _run_b_modify(self, client: OpenAIClient, diag_file_ids: List[str]) -> Dict[str, Any]:
        self._set(5, 0, "IN mirror: scan + manifest + upload...")
        root = self.cfg.in_dir
        root_name = os.path.basename(os.path.abspath(root))
        items = scan_tree(
            root, root_name,
            deny_dirs=["venv",".venv","LOG"],
            deny_exts=self.settings.security.deny_extensions_in,
            allow_exts=self.settings.security.allow_extensions_in,
            deny_globs=self.settings.security.deny_globs_in,
            allow_globs=self.settings.security.allow_globs_in
        )
        manifest = build_manifest(root, items, extra={"project": self.cfg.project})
        manifest_path = os.path.join(self.log.paths.manifests_dir, f"mirror_manifest_{ts_code()}.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)

        mf_up = with_retry(lambda: client.upload_file(manifest_path, purpose="user_data"), self.settings.retry, self.breaker)
        manifest_file_id = mf_up["id"]

        uploaded: List[Tuple[str,str]] = []
        up_items = [it for it in items if it.uploadable]
        for i, it in enumerate(up_items):
            self._check_stop()
            self.subprogress.emit(int((i+1)*100/max(1,len(up_items))))
            up = with_retry(lambda p=it.abs_path: client.upload_file(p, purpose="user_data"), self.settings.retry, self.breaker)
            uploaded.append((it.rel_path, up["id"]))
            try:
                self.log.event("upload.mirror", {"path": it.rel_path, "abs": it.abs_path, "file_id": up["id"], "bytes": it.size})
            except Exception:
                pass

        self.log.save_json("manifests", "mirror_manifest", {"manifest_file_id": manifest_file_id, "uploaded": uploaded, "manifest": manifest})

        tools: Optional[List[Dict[str, Any]]] = None
        vs_id: Optional[str] = None
        supports = False
        try:
            self._set(18, 0, "Capability probe: vector store...")
            vs = with_retry(lambda: client.create_vector_store(f"{(self.cfg.project or root_name)}{ts_code()}"), self.settings.retry, self.breaker)
            vs_id = vs.get("id")
            if vs_id:
                for rel, fid in uploaded[:2000]:
                    self._check_stop()
                    with_retry(lambda v=vs_id, f=fid, r=rel: client.add_file_to_vector_store(v, f, attributes={"source_path": os.path.join(root, rel)}), self.settings.retry, self.breaker)
                with_retry(lambda: client.add_file_to_vector_store(vs_id, manifest_file_id, attributes={"source":"mirror_manifest"}), self.settings.retry, self.breaker)
                tools = [{"type":"file_search","vector_store_ids":[vs_id]}]
                supports = True
        except Exception as e:
            supports = False
            tools = None
            vs_id = None
            try:
                self.log.exception("capability_probe", e)
            except Exception:
                pass

        self._set(22, 0, "B1: PLAN (modify)...")
        b1_schema = (
            '{"contract":"B1_PLAN","diagnosis":{"summary":"string","evidence":[{"path":"string","reason":"string"}],"likely_root_causes":["string"]},'
            '"change_plan":{"goals":["string"],"files_to_modify":[{"path":"string","intent":"string"}],"files_to_add":[{"path":"string","intent":"string"}],"verification_steps":["string"]},'
            '"missing_inputs":["string"]}'
        )
        instructions1 = (
            "Jsi senior maintenance inženýr. Pokud je dostupné file_search, použij jej. "
            "OUTPUT: VRAŤ POUZE validní JSON. ŽÁDNÝ markdown ani další text. "
            f"KONTRAKT B1_PLAN: {b1_schema}"
        )
        payload1 = {
            "model": self.cfg.model,
            "previous_response_id": (self.cfg.response_id or None),
            "temperature": 0.2,
            "instructions": instructions1,
            "input": self._input_parts(self.cfg.prompt, self.cfg.attached_file_ids + diag_file_ids + [manifest_file_id] + [fid for _, fid in uploaded]),
        }
        if supports and tools:
            payload1["tools"] = tools
        self.log.save_json("requests", f"B1_request_{ts_code()}", {"payload": payload1, "ui_state": self.cfg.__dict__, "supports_file_search": supports, "vector_store_id": vs_id})
        resp1 = with_retry(lambda: client.create_response(payload1), self.settings.retry, self.breaker)
        self.log.save_json("responses", f"B1_response_{resp1.get('id','NOID')}_{ts_code()}", resp1)
        resp1_id = resp1.get("id","")
        plan = parse_json_strict(extract_text_from_response(resp1))
        if plan.get("contract") != "B1_PLAN":
            raise ContractError("B1_PLAN contract mismatch")

        if getattr(self.settings, "dry_run_modify", False):
            return {"mode":"MODIFY","dry_run":True,"plan":plan,"response_id":resp1_id,"vector_store_id":vs_id,"supports_file_search":supports}

        self._set(35, 0, "B2: STRUCTURE (touched files)...")
        b2_schema = '{"contract":"B2_STRUCTURE","touched_files":[{"path":"string","action":"modify|add","intent":"string"}],"invariants":["string"]}'
        instructions2 = (
            "OUTPUT: VRAŤ POUZE validní JSON. ŽÁDNÝ markdown ani další text. "
            f"KONTRAKT B2_STRUCTURE: {b2_schema}"
        )
        payload2 = {
            "model": self.cfg.model,
            "previous_response_id": resp1_id or None,
            "temperature": 0.2,
            "instructions": instructions2,
            "input": self._input_parts("Vrať seznam touched_files pro implementaci B3.", self.cfg.attached_file_ids + diag_file_ids + [manifest_file_id] + [fid for _, fid in uploaded]),
        }
        if supports and tools:
            payload2["tools"] = tools
        self.log.save_json("requests", f"B2_request_{ts_code()}", {"payload": payload2, "ui_state": self.cfg.__dict__})
        resp2 = with_retry(lambda: client.create_response(payload2), self.settings.retry, self.breaker)
        self.log.save_json("responses", f"B2_response_{resp2.get('id','NOID')}_{ts_code()}", resp2)
        resp2_id = resp2.get("id","")
        struct = parse_json_strict(extract_text_from_response(resp2))
        if struct.get("contract") != "B2_STRUCTURE":
            raise ContractError("B2_STRUCTURE contract mismatch")

        touched = struct.get("touched_files", []) or []
        out_files: List[Dict[str, Any]] = []
        for i, tf in enumerate(touched):
            self._check_stop()
            path = tf.get("path","")
            action = tf.get("action","modify")
            if not path:
                continue
            self._set(45 + int(40*i/max(1,len(touched))), 0, f"B3: {action} {path}")
            content = self._gen_file_chunks(client, prev_id=resp2_id, contract="B3_FILE", path=path, action=action, diag_file_ids=diag_file_ids, tools=tools if supports else None)
            out_files.append({"path": path, "content": content})

        saved_map = self._save_out_files(out_files)
        self._record_receipt(resp2, mode="MODIFY", flow_type="B", response_id=resp2_id)
        return {"mode":"MODIFY","plan":plan,"structure":struct,"saved":saved_map,"response_id":resp2_id,"vector_store_id":vs_id,"supports_file_search":supports}

    # ---------- QA ----------
    def _run_qa(self, client: OpenAIClient, diag_file_ids: List[str]) -> Dict[str, Any]:
        self._set(10, 0, "QA: request...")
        payload = {
            "model": self.cfg.model,
            "previous_response_id": (self.cfg.response_id or None),
            "temperature": 0.2,
            "instructions": "Jsi QA asistent. Vrať pouze textovou odpověď.",
            "input": self._input_parts(self.cfg.prompt, self.cfg.attached_file_ids + diag_file_ids),
        }
        self.log.save_json("requests", f"QA_request_{ts_code()}", {"payload": payload, "ui_state": self.cfg.__dict__})
        resp = with_retry(lambda: client.create_response(payload), self.settings.retry, self.breaker)
        self.log.save_json("responses", f"QA_response_{resp.get('id','NOID')}_{ts_code()}", resp)
        self._record_receipt(resp, mode="QA", flow_type="QA", response_id=resp.get("id"))
        return {"mode":"QA","response_id":resp.get("id",""),"text":extract_text_from_response(resp)}

    # ---------- C: Batch ----------
    def _run_c_batch(self, client: OpenAIClient, diag_file_ids: List[str]) -> Dict[str, Any]:
        self._set(10, 0, "C: building batch JSONL...")
        c_schema = (
            '{"contract":"C_FILES_ALL","project":{"name":"string","target_os":"Windows 10/11","runtime":"string","language":"string"},'
            '"root":"string","files":[{"path":"relative/path/file.ext","purpose":"string","content":"string"}],'
            '"build_run":{"prerequisites":["string"],"commands":["string"],"verification":["string"]},"notes":["string"]}'
        )
        instructions = (
            "Jsi senior programátor. OUTPUT: VRAŤ POUZE validní JSON dokument dle KONTRAKTU C_FILES_ALL. "
            "ŽÁDNÝ markdown ani další text. "
            f"KONTRAKT C_FILES_ALL: {c_schema}"
        )
        req_line = {
            "custom_id": f"{self.log.run_id}_C1",
            "method": "POST",
            "url": "/v1/responses",
            "body": {
                "model": self.cfg.model,
                "previous_response_id": (self.cfg.response_id or None),
                "temperature": 0.2,
                "instructions": instructions,
                "input": self._input_parts(self.cfg.prompt, diag_file_ids),
            }
        }
        jsonl_path = os.path.join(self.log.paths.requests_dir, f"C_batch_{ts_code()}.jsonl")
        with open(jsonl_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(req_line, ensure_ascii=False) + "\n")

        self._set(20, 0, "C: upload JSONL...")
        up = with_retry(lambda: client.upload_file(jsonl_path, purpose="batch"), self.settings.retry, self.breaker)
        input_file_id = up["id"]

        self._set(25, 0, "C: create batch...")
        batch = with_retry(lambda: client.create_batch(input_file_id=input_file_id, endpoint="/v1/responses"), self.settings.retry, self.breaker)
        batch_id = batch.get("id","")
        self.log.update_state({"batch_id": batch_id})
        self.log.save_json("responses", f"C_batch_created_{batch_id}_{ts_code()}", batch)

        self._set(35, 0, f"C: polling batch {batch_id} ...")
        start = time.time()
        while True:
            self._check_stop()
            bj = with_retry(lambda: client.retrieve_batch(batch_id), self.settings.retry, self.breaker)
            st = bj.get("status","")
            self.status.emit(f"Batch status: {st}")
            try:
                self.log.event("batch.poll", {"batch_id": batch_id, "status": st})
            except Exception:
                pass
            if st in ("completed","failed","cancelled","expired"):
                batch = bj
                break
            if time.time() - start > self.settings.batch_timeout_s:
                raise RuntimeError("Batch timeout")
            time.sleep(self.settings.batch_poll_interval_s)

        output_file_id = batch.get("output_file_id")
        if not output_file_id:
            raise RuntimeError(f"Batch finished without output_file_id. status={batch.get('status')}")
        raw = with_retry(lambda: client.file_content(output_file_id), self.settings.retry, self.breaker)
        out_path = os.path.join(self.log.paths.responses_dir, f"C_batch_output_{batch_id}_{ts_code()}.jsonl")
        with open(out_path, "wb") as f:
            f.write(raw)

        line = raw.decode("utf-8", errors="ignore").splitlines()[0] if raw else ""
        try:
            obj = json.loads(line)
        except Exception:
            raise ContractError("Batch output JSONL: invalid JSON line")
        body = obj.get("response", {}).get("body") or obj.get("body") or {}
        if not isinstance(body, dict):
            raise ContractError("Batch output: body is not dict")
        j = parse_json_strict(extract_text_from_response(body))
        if j.get("contract") != "C_FILES_ALL":
            raise ContractError("C_FILES_ALL contract mismatch")

        files = j.get("files", []) or []
        validate_paths(files)
        saved_map = self._save_out_files(files)
        self._record_receipt(body, mode="C", flow_type="C", batch_id=batch_id, is_batch=True)
        return {"mode":"C","batch_id":batch_id,"saved":saved_map,"contract":j}

    # ---------- File generation with chunking ----------
    def _gen_file_chunks(self, client: OpenAIClient, prev_id: str, contract: str, path: str, action: Optional[str],
                         diag_file_ids: List[str], tools: Optional[List[Dict[str, Any]]]=None) -> str:
        if contract == "A3_FILE":
            schema = '{"contract":"A3_FILE","path":"string","chunking":{"max_lines":500,"chunk_index":0,"chunk_count":0,"has_more":false,"next_chunk_index":null},"content":"string"}'
        else:
            schema = '{"contract":"B3_FILE","path":"string","action":"modify|add","chunking":{"max_lines":500,"chunk_index":0,"chunk_count":0,"has_more":false,"next_chunk_index":null},"content":"string","notes":["string"]}'
        instructions = (
            "OUTPUT: VRAŤ POUZE validní JSON. ŽÁDNÝ markdown ani další text. "
            "KRITICKÉ: content je vždy kompletní výsledné znění souboru (ne diff/patch). "
            f"CHUNK: max 500 řádků. KONTRAKT: {schema}"
        )

        chunk_index = 0
        parts: List[str] = []
        while True:
            self._check_stop()
            if contract == "A3_FILE":
                prompt = f"Vrať obsah souboru PATH={path}. Pokud je dlouhý, vrať chunk CHUNK_INDEX={chunk_index}."
            else:
                prompt = f"Vrať výsledný obsah souboru PATH={path} ACTION={action}. Pokud je dlouhý, vrať chunk CHUNK_INDEX={chunk_index}."
            payload = {
                "model": self.cfg.model,
                "previous_response_id": prev_id or None,
                "temperature": 0.0,
                "instructions": instructions,
                "input": self._input_parts(prompt, self.cfg.attached_file_ids + diag_file_ids),
            }
            if tools:
                payload["tools"] = tools
            self.log.save_json("requests", f"{contract}_{path.replace('/','_')}_{chunk_index}_{ts_code()}", {"payload": payload, "ui_state": self.cfg.__dict__})
            resp = with_retry(lambda: client.create_response(payload), self.settings.retry, self.breaker)
            self.log.save_json("responses", f"{contract}_{resp.get('id','NOID')}_{path.replace('/','_')}_{chunk_index}_{ts_code()}", resp)
            j = parse_json_strict(extract_text_from_response(resp))
            if j.get("contract") != contract:
                raise ContractError(f"{contract} mismatch for {path}")
            parts.append(j.get("content",""))
            ch = j.get("chunking", {}) or {}
            if not ch.get("has_more"):
                break
            chunk_index = int(ch.get("next_chunk_index") or (chunk_index+1))
            if chunk_index > 5000:
                raise ContractError("Chunk loop guard")
        return "".join(parts)
