from __future__ import annotations

import os, subprocess, time
from typing import List, Tuple
from ..utils import ensure_dir

def collect_windows_diagnostics(output_base_dir: str) -> Tuple[str, List[str]]:
    ensure_dir(output_base_dir)
    script = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "diagnostics", "windows_collect.ps1"))
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = os.path.join(output_base_dir, f"Diag_{ts}")
    ensure_dir(out_dir)
    cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", script, "-OutDir", out_dir]
    p = subprocess.run(cmd, capture_output=True, text=True)
    log_txt = os.path.join(out_dir, "_collector_stdout_stderr.txt")
    with open(log_txt, "w", encoding="utf-8") as f:
        f.write("STDOUT:\n" + (p.stdout or "") + "\n\nSTDERR:\n" + (p.stderr or ""))
    files: List[str] = []
    for root, _, fnames in os.walk(out_dir):
        for fn in fnames:
            files.append(os.path.join(root, fn))
    return out_dir, files
