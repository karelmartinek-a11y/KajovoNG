from __future__ import annotations

import os, time, posixpath
from typing import List, Tuple, Optional
import paramiko
from ..utils import ensure_dir

REMOTE_SCRIPT = r"""#!/usr/bin/env bash
set -o pipefail
set +e

outdir="$1"
mkdir -p "$outdir"/system "$outdir"/network "$outdir"/processes

(cat /etc/os-release) > "$outdir/system/os_release.txt" 2>&1
(uname -a) > "$outdir/system/uname_a.txt" 2>&1
(uptime && who -b) > "$outdir/system/uptime.txt" 2>&1
(locale && (timedatectl 2>/dev/null || true)) > "$outdir/system/locale_timezone.txt" 2>&1
(hostnamectl 2>/dev/null || true; cat /etc/hosts; cat /etc/hostname 2>/dev/null || true) > "$outdir/system/hostname_hosts.txt" 2>&1
(ulimit -a) > "$outdir/system/limits_summary.txt" 2>&1
(sysctl -a 2>/dev/null || true) > "$outdir/system/sysctl_all.txt" 2>&1

(ss -lntup 2>/dev/null || netstat -lntup 2>/dev/null || true) > "$outdir/network/listen.txt" 2>&1
(ip a 2>/dev/null || ifconfig -a 2>/dev/null || true) > "$outdir/network/ip_addr.txt" 2>&1
(ip r 2>/dev/null || route -n 2>/dev/null || true) > "$outdir/network/routes.txt" 2>&1

(ps auxww) > "$outdir/processes/ps_aux.txt" 2>&1

tar -czf "$outdir.tar.gz" -C "$(dirname $outdir)" "$(basename $outdir)" 2>/dev/null || true
echo "TAR=$outdir.tar.gz"
"""

def collect_ssh_diagnostics(local_base_dir: str, host: str, username: str, key_path: str, password: str = "") -> Tuple[str, List[str]]:
    ensure_dir(local_base_dir)
    ts = time.strftime("%Y%m%d-%H%M%S")
    local_root = os.path.join(local_base_dir, f"Diag_{ts}")
    ensure_dir(local_root)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    pkey = None
    if key_path:
        try:
            pkey = paramiko.RSAKey.from_private_key_file(key_path, password=password or None)
        except Exception:
            try:
                pkey = paramiko.Ed25519Key.from_private_key_file(key_path, password=password or None)
            except Exception:
                pkey = None

    client.connect(hostname=host, username=username, pkey=pkey, password=(password or None), timeout=20)
    try:
        sftp = client.open_sftp()
        remote_script = f"/tmp/kajovo_diag_{ts}.sh"
        with sftp.open(remote_script, "w") as f:
            f.write(REMOTE_SCRIPT)
        sftp.chmod(remote_script, 0o700)

        remote_outdir = f"/root/Diag_{ts}"
        stdin, stdout, stderr = client.exec_command(f"bash {remote_script} {remote_outdir}", get_pty=True)
        out = stdout.read().decode("utf-8", errors="ignore")
        err = stderr.read().decode("utf-8", errors="ignore")
        with open(os.path.join(local_root, "_ssh_exec.txt"), "w", encoding="utf-8") as f:
            f.write("STDOUT\n"+out+"\n\nSTDERR\n"+err)

        tar_path = None
        for line in out.splitlines():
            if line.startswith("TAR="):
                tar_path = line.split("=",1)[1].strip()
        if not tar_path:
            tar_path = remote_outdir + ".tar.gz"

        local_tar = os.path.join(local_root, "diag.tar.gz")
        try:
            sftp.get(tar_path, local_tar)
        except Exception:
            # last resort: download single _ssh_exec only
            return local_root, [os.path.join(local_root, "_ssh_exec.txt")]

        return local_root, [local_tar, os.path.join(local_root, "_ssh_exec.txt")]
    finally:
        try:
            client.close()
        except Exception:
            pass
