from __future__ import annotations

import os, json, time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple
import requests

@dataclass
class PriceRow:
    model: str
    input_per_1k: float
    output_per_1k: float
    batch_input_per_1k: Optional[float] = None
    batch_output_per_1k: Optional[float] = None
    file_search_per_1k: Optional[float] = None
    storage_per_gb_day: Optional[float] = None

class PriceTable:
    def __init__(self, cache_path: str):
        self.cache_path = cache_path
        self.rows: Dict[str, PriceRow] = {}
        self.last_updated: Optional[float] = None
        self.verified: bool = False

    def load_cache(self) -> None:
        if not os.path.exists(self.cache_path):
            return
        with open(self.cache_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        self.last_updated = raw.get("last_updated")
        self.verified = bool(raw.get("verified"))
        self.rows = {}
        for r in raw.get("rows", []):
            self.rows[r["model"]] = PriceRow(**r)

    def save_cache(self) -> None:
        os.makedirs(os.path.dirname(self.cache_path) or ".", exist_ok=True)
        with open(self.cache_path, "w", encoding="utf-8") as f:
            json.dump({
                "last_updated": self.last_updated,
                "verified": self.verified,
                "rows": [vars(r) for r in self.rows.values()],
            }, f, ensure_ascii=False, indent=2)

    def refresh_from_url(self, url: str, timeout_s: float = 20.0) -> Tuple[bool, str]:
        try:
            r = requests.get(url, timeout=timeout_s)
            r.raise_for_status()
            data = r.json()
            rows = {}
            for row in data.get("rows", []):
                pr = PriceRow(**row)
                rows[pr.model] = pr
            if not rows:
                return False, "price_table: empty rows"
            self.rows = rows
            self.last_updated = time.time()
            self.verified = True
            self.save_cache()
            return True, "OK"
        except Exception as e:
            self.verified = False
            return False, f"refresh_failed: {e}"

    def get(self, model: str) -> Optional[PriceRow]:
        return self.rows.get(model)

    @staticmethod
    def builtin_fallback() -> 'PriceTable':
        pt = PriceTable(cache_path=":memory:")
        pt.verified = False
        pt.rows = {
            "gpt-4o-mini": PriceRow("gpt-4o-mini", 0.15, 0.60),
            "gpt-4o": PriceRow("gpt-4o", 5.00, 15.00),
        }
        return pt

def compute_cost(row: PriceRow, input_tokens: int, output_tokens: int, is_batch: bool=False) -> float:
    inp = row.batch_input_per_1k if is_batch and row.batch_input_per_1k is not None else row.input_per_1k
    outp = row.batch_output_per_1k if is_batch and row.batch_output_per_1k is not None else row.output_per_1k
    return (input_tokens/1000.0)*inp + (output_tokens/1000.0)*outp
