param(
  [Parameter(Mandatory=$true)]
  [string]$OutDir
)

$ErrorActionPreference = "Continue"

function Ensure-Dir($p) { if (!(Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null } }

Ensure-Dir $OutDir
$sys = Join-Path $OutDir "system"
$net = Join-Path $OutDir "network"
$pro = Join-Path $OutDir "processes"
Ensure-Dir $sys; Ensure-Dir $net; Ensure-Dir $pro

"== Windows Diagnostics Collector ==" | Out-File -Encoding utf8 (Join-Path $OutDir "_collector_info.txt")
(Get-Date).ToString("o") | Out-File -Encoding utf8 (Join-Path $OutDir "_collector_timestamp.txt")

# system
try { (Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, OSArchitecture) | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "os_arch.txt")
try { systeminfo } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "systeminfo.txt")
try { Get-CimInstance Win32_BIOS | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_bios.txt")
try { Get-CimInstance Win32_Processor | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_cpu.txt")
try { Get-CimInstance Win32_PhysicalMemory | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_mem.txt")
try { Get-CimInstance Win32_DiskDrive | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_disk.txt")
try { Get-CimInstance Win32_VideoController | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_gpu.txt")
try { Get-CimInstance Win32_BaseBoard | Format-List * } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "wmi_motherboard.txt")
try { Get-ChildItem Env:* | Sort-Object Name | Format-Table -AutoSize } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "env_vars.txt")
try { Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* , HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Sort-Object DisplayName | Format-Table -AutoSize } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "installed_programs.txt")
try { powercfg /a } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "powercfg.txt")
try { driverquery /v } catch { $_ } | Out-File -Encoding utf8 (Join-Path $sys "drivers.txt")

# network
try { ipconfig /all } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "ipconfig_all.txt")
try { route print } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "route_print.txt")
try { netstat -ano } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "netstat_ano.txt")
try { ipconfig /displaydns } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "dns_cache.txt")
try { netsh advfirewall firewall show rule name=all } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "firewall_rules.txt")
try { netsh wlan show profiles } catch { $_ } | Out-File -Encoding utf8 (Join-Path $net "wifi_profiles.txt")

# processes
try { tasklist /v } catch { $_ } | Out-File -Encoding utf8 (Join-Path $pro "tasklist_v.txt")
try { Get-Service | Sort-Object Status,Name | Format-Table -AutoSize } catch { $_ } | Out-File -Encoding utf8 (Join-Path $pro "services.txt")
try { Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location, User | Format-Table -AutoSize } catch { $_ } | Out-File -Encoding utf8 (Join-Path $pro "startup.txt")

"OK" | Out-File -Encoding utf8 (Join-Path $OutDir "_collector_done.txt")
