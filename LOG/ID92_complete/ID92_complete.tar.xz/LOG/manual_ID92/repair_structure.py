"""Oprava kategorií odkazů při zachování akceptačních povinností souborů."""
import copy
import re

from stage import read, save
from kajovo.core.delivery_preparation import validate_delivery_structure


def main():
    structure = copy.deepcopy(read("A2_value.json"))
    requirements = read("original_value_0.json")
    plan = read("original_value_1.json")
    architecture = {a["id"]: set(a["requirement_ids"]) for a in plan["architecture_items"]}
    required = {r["id"] for k in ("explicit_requirements", "implicit_requirements") for r in requirements[k]}
    criteria = {}
    for text in requirements["acceptance_criteria"]:
        match = re.match(r"(AC-\d+)", text)
        if match:
            criteria[match[1]] = text
    changes = []
    for file in structure["files"]:
        before = copy.deepcopy(file)
        misplaced = set(file["requirement_ids"]) - required
        assert misplaced <= criteria.keys(), f"Neznámý požadavek {file['path']}: {misplaced - criteria.keys()}"
        if misplaced:
            file["behavior"] += "\nAkceptační povinnosti: " + "\n".join(criteria[k] for k in sorted(misplaced))
            file["requirement_ids"] = [r for r in file["requirement_ids"] if r in required]
        links = []
        for link in file["architecture_item_ids"]:
            if link not in architecture:
                match = re.fullmatch(r"(WP-\d+)-(?:AC|EX)-\d+", link)
                assert match and match[1] in architecture
                link = match[1]
            if link not in links:
                links.append(link)
        missing = set(file["requirement_ids"]) - set().union(*(architecture[k] for k in links))
        if "EX-060" in missing:
            # Procesní role a systemd profil patří k Trusted Runtime Boundary.
            assert file["path"].startswith("apps/") or file["path"] == "deploy/systemd/service-profiles.json"
            links.append("WP-017")
            missing.remove("EX-060")
        if "EX-006" in missing:
            # Test aktivace Secret musí zachovat ochranu rezervovaného owner klíče.
            assert file["path"] == "tests/postgres/activation-secret.test.ts"
            links.append("WP-018")
            missing.remove("EX-006")
        assert not missing, (file["path"], missing)
        file["architecture_item_ids"] = list(dict.fromkeys(links))
        if before != file:
            changes.append({"path": file["path"], "before": before, "after": copy.deepcopy(file)})
    # Konkrétní implementační povinnosti chybějících vazeb, nikoli prázdná ID.
    obligations = [
        ("WP-001", "IM-001", "packages/contract-pack/src/compiler.ts", "Compiler používá sdílenou implementaci canonical JSON a digestů; vlastní odlišná serializace je zakázána."),
        ("WP-004", "IM-003", "packages/database/src/startup.ts", "Startup ověří health monitorované časové synchronizace hostu a databáze; autoritativní expiry používají DB čas."),
        ("WP-004", "IM-004", "database/baseline/130-constraints-indexes.sql", "Dodat indexy všech CAS, aktivních partial predicates, idempotency, queue eligibility, cursor/fulltext, closure, correlation a retention dotazů."),
        ("WP-005", "EX-059", "packages/domain/src/command-executor.ts", "Vynutit Idempotency-Key, expected-state/CAS, revision/digest/binding/epoch guards a response metadata correlation, logical operation, command, state/event version, activation epoch, result digest a replay flag."),
        ("WP-006", "IM-005", "packages/domain/src/work.ts", "Odvodit admissions a recovery headroom z reálné CPU/RAM/disk/FD/PID/browser/DB kapacity, respektovat bezpečné defaults, hysteresis a zaznamenanou capacity evidence."),
        ("WP-008", "IM-007", "deploy/scripts/backup-restore.ts", "Obnova zahrnuje auditované a testované zálohy master encryption key, bridge CA/private material, TLS keys a backup decryption material; bez nich nesmí recovery oznámit úspěch."),
        ("WP-010", "IM-013", "apps/server/src/routes/streams.ts", "Oddělit replayable domain SSE od MCP no-replay a KBPP preview; vynutit odpovídající timeout, buffering/cache a backpressure kontrakty."),
        ("WP-010", "IM-014", "packages/domain/src/operation-registry.ts", "Poskytovat schema-validovaná form/view metadata pro všechny object types, input validation, disabled-state explanation, audit links a object-action parity."),
        ("WP-011", "IM-010", "apps/audit-archiver/src/main.ts", "Partition/retention joby musí zachovat current pointers, replay windows, closure/recovery evidence a trusted secret visibility pro log/audit/model/browser/artifact/metric storage."),
        ("WP-012", "IM-013", "apps/owner-ui/src/api.ts", "Klient rozlišuje SSE replay a MCP no-replay, ruší jednotlivé streamy korektně a respektuje samostatné preview timeout/backpressure kontrakty."),
        ("WP-014", "EX-074", "packages/domain/src/activation.ts", "Vynutit jednoho canonical writera každého activation object/pointer/projection podle ownership mapy 55.15; worker a migration předávají jen guarded evidence."),
        ("WP-016", "EX-067", "packages/kcip/src/codec.ts", "Wire error/retry mapování používat výhradně ze sdíleného Error and Retry Registry kapitoly 32, včetně terminality, side-effect point a recovery directive."),
        ("WP-022", "EX-064", ".github/workflows/ci.yml", "OpenAI runtime contract gates musí být součástí exact-SHA frozen-lockfile release CI; ověřit runtime/session/storage/model capability kontrakty se síťovými fixture službami."),
        ("WP-022", "IM-012", "packages/openai-runtime/src/client.ts", "Capability refresh váže key/project context, response storage policy a selected model access k jednomu bounded smoke testu dle produktového SSOT; zabránit neřízeným opakováním a evidovat cenu."),
        ("WP-030", "IM-013", "deploy/nginx/kajovocml.conf", "Samostatné location/timeouts/buffering/cache pro domain SSE, MCP no-replay a KBPP preview včetně backpressure."),
        ("WP-033", "EX-066", "packages/browser-interaction/src/bridge-gateway.ts", "Typed bridge boundary ověřuje identitu, původ, vazby, transport security a supply-chain digests v single trusted perimeter; všechny autoritativní operace auditovat."),
        ("WP-039", "EX-072", "tests/postgres/core-concurrency.test.ts", "Concurrency tests spouštějí production handlers a persistentní state registry s deterministic scheduler, linearizability histories, before/after fault points a recovery/direct-state oracle; dodat shrink/replay a oracle mutation checks."),
        ("WP-039", "IM-004", "tests/postgres/core-concurrency.test.ts", "Na production-shaped datech ověřit query plány a contention CAS, partial predicates, idempotency, queue, pagination, fulltext, closure, correlation a retention indexů."),
        ("WP-040", "EX-067", "tests/kcip/wire.test.ts", "Ověřit úplné registry-driven wire mapování stable errors/retry, side-effect pointů, terminality a recovery directive, včetně negativních případů."),
        ("WP-040", "IM-018", "tests/fixtures/fixture-server.ts", "Externí integrační fixture schémata deklarují bezpečný test target a nezávislou postcondition; provider bez idempotency/read-back musí testovat manual-review-capable klasifikaci."),
        ("WP-043", "IM-003", "deploy/acceptance/infrastructure.ts", "Infrastructure acceptance měří bounded host/DB clock drift a ověřuje funkční alarm a time-sync monitoring pro TLS, TOTP, audit a provider requests."),
        ("WP-046", "IM-019", "docs/operations.md", "Dokumentovat konkrétní OWNER navigaci a search/fulltext/correlation dotazy od message přes command, model/tool/browser call, state transition, side effect a audit až k release bez ztráty lineage."),
    ]
    by_path = {f["path"]: f for f in structure["files"]}
    for link, requirement, path, behavior in obligations:
        file = by_path[path]
        assert requirement in architecture[link]
        before = copy.deepcopy(file)
        if link not in file["architecture_item_ids"]:
            file["architecture_item_ids"].append(link)
        if requirement not in file["requirement_ids"]:
            file["requirement_ids"].append(requirement)
        file["behavior"] += "\n" + behavior
        changes.append({"path": path, "before": before, "after": copy.deepcopy(file)})
    save("A2_manual_corrections.json", changes)
    save("A2_corrected_candidate.json", structure)
    validated, additions = validate_delivery_structure(requirements, plan, structure, "GENERATE")
    save("A2_validated.json", validated)
    save("A2_validation.json", {"valid": True, "manual_corrections": len(changes), "added_dependencies": additions, "usage": read("A2_response.json")["usage"]})
    print("A2_VALIDATED", len(validated["files"]), "MANUAL_CORRECTIONS", len(changes), flush=True)


if __name__ == "__main__":
    main()
