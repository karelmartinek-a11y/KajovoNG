"""Sloučení ověřených vazeb A2 a obsahové kontroly A2Q bez opakování API."""
import copy

from stage import read, save, bounded_structure_format
from kajovo.core.delivery_preparation import validate_delivery_structure
import jsonschema


def main():
    value = copy.deepcopy(read("A2Q_value.json"))
    original = {f["path"]: f for f in read("A2_validated.json")["files"]}
    req, plan = read("original_value_0.json"), read("original_value_1.json")
    changed = []
    for file in value["files"]:
        before = copy.deepcopy(file)
        if file["path"] in original:
            old = original[file["path"]]
            assert set(old["architecture_item_ids"]) == set(file["architecture_item_ids"])
            file["requirement_ids"] = copy.deepcopy(old["requirement_ids"])
            if old["behavior"] != file["behavior"]:
                assert file["path"] in ("contracts/registry-schemas/bundle-manifest.json", "packages/agentic-authority/src/provenance.ts")
        elif file["path"].startswith("contracts/registry-schemas/") and file["path"].endswith("-registry.schema.json"):
            assert file["architecture_item_ids"] == ["WP-001"]
            file["requirement_ids"] = ["EX-073"]
        else:
            assert file["path"] == "packages/content-provenance/src/index.ts"
            file["requirement_ids"] = ["EX-071"]
        changed.append({"path": file["path"], "before": before["requirement_ids"], "after": file["requirement_ids"]})
    assert original.keys() <= {f["path"] for f in value["files"]}
    fmt = bounded_structure_format(req, plan)
    jsonschema.validate(value, fmt["format"]["schema"])
    checked, additions = validate_delivery_structure(req, plan, value, "GENERATE")
    save("A2Q_manual_corrections.json", changed)
    save("A2Q_validated.json", checked)
    save("A2Q_validation.json", {"valid": True, "reference_category_corrections": len(changed), "added_dependencies": additions, "usage": read("A2Q_response.json")["usage"]})
    print("A2Q_VALIDATED", len(checked["files"]), flush=True)


if __name__ == "__main__":
    main()
