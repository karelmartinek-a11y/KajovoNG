"""Příprava souborových požadavků s úplnou specifikací a cenovým limitem."""
import json
import sys
import hashlib
import copy
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from openai import OpenAI

from kajovo.core.contracts import file_response_format
from kajovo.core.requirements import stage_instructions
from kajovo.core.delivery_preparation import validate_delivery_structure, digest
from kajovo.core.request_rules import validate_response_payload
from kajovo.core.secret_store import load_api_key
from stage import read, save

ROOT = Path(__file__).resolve().parent


def compact_structure(structure):
    result = copy.deepcopy(structure)
    columns = sorted({key for file in structure["files"] for key in file})
    assert all(set(file) == set(columns) for file in structure["files"])
    result["file_columns"] = columns
    result["files"] = [[file[key] for key in columns] for file in structure["files"]]
    assert all(dict(zip(columns, row, strict=True)) == file for row, file in zip(result["files"], structure["files"], strict=True))
    return result


def coding_file(file):
    return Path(file["path"]).suffix in (".ts", ".tsx", ".rs", ".sql", ".mjs", ".tla")


def body_for(structure, file, source_id):
    specification = {
        "requirements": read("original_value_0.json"),
        "plan": read("original_value_1.json"),
        "structure": compact_structure(structure),
        "maximum_quality": True,
        "source": "Úplné původní zadání je v přiloženém souboru SSOT_CURRENT.txt. Je normativní autoritou. SSOT_CURRENT.md bude dodán přesnou lokální kopií, jeho obsah již negeneruj. Structure.files je bezeztrátová tabulka: názvy sloupců určuje structure.file_columns ve stejném pořadí; každý řádek obsahuje všechny hodnoty původního souborového kontraktu.",
    }
    fmt = file_response_format("A3_FILE", file["path"], 0)
    chunk = fmt["format"]["schema"]["properties"]["chunking"]["properties"]
    chunk["chunk_count"] = {"type": "integer", "enum": [1]}
    chunk["has_more"] = {"type": "boolean", "enum": [False]}
    chunk["next_chunk_index"] = {"type": "null"}
    body = {
        "model": "gpt-5.4-mini" if coding_file(file) else "gpt-5.6-luna", "store": False,
        "instructions": stage_instructions("A3", batch=True),
        "input": [{"role": "user", "content": [
            {"type": "input_file", "file_id": source_id},
            {"type": "input_text", "text": json.dumps({"specification": specification, "file": file}, ensure_ascii=False, separators=(",", ":"))},
        ]}],
        "text": fmt, "reasoning": {"effort": "xhigh"},
        "max_output_tokens": 16384,
    }
    validate_response_payload(body, batch=True)
    return body


def main():
    client = OpenAI(api_key=load_api_key(), max_retries=0, timeout=120)
    action = sys.argv[1]
    if not (ROOT / "source_upload.json").exists():
        source = (ROOT / "original_prompt.txt").read_bytes()
        uploaded = client.files.create(file=("SSOT_CURRENT.txt", source, "text/plain"), purpose="user_data")
        save("source_upload.json", uploaded.model_dump(mode="json"))
        print("SOURCE_UPLOADED", uploaded.id, flush=True)
    source_id = read("source_upload.json")["id"]
    if action == "estimate":
        structure = read("A2Q_validated.json") if (ROOT / "A2Q_validated.json").exists() else read("A2_validated.json")
        file = max(structure["files"], key=lambda f: len(json.dumps(f)))
        body = body_for(structure, file, source_id)
        save("batch_sample_request.json", body)
        count = client.responses.input_tokens.count(**{k: v for k, v in body.items() if k in ("model", "instructions", "input", "text", "reasoning")})
        print("SAMPLE_INPUT_TOKENS", count.input_tokens, "WITH_OUTPUT", count.input_tokens + body["max_output_tokens"], flush=True)
        # Tento odhad není autorizací odeslání; závazná kontrola proběhne pro finální A2Q.
        selected = [f for f in structure["files"] if f["path"] != "SSOT_CURRENT.md"]
        upper = sum((count.input_tokens * (0.375 if coding_file(f) else 0.25) + 16384 * (2.25 if coding_file(f) else 0.9)) / 1000000 for f in selected)
        save("batch_initial_estimate.json", {"input_tokens": count.input_tokens, "estimated_upper_usd": upper})
        print("BATCH_INITIAL_USD", upper, flush=True)
    elif action == "prepare":
        structure = read("A2Q_validated.json")
        checked, _ = validate_delivery_structure(read("original_value_0.json"), read("original_value_1.json"), structure, "GENERATE")
        assert checked == structure
        old_paths = {f["path"] for f in read("original_value_3.json")["files"]}
        assert old_paths <= {f["path"] for f in structure["files"]}, "Ze specifikace zmizely původní soubory."
        assert all(f["kind"] == "text" for f in structure["files"])
        selected = [f for f in structure["files"] if f["path"] != "SSOT_CURRENT.md"]
        rows = [{"custom_id": f"ID92_MANUAL_A3_{i:05d}", "method": "POST", "url": "/v1/responses", "body": body_for(structure, f, source_id)} for i, f in enumerate(selected)]
        save("batch_rows.json", rows)
        save("batch_expected.json", {r["custom_id"]: f["path"] for r, f in zip(rows, selected, strict=True)})
        save("batch_specification.json", {"source_prompt_hash": digest((ROOT / "original_prompt.txt").read_text(encoding="utf-8")), "requirements": read("original_value_0.json"), "plan": read("original_value_1.json"), "structure": structure, "maximum_quality": True})
        # Každý finální pracovní požadavek dostane vlastní ne-generativní počet tokenů.
        counts = read("batch_token_counts.json") if (ROOT / "batch_token_counts.json").exists() else {}
        pending = []
        for row in rows:
            key = digest(row["body"])
            if key not in counts:
                pending.append((key, row["body"]))

        def count_one(item):
            key, body = item
            counter = client.responses.input_tokens.count(**{k: v for k, v in body.items() if k in ("model", "instructions", "input", "text", "reasoning")})
            return key, counter.input_tokens

        with ThreadPoolExecutor(max_workers=3) as pool:
            for key, count in pool.map(count_one, pending):
                counts[key] = count
                save("batch_token_counts.json", counts)
                print("COUNTED", len(counts), "of", len(rows), flush=True)
        budget = []
        for row in rows:
            body = row["body"]
            count = counts[digest(body)]
            mini = body["model"] == "gpt-5.4-mini"
            assert count + body["max_output_tokens"] <= (400000 if mini else 1050000), "Překročen kontext modelu."
            budget.append({"custom_id": row["custom_id"], "model": body["model"], "input_tokens": count, "max_output_tokens": body["max_output_tokens"], "upper_usd": (count * (0.375 if mini else 0.25) + body["max_output_tokens"] * (2.25 if mini else 0.9)) / 1000000})
        preparation = sum(read(p.name)["reserved_usd"] for p in ROOT.glob("A*_budget.json"))
        total = preparation + sum(r["upper_usd"] for r in budget)
        assert total <= 60, "Celková rezervace překračuje 60 USD."
        raw = "".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n" for r in rows).encode("utf-8")
        assert len(raw) <= 200000000
        (ROOT / "batch_requests.jsonl").write_bytes(raw)
        for model in {row["body"]["model"] for row in rows}:
            model_raw = "".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n" for r in rows if r["body"]["model"] == model).encode("utf-8")
            (ROOT / (model + ".jsonl")).write_bytes(model_raw)
        save("batch_budget.json", {"rows": budget, "preparation_reserved_usd": preparation, "batch_reserved_usd": sum(r["upper_usd"] for r in budget), "total_reserved_usd": total, "jsonl_sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
        print("BATCH_READY", len(rows), "TOTAL_RESERVED_USD", total, "BYTES", len(raw), flush=True)
    elif action == "submit":
        model = sys.argv[2]
        assert model in ("gpt-5.4-mini", "gpt-5.6-luna")
        submission_name = model + "_submission.json"
        assert not (ROOT / submission_name).exists(), "Existuje evidence odeslání; požadavek neopakovat."
        budget = read("batch_budget.json")
        assert budget["total_reserved_usd"] <= 60
        raw = (ROOT / "batch_requests.jsonl").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == budget["jsonl_sha256"]
        rows = [json.loads(line) for line in raw.splitlines()]
        assert len(rows) == len(budget["rows"])
        rows = [row for row in rows if row["body"]["model"] == model]
        raw = (ROOT / (model + ".jsonl")).read_bytes()
        assert [json.loads(line) for line in raw.splitlines()] == rows
        for row in rows:
            validate_response_payload(row["body"], batch=True)
        original_state = json.loads((ROOT.parent / "RUN_130920260322_ID92" / "run_state.json").read_text(encoding="utf-8"))
        source = (ROOT / "original_prompt.txt").read_bytes()
        assert digest(source.decode("utf-8")) == original_state["preparation_snapshot"]["prompt_hash"]
        output = Path(original_state["out_dir"]).resolve()
        destination = output / "SSOT_CURRENT.md"
        assert destination.resolve().parent == output
        if destination.exists():
            assert destination.read_bytes() == source, "Existující SSOT má jiný obsah; nepřepsán."
        else:
            output.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as handle:
                handle.write(source)
        save("completed_local_files.json", {"out_dir": str(output), "files": {"SSOT_CURRENT.md": hashlib.sha256(source).hexdigest()}})
        upload_name = model + "_upload.json"
        if not (ROOT / upload_name).exists():
            upload = client.files.create(file=("ID92_" + model + "_batch.jsonl", raw, "application/jsonl"), purpose="batch")
            save(upload_name, upload.model_dump(mode="json"))
        uploaded = read(upload_name)
        save(submission_name, {"status": "submitting", "input_file_id": uploaded["id"], "jsonl_sha256": hashlib.sha256(raw).hexdigest()})
        batch = client.batches.create(input_file_id=uploaded["id"], endpoint="/v1/responses", completion_window="24h", metadata={"source_run": "RUN_130920260322_ID92", "manual_recovery": "true", "budget_total_usd": "60"})
        save(submission_name, batch.model_dump(mode="json"))
        print("BATCH_SUBMITTED", batch.id, batch.status, flush=True)
    elif action == "poll":
        model = sys.argv[2]
        batch = client.batches.retrieve(read(model + "_submission.json")["id"])
        save(model + "_submission.json", batch.model_dump(mode="json"))
        print("BATCH", batch.id, batch.status, batch.request_counts, batch.errors, flush=True)


if __name__ == "__main__":
    main()
