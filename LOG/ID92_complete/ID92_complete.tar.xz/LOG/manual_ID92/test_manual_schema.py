"""Regrese oddělených kategorií ID bez sítě a provozních podkladů."""
import jsonschema
import pytest

from stage import bounded_structure_format
from batch_prepare import compact_structure


def test_requirement_and_architecture_ids_are_separate():
    req = {"explicit_requirements": [{"id": "EX-001"}], "implicit_requirements": [{"id": "IM-001"}]}
    plan = {"architecture_items": [{"id": "WP-001"}]}
    fmt = bounded_structure_format(req, plan)
    fields = fmt["format"]["schema"]["properties"]["files"]["items"]["properties"]
    jsonschema.validate(["EX-001", "IM-001"], fields["requirement_ids"])
    jsonschema.validate(["WP-001"], fields["architecture_item_ids"])
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(["WP-001"], fields["requirement_ids"])
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(["EX-001"], fields["architecture_item_ids"])
    jsonschema.validate(["lib/index.ts"], fields["dependencies"])


def test_compact_structure_preserves_all_values_and_source():
    source = {"rules": ["Zachovat celé zadání."], "files": [
        {"path": "a.ts", "behavior": "Řádek 1\nŘádek 2", "dependencies": [], "requirement_ids": ["EX-001"]},
        {"path": "b.ts", "behavior": "Unicode: žluťoučký", "dependencies": ["a.ts"], "requirement_ids": ["IM-001"]},
    ]}
    packed = compact_structure(source)
    reconstructed = [dict(zip(packed["file_columns"], row, strict=True)) for row in packed["files"]]
    assert reconstructed == source["files"]
    assert packed["rules"] == source["rules"]
    assert "file_columns" not in source
