"""Ruční pracovní fáze s uloženým ID, kontrolou kontraktu a rozpočtem."""
import json
import sys
from pathlib import Path

from openai import OpenAI

from kajovo.core.delivery_preparation import validate_delivery_structure
from kajovo.core.requirements import enriched_structure_format, stage_instructions
from kajovo.core.secret_store import load_api_key
from kajovo.core.request_rules import validate_response_payload
from kajovo.core.structured_output import validate_output

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def save(name, value):
    target = ROOT / name
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)


def bounded_structure_format(req, plan):
    fmt = enriched_structure_format("GENERATE")
    props = fmt["format"]["schema"]["properties"]["files"]["items"]["properties"]
    # Každé pole má samostatný objekt; původní schema factory sdílí pole řetězců.
    props["requirement_ids"] = {"type": "array", "items": {"type": "string", "enum": sorted({r["id"] for k in ("explicit_requirements", "implicit_requirements") for r in req[k]})}}
    props["architecture_item_ids"] = {"type": "array", "items": {"type": "string", "enum": sorted(a["id"] for a in plan["architecture_items"])}}
    return fmt


def main():
    stage, action = sys.argv[1:3]
    assert stage in ("A2", "A2Q")
    client = OpenAI(api_key=load_api_key(), max_retries=0, timeout=120)
    if action == "prepare":
        req, plan = read("original_value_0.json"), read("original_value_1.json")
        structure = read("original_value_3.json" if stage == "A2" else "A2_validated.json")
        mappings = {a["id"]: set(a["requirement_ids"]) for a in plan["architecture_items"]}
        errors = []
        for file in structure["files"]:
            covered = set().union(*(mappings[a] for a in file["architecture_item_ids"]))
            missing = set(file["requirement_ids"]) - covered
            if missing:
                errors.append({"path": file["path"], "requirements_without_architecture": sorted(missing)})
        context = {
            "source": (ROOT / "original_prompt.txt").read_text(encoding="utf-8"),
            "requirements": req, "plan": plan, "structure": structure,
            "validation_errors": errors,
            "manual_delivery": "Původní SSOT_CURRENT.md bude dodán přesnou lokální kopií source, negeneruj ani nezkracuj jeho obsah. Ostatní soubory budou samostatné úlohy Batch. Zachovej úplný rozsah a všechny cesty; neopakuj requirements ani plán. Oprav všechny vazby požadavků přes architekturu a jejich úplné pokrytí. Žádné formální přidání nesouvisejících vazeb jen kvůli validaci.",
        }
        if stage == "A2Q":
            context["manual_quality_constraints"] = (
                "Vstupní struktura již prošla schématem, kontrolou vazeb i úplností pokrytí. "
                "Zachovej všechny její konkrétní povinnosti v behavior. AC-* jsou akceptační kritéria, "
                "nikoli requirement_ids. requirement_ids obsahují jen explicit_requirements/implicit_requirements ID. "
                "architecture_item_ids obsahují jen ID plan.architecture_items. Pro KAŽDOU položku architektury "
                "musí sjednocení requirement_ids souborů odkazujících na ni pokrýt všechny její requirement_ids. "
                "Každé requirement_id souboru musí být pokryto některou z jeho architecture_item_ids."
            )
        fmt = bounded_structure_format(req, plan)
        body = {
            "model": "gpt-5.4", "instructions": stage_instructions(stage),
            "input": json.dumps(context, ensure_ascii=False, separators=(",", ":")),
            "text": fmt,
            "reasoning": {"effort": "xhigh"}, "max_output_tokens": 90000,
            "background": True, "store": True, "service_tier": "default",
        }
        validate_response_payload(body)
        save(stage + "_request.json", body)
        counted = client.responses.input_tokens.count(**{k: v for k, v in body.items() if k in ("model", "instructions", "input", "text", "reasoning")})
        # Horní rezervace bez slevy za cache, se zvýšenou sazbou dlouhého kontextu.
        upper = counted.input_tokens * 5 / 1000000 + body["max_output_tokens"] * 30 / 1000000
        save(stage + "_budget.json", {"input_tokens": counted.input_tokens, "max_output_tokens": body["max_output_tokens"], "reserved_usd": upper})
        print(stage, "input_tokens", counted.input_tokens, "reserved_usd", upper, "validation_errors", len(errors), flush=True)
    elif action == "submit":
        assert not (ROOT / (stage + "_submission.json")).exists(), "Požadavek už má evidenci odeslání."
        reserved = sum(read(p.name)["reserved_usd"] for p in ROOT.glob("*_budget.json"))
        assert reserved <= 10, "Příprava překračuje vyhrazený rozpočet."
        save(stage + "_submission.json", {"status": "submitting"})
        response = client.responses.create(**read(stage + "_request.json"))
        save(stage + "_response.json", response.model_dump(mode="json"))
        save(stage + "_submission.json", {"id": response.id, "status": response.status})
        print(stage, response.id, response.status, flush=True)
    elif action == "poll":
        entry = read(stage + "_submission.json")
        response = client.responses.retrieve(entry["id"])
        save(stage + "_response.json", response.model_dump(mode="json"))
        save(stage + "_submission.json", {"id": response.id, "status": response.status})
        print(stage, response.status, flush=True)
        if response.status == "completed":
            value = validate_output(response.model_dump(mode="json"), read(stage + "_request.json"))
            save(stage + "_value.json", value)
            validated, additions = validate_delivery_structure(read("original_value_0.json"), read("original_value_1.json"), value, "GENERATE")
            save(stage + "_validated.json", validated)
            save(stage + "_validation.json", {"valid": True, "added_dependencies": additions, "usage": response.usage.model_dump(mode="json")})
            print("VALIDATED", len(validated["files"]), response.usage.model_dump(mode="json"), flush=True)
        elif response.status not in ("queued", "in_progress"):
            print("API_ERROR", response.error, response.incomplete_details, flush=True)


if __name__ == "__main__":
    main()
