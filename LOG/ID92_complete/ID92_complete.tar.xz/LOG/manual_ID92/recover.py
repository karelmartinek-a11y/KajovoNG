"""Ne-generativní obnova pracovních podkladů z existujících odpovědí API."""
import json
from pathlib import Path

from openai import OpenAI

from kajovo.core.secret_store import load_api_key
from kajovo.core.delivery_preparation import digest

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "RUN_130920260322_ID92"


def save(name, value):
    target = ROOT / name
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)


def main():
    client = OpenAI(api_key=load_api_key(), max_retries=0, timeout=60)
    journal = json.loads(next((SOURCE / "manifests").glob("*response_journal*")).read_text(encoding="utf-8"))
    selected = [e for e in journal["entries"].values() if e["status"] == "completed"][-4:]
    for index, entry in enumerate(selected):
        name = f"original_response_{index}.json"
        if not (ROOT / name).exists():
            save(name, client.responses.retrieve(entry["id"]).model_dump(mode="json"))
        response = json.loads((ROOT / name).read_text(encoding="utf-8"))
        texts = [c["text"] for o in response["output"] for c in o.get("content", []) if c.get("type") == "output_text"]
        value = json.loads("".join(texts))
        save(f"original_value_{index}.json", value)
        print("Obnovena odpoved", index, response["status"], value.get("contract"), flush=True)
    if not (ROOT / "original_input_items.json").exists():
        items = [item.model_dump(mode="json") for item in client.responses.input_items.list(selected[1]["id"], limit=100, order="asc")]
        save("original_input_items.json", items)
    items = json.loads((ROOT / "original_input_items.json").read_text(encoding="utf-8"))
    print("Vstupni polozky", len(items), flush=True)
    for index, item in enumerate(items):
        if item.get("role") == "user":
            texts = [c.get("text", "") for c in item.get("content", [])]
            print("Vstup", index, [len(t) for t in texts], [digest(t)[:12] for t in texts], flush=True)


if __name__ == "__main__":
    main()
