# Důkazní základ a konkrétní změnové nálezy

Referenční commit: `c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4` ve větvi `main`. Níže je odděleno přečtené chování zdrojového kódu od cílového návrhu. Dokumentace samotná není důkazem funkčnosti; tvrzení o novém návrhu nejsou tvrzeními, že už byl implementován. Výpis jednotlivých API vlastností má v balíku zdrojové odkazy v `sources.json`.

## F01 — přípravné fáze již nejsou jeden neomezený chat

`prepare_delivery` sestavuje A0R/A1/A2[Q] a B ekvivalenty. Interní A1 a další fáze již nepřipojují předchozí Responses historii; posílají vlastní kanonické podklady. Kandidát při opravě nahrazuje předchozí, počet pokusů je omezený. Návrh toto zachovává. Zbývající problém není prokázaný exponenciální růst ve všech cestách, ale opakování plného zdroje a širokých globálních podkladů i tam, kde může stačit ověřená projekce.

Zdroj: [delivery_preparation.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/delivery_preparation.py), funkce `prepare_delivery`.

## F02 — dobrý FileContext není hotový vícebatchový executor

Současný compiler vybírá relevantní požadavky, interfaces, scoped invariants a přímé závislosti; podporuje verified_artifacts a SCC. Připravený graf ale sám neprokazuje úplnou vykonávací orchestraci vln s ověřenými providery. Nová změna přidává explicitní content_dependencies, scheduler a verifikační podmínky bez posílání všech hotových souborů každému dalšímu souboru.

Zdroj: [context_compiler.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/context_compiler.py), `ContextCompiler.compile`, `dependency_groups`; [generate_batch.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/generate_batch.py), `build_manifest`.

## F03 — A3 už používá jeden úplný soubor

Aktuální LIVE A3/B3 již vyžaduje count=1 a obsahuje omezenou opravnou smyčku. Nelze jej znovu popsat jako původní 500řádkovou transportní smyčku. Navrhovaný FILE_CONTENT_V1 redukuje redundantní modelová metadata; jde o další verzovanou změnu, ne o popis současného drátového kontraktu.

Zdroj: [runs/file_execution.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/runs/file_execution.py), `_gen_file_chunks`; [contracts.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/contracts.py), `file_response_format`.

## F04 — QFILE má stále rozpornou prose instrukci

QFILE sestavuje inline ukázku s chunk_count=0 a max500 řádky, a přitom skutečný request používá jednorázové count=1 schéma. Ve stejné funkci se opakují IO referenční instrukce. Nová cesta QFILE_PLAN → FILE_CONTENT tento rozpor odstraní, zamkne cestu mimo modelový obsah a zachová podporu samostatného souboru bez zbytečného celého GENERATE.

Zdroj: [runs/qfile.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/runs/qfile.py), `_run_qfile`.

## F05 — kaskáda: dvě reprezentace stejného JSON

V deterministické větvi kaskády instrukce požaduje JSON serializovaný do textového řetězce. Současně se podle context_id může připojit historie, ačkoli je výstup předchozího kroku vložen explicitně přes binding. Nový typovaný DSL a rozlišení artifact/conversation zabrání nechtěnému dvojímu předání. Stávající dopředné rozhodování a kontroly dominance se zachovávají; není doložena potřeba zavádět libovolné zpětné smyčky.

Zdroj: [cascade_pipeline.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/cascade_pipeline.py), `_resolve_deterministic_inputs`, `_deterministic_instructions`, `_prepare_step`; [cascade_contract.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/cascade_contract.py), `_dominators`, `resolve_decision_targets`.

## F06 — katalog modelů již existuje, musí být společný

Současný model_registry již filtruje konkrétní usage a preferuje doporučené modely. ModelCatalogCache byla přidána před tímto návrhem. Změna ji nerozmnožuje do druhé nezávislé databáze capability: sjednocuje account scope, obnovu, frozen run snapshot a všechny UI volby včetně komiksu a kaskád. Účtová dostupnost GET /models sama nedokazuje všechny capability konkrétního modelu.

Zdroj: [model_registry.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/model_registry.py), `models_for_usage`; [studio/context.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/studio/context.py).

## F07 — fotografie: dekodér je nutný, nikoli obsahový důkaz

Photo Batch už skutečně dekóduje obraz a ověřuje formát/rozměry. Současně jsou různé části politik odvozené z názvu modelu a fotografie mají jinou obecnou vstupní mez než společný comic image runtime. Nový návrh předepisuje jednotnou capability matici, neměnný pracovní asset před uploadem, explicitní obrazový kontrakt a zvláštní vizuální posouzení. Originální soubor se nikdy nepřepíše.

Zdroj: [photo_batch.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/photo_batch.py), `make_items`, `image_edit_options`, `inspect_photo_bytes`; [image_runtime.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/image_runtime.py).

## F08 — komiksové reference: index až po deduplikaci

`compile_panel` přiřazuje image_index během sběru entit a poté deduplikuje seznam assetů. Pokud několik rolí odkazuje na stejný asset, index se může od skutečně odeslaného pořadí odchýlit. Předepsaná oprava nejprve vytvoří stabilní unikátní seznam assetů a až následně mapuje každou roli/entity na jeho slot. To musí být kryto testem jedné reference použité ve dvou rolích.

Zdroj: [comic_service.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/comic_service.py), `compile_panel`.

## F09 — komiksová bible a ruční panely nejsou celý příběh

Současný ComicService připravuje bibli, descriptory, reference a ručně zadané panely. Nová narrative cesta je skutečná produktová změna: outline → script → storyboard → continuity → panely. Zachovává se ruční editor, lokální sazba bublin a verzování. Normalizace explicitních stylistických voleb nemá přepsat podrobné generované pravidlo jedním krátkým slovem; dvě vrstvy se uloží odděleně.

Zdroj: [comic_service.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/comic_service.py), `start_bible`, `_entity`, `start_panels`; [comic_types.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/comic_types.py), `normalize_bible`.

## F10 — limity existují, univerzální finanční ledger je nová změna

context_budget již počítá komponenty a kontroluje kapacitu. Nejde však o atomický souběžný peněžní limit všech typů práce. Nový ledger se musí vztahovat i na foto, komiks, kaskádu, vlastní schéma a repair. Rezervace celého Batch se provede dříve než submit; neznámá cena nebo neznámý výsledek submitu nesmějí být nula.

Zdroj: [context_budget.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/context_budget.py); [comic_service.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/comic_service.py), `text_request`; [photo_prompt.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/photo_prompt.py).

## F11 — nástroje vyžadují nový mezistavový classifier

OpenAIClient dnes obvykle ověřuje finální structured output hned po synchronním návratu; request_rules povoluje především file_search a zprávy. Pro nové custom read nástroje se musí explicitně podporovat function_call/function_call_output a nesmí se zaměnit tool request za vadný finální JSON. Nové tools jsou pouze čtecí; model nesmí dostat obecný shell ani zápis do hostitelského filesystemu.

Zdroj: [openai_client.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/openai_client.py), `create_response`; [request_rules.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/request_rules.py).

## F12 — finální produkt musí mít doložený rozsah ověření

Souborový kontrakt a bezpečný zápis nedokazují build, testy ani správné UI chování vygenerované aplikace. Návrh vyžaduje sandbox a konkrétní VerificationReport, ne přejmenování dosavadního files_complete_unverified na completed. Ve vizuálních procesech odděluje technickou integritu, modelové posouzení a lidské schválení.

Zdroj: [runs/generate.py](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/kajovo/core/runs/generate.py); [docs/SSOT.md](https://github.com/karelmartinek-a11y/KajovoNG/blob/c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4/docs/SSOT.md).

## Co tento průchod neprokazuje

Nebyly provedeny nové placené provider requesty ani runtime ověření uživatelova účtu. Přečtení kódu není totéž jako vykonání aplikace. Nálezy v tomto dokumentu jsou svázané s referenčním commitem; při změně HEAD je nutné znovu porovnat dotčené call sites. Oficiální dokumentace API se ověřuje při zavedení capability profilu, ne domněnkou podle názvu modelu.