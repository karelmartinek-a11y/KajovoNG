# KájovoNG — závazné změnové zadání

**Verze návrhu:** 1.0.0 · **Základ zdrojového kódu:** `c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4` · **Výstup tohoto balíku:** specifikace, kontrakty, referenční algoritmy a offline kontroly. Nejde o tvrzení, že je navrhovaná úprava již implementována v KájovoNG.

## 1. Rozsah, autorita a význam záruky

Upravit všechny placené generativní cesty: GENERATE, MODIFY, QA, QFILE, uživatelské kaskády, přípravu jejich schémat, profesionalizaci fotografického zadání, úpravy fotografií, komiksovou bibli, entity, nové příběhy, scénáře, storyboardy, referenční obrazy, panely a jejich opravy. Zahrnout také katalog modelů, přílohy, retrieval, dávky, historii, pokračování, účetní evidenci, ověření a publikaci výsledků. Zdroje, Git, diagnostika, nastavení, oznámení a převod textů jsou podpůrné procesy a nesmějí získat skryté generativní volání.

Programátor nesmí samostatně změnit produktovou politiku, počet automatických pokusů, způsob výběru modelu, schéma ani kritérium úspěchu. Změna těchto pravidel je nová verze příslušného kontraktu/policy s aktualizovanými testy. Nejasnost v implementaci se řeší proti autoritativním souborům tohoto balíku, nikoli improvizací v promptu.

**Zaručitelné vlastnosti jsou vlastnosti orchestrace:** neodeslat nedovolený požadavek, nepřevzít neúplný výsledek, nepřekročit schválenou lokální rezervaci, neopakovat automaticky neurčitý submit, neztratit originál a nevydávat neověřený výsledek za ověřený. Nelze zaručit bezchybnost libovolného zdrojového kódu, dokonalou vizuální shodu ani dostupnost služby pouze schématem či návrhem. Proto je závazným výsledkem při nesplnění podmínek bezpečné zastavení s důkazem, nikoli předstírané dokončení. Ověření vždy platí jen pro uvedený profil, přesnou verzi artefaktů a prostředí.

Pořadí autority uvnitř balíku: (1) tento dokument a explicitní rozhodnutí v `docs/01_ROZHODNUTI.md`, (2) doménové specifikace `docs/workflows/`, (3) schémata, policy a stavové stroje, (4) akceptační katalog, (5) příklady. Rozpor mezi úrovněmi je chyba balíku a blokuje implementaci dotčeného bodu; příklad nesmí oslabit normativní pravidlo. Machine-readable hodnoty limitů jsou autoritou pro čísla, dokumenty vysvětlují jejich význam. `reference/` obsahuje spustitelné referenční algoritmy, nikoli náhradu produkční integrace.

## 2. Jedenáct cílů a podmínky jejich přijetí

| ID | Cíl | Mechanismus | Důkaz přijetí |
|---|---|---|---|
| G01 | Přesný vstup každého kroku | SourcePack, typovaný input contract, projekce a zmrazený WorkOrder | Žádný submit bez ověřené projekce a hashů; test chybějícího vstupu nevolá transport |
| G02 | Výstup použitelný následujícím krokem | Strict wire schema, sémantická brána, producer/consumer typová kompatibilita | Každá povinná vazba má existujícího producenta a validovaný artefakt |
| G03 | Odmítnutí neúplného výstupu | Klasifikace provider status/refusal/tool call, validace, staging | Incomplete, refusal, chybné vztahy a neplatný obraz nikdy neotevřou další závislý krok |
| G04 | Kvalitní LIVE příprava | Role modelů, capability snapshot, zmrazená schválená volba | A0R/A1/A2/B0R/B1/B2 se neodešlou jako produkční BATCH a model se tajně nesníží |
| G05 | Ekonomická dávková výroba | Samostatné A3/B3, skupiny model+endpoint+wave, targeted repair | Nezávislé soubory jdou paralelně; oprava jedné položky nepřegeneruje celek |
| G06 | Konečný růst kontextu | Nové kontexty mezi etapami, žádné vnořené snapshoty, omezené opravy | Test počtu vstupních komponent při opakování nezvyšuje počet historických kandidátů |
| G07 | Jen potřebná data | Sémantické reference, povinnosti s vlastníkem, deduplikace podle identity | Každá odeslaná komponenta má původ a důvod; duplicity bez role jsou odmítnuty |
| G08 | Placená historie je přiznaná | Explicitní conversation mode, měření celé historie | `previous_response_id` nikdy neznamená nulové vstupní tokeny |
| G09 | Účelné využití OpenAI API | Responses pro text/vision, native Image pro obraz, strict schema, cache, background, token count | Každá cesta má konkrétní povolené endpointy/parametry; nepodporované funkce se neposílají |
| G10 | Auditovatelnost | Ledger rezervací a spotřeby, request identity, immutable evidence | Polling nepřičítá usage znovu; náklad neznámý není nula |
| G11 | Pravdivý finální stav | Verification profiles a oddělené výsledky reviewed/verified/unverified | `completed_verified` vyžaduje všechny povinné důkazy k přesnému finálnímu snapshotu |

Úplné vazby cíl → akceptační případ jsou v `acceptance/catalog.json`. Nestačí počet unit testů, coverage ani ukázková odpověď modelu.

## 3. Závazná architektura

Zavést jedinou společnou cestu `WorkflowAdapter → WorkOrderBuilder → ContextProjection → PayloadBuilder → BudgetGate → RequestJournal → ProviderTransport → ResponseClassifier → ContractRegistry → ArtifactStore → Verification → Publication`. Stávající obrazovky a doménové služby jsou adaptéry. Nesmějí si vytvářet druhý paralelní klient, vlastní retry smyčku ani vlastní alternativní definici úspěchu.

`ProviderTransport` vrací surovou poskytovatelskou obálku bez předčasné interpretace jako finální JSON. `ResponseClassifier` nejdříve rozliší průběžný stav, dokončenou odpověď s tool callem, finální text, refusal, incomplete, chybu a neznámý stav. Teprve finální text bez čekajícího tool callu vstupuje do `ContractRegistry`. Tato změna je nutná, protože současná centrální validace textu by jinak odmítala legitimní tool-calling krok.

Stávající `OpenAIClient`, `ResponseJournal`, `RunLogger`, `ComicStore`, `ContextCompiler` a autoritativní modelová matice se nezahazují. Přesná mapa integrace je v `migration/file_map.json`. Nové orchestration moduly musí být nezávislé na Qt. UI komunikuje přes immutable příkazy a události. Doménové tabulky komiksu zůstanou autoritou pro projekty/entity/panely; společný ledger ukládá odkazy, nikoli druhou kopii knihovny.

## 4. Datové vrstvy a identita

### 4.1 Originály

Originální soubor nebo uživatelský text je immutable byte artefakt. Hashovat přesné bajty. Neměnit diakritiku, konce řádků, Unicode normalizaci ani pořadí při ukládání zdroje. Textová interpretace a normalizovaný obraz jsou odvozené artefakty s vlastním hashem a vazbou na originál. Změna souboru po schválení nesmí změnit odesílaný obsah: použít zmrazenou kopii, nikoli znovu otevřenou cestu v pracovním adresáři.

### 4.2 Kanonické objekty

Kanonický JSON: UTF-8 bez BOM, `ensure_ascii=false`, klíče lexikograficky seřazené, oddělovače `,` a `:`, žádné NaN/Infinity, žádné duplicitní klíče. Doménové seznamy zachovávají pořadí, pokud kontrakt nestanoví množinu; množiny ID se třídí před kanonizací. Peníze jsou celá čísla v mikroUSD, nikoli float. ID běhu/úlohy/pokusu vytváří aplikace. Model nesmí rozhodovat o request ID, cestě zápisu, oprávněních ani stavu rezervace.

### 4.3 Pracovní kontext

Kontext je deterministická projekce z kanonických podkladů. Pro každou komponentu ukládat `{artifact_id, sha256, selector, role, reason}`. Auditní metadata, všechny předchozí odpovědi, globální snapshot a diagnostické přílohy se automaticky nepřibalují. Deduplikace se provádí podle identity zdrojové komponenty a role; dva stejné textové řetězce v různých významových rolích se nesmějí bez důvodu zahodit.

### 4.4 WorkOrder

Před prvním započítaným requestem zmrazit cílový artefakt, model, capability hash, prompt hash, schema hash, effective input hash, schválení a očekávanou revizi cíle. Nepoužívat jako jedinou identitu provider `response_id`; to vzniká až po submitu. Jeden WorkOrder může mít nejvýše tři placené pokusy podle policy. Změna scope/modelu/zdrojů je nová úloha v lineage, ne přepsání původního requestu.

## 5. Schémata a sémantická brána

Wire kontrakty jsou v `contracts/wire/`. Každý objekt má povinná všechna definovaná pole a `additionalProperties:false`. Rozlišující varianty jsou vnořené `anyOf`, ne nekontrolovaný generický slovník. Většina plánovacích kontraktů používá obálku `result` s variantou `ready/data` nebo `blocked/questions`. `blocked` není porušením schématu a nesmí vyvolat tři pokusy o vymyšlení chybějící odpovědi. Uložit otázky a přejít do čekání na zadání.

`FILE_CONTENT_V1` obsahuje výhradně `content:string`. Cesta a akce jsou v důvěryhodném WorkOrder. Schéma se nesmí doplňovat v každé obrazovce jinak. Starý A3/B3 se čte odděleným legacy adaptérem. QFILE smí navrhnout jméno pouze samostatným plánovacím kontraktem a před zápisem musí být jméno aplikací/uživatelem schválené.

**Dvě různé množiny kontrol:** wire schema určuje tvar a lokální omezení hodnot. Sémantický validátor kontroluje vztahy k jiným artefaktům, úplnost povinností, oprávnění a skutečnou dostupnost zdrojů. Není cílem předstírat, že samotné JSON Schema dokazuje sémantickou správnost. Parity test znamená, že obě vrstvy nemají rozporná pravidla stejného lokálního pole; referenční integrita a výsledná funkčnost jsou záměrně další brány.

Každá chyba nese stabilní kód, fázi, JSON pointer, očekávání, stručný pozorovaný stav a hash úplného důkazu. Do promptu se neposílá celé exception traceback, pokud obsahuje nesouvisející data či credential. Chyby třídit podle pointer+code, vrátit nejvýše 50 nejbližších příčin; plný seznam zůstává lokálně. Zkrácení diagnostiky nesmí odstranit požadavek z kanonického registru.

## 6. Výstup není zadání pro nový produkt

A0R má doplnit odborně nezbytné implicitní požadavky, ne neomezeně rozšiřovat produkt. Každý odvozený požadavek musí uvést `derived_from` a konkrétní `necessity`; nesouvisející funkce je blokující scope drift. A1 již nepřepisuje requirements do dalšího dlouhého seznamu. A2 přiřazuje implementaci a rozhraní. A3 pouze implementuje schválený kontrakt. Nový produktový požadavek v A3 je chyba a eskaluje na A0R pouze po novém schválení.

Každý explicitní požadavek má cestu do akceptace; každá povinná akceptace má způsob ověření. Čistě grafová dosažitelnost však nedokazuje, že model text správně pochopil. U důležitých zadání se vyžaduje kontrola lidského scope snapshotu nebo nezávislý obsahový review. Uživatel může takové schválení udělit předem konkrétnímu snapshotu; nesmí být fingováno checkboxem nastaveným modelem.

## 7. LIVE, BATCH a změna modelů

Přípravné etapy GENERATE a MODIFY jsou LIVE. Je možné skončit po validované přípravě stavem `plan_ready`, zavřít aplikaci a později vybrat A3/B3 LIVE nebo BATCH bez opakovaného placení přípravy. Export/import tohoto checkpointu obsahuje úplné kanonické podklady, jejich verze a hashe; nikoli pouze OpenAI ID s omezenou retencí.

Modely pro A0R/A1/A2 a B0R/B1/B2 se vybírají podle rolí. MODIFY dostane stejné oddělení přípravy a výroby jako GENERATE. Změna výrobního modelu před odesláním je nová autorizace a nové měření, ne opakovaná syntéza requirements. Žádný model se za běhu tajně nenahradí. Doporučení pro nové zadání je viditelné UI pravidlo; zamítnutí poskytovatelem není důvod automaticky utratit peníze u jiného modelu.

BATCH není konverzace. Řádky jsou samostatné, bez `previous_response_id`, `conversation`, `background`, `tools` a live `service_tier`. Každá skupina má právě jeden endpoint, model a wave. Úspěch dávky neznamená úspěch každé položky. Výsledky se mapují jen podle `custom_id`, nikdy podle pořadí řádků.

## 8. Kontext a cena

V přípravných etapách současného main již není interní `previous_response_id`; to se zachová. Znovu připojit plný originál do čtyř etap je opakovaný lineární náklad, nikoli samo o sobě exponenciální růst. Změna má odstranit nepotřebné opakování, nikoli tvrdit, že současný kód všude rekurzivně kopíruje historii.

Pro příliš dlouhý SourcePack použít konečnou mapovací extrakci po přesných segmentech; žádná placená potvrzení přijetí. Žádné rekurzivní shrnování shrnutí. Když se ani úplný registr normativních faktů nevejde do schváleného plánu, přejít do `scope_partition_required`, ponechat všechny zdroje a vyžádat rozdělení úlohy. Tento stav nesmí být vydáván za chybu API ani za hotové zadání.

Rozpočet zahrnuje všechny placené kroky včetně review, oprav, automaticky navrhovaných schémat a obrazů. Společná SQLite transakce rezervuje rozpočet před souběžným submitováním. U neznámého výsledku submitu se rezervace neuvolní. Před celou dávkou se rezervuje součet, ne pouze první položka. Hard USD záruka se může vztahovat jen na známý a platný ceník/route/tier; neznámá cena je `null`, nikoli nula. Token-only režim vyžaduje samostatné výslovné schválení rizika neznámé ceny.

Maximální výstup obsahuje viditelný text i reasoning. `max_output_tokens` není cílová délka a celý limit není automaticky účtován, ale je základem konzervativní rezervace. Výstupní limit se stanoví podle `policies/budgets.json`, ne univerzálně na maximum modelu. Překročení modelové kapacity se neřeší useknutím zadání.

## 9. Přesně jeden automatický submit, nikoli falešné exactly-once

Pro každou placenou mutaci nejdříve transakčně zapsat `submitting`, persistentní attempt ID, hash requestu a rezervaci. SDK retry je nula. Po potvrzeném ID pokračovat jen retrieval/polling. Pokud není známé, zda server operaci přijal, stav je `submission_unknown`; žádný automatický nový submit. U Batch se použije úplně stránkovaný seznam a přesná korelace input_file_id+endpoint+model, právě jedna shoda. Nulová shoda krátce po výpadku není důkaz, že nic nevzniklo. Responses/Image bez doloženého lookupu zůstávají blokované, dokud uživatel výslovně neschválí riziko duplicitní nové operace.

Hlavička X-Client-Request-Id je korelační identita, ne obecná záruka idempotence. Falešná hlavička Idempotency-Key se bez ověřené podpory endpointu nepřidává. Stejný GET stav nezvyšuje počet generací ani spotřebu. Stop zastavuje místní sledování; cancel je odlišná vzdálená operace, úspěšná až po potvrzení služby.

## 10. Ověření, staging a publikace

Výsledky nejdříve uložit do immutable stagingu. Vstup do dalšího kroku je povolen jen po příslušné bráně. Technicky platný soubor není automaticky funkční aplikace a platný PNG není automaticky správně upravená fotografie.

Ověření programu se spouští pouze v administrátorem připraveném sandboxu s digestem image, bez hostitelských tajemství, bez síťového přístupu ve výchozím stavu a bez připojení Docker socketu. Model nesmí volit argv. Nedostupný sandbox nebo nepodporovaný stack znamená `completed_unverified` nebo blokující ověření podle schváleného cíle; nesmí se spustit nebezpečný fallback na hostiteli. Testy mohou být chybným generovaným kódem, proto samotné přepnutí na allowlisted `pytest` neodstraňuje potřebu izolace.

Publikace do OUT se provede až po akceptaci nebo po výslovně označeném převzetí neověřených artefaktů. Existující soubory se přepisují pouze s odpovídajícím expected hash. Konflikt znamená `publish_conflict`, nikoli destruktivní přepsání. MODIFY zachová původní obsah i nedotčené soubory; dry-run nikdy nezmění OUT.

## 11. Zakázaná zjednodušení

Nesnižovat coverage limity, neignorovat vadné položky, nepřeklasifikovat chybu na warning, nenahrazovat chybějící data falešným obsahem, nevyrábět baseline build/test důkaz z mocku, nespouštět generativní kontrolní sondy, nepřepisovat legacy evidence, nezasílat celou historii každému souboru, nepovažovat hash za důkaz odborné správnosti, nevyžadovat lidské rozhodnutí o interní implementační variantě, která je zde určena. Lidské rozhodnutí je potřebné pro produktový scope, útratu, oprávnění a skutečnou nejednoznačnost zadání; to nejsou volné technické volby implementátora.

## 12. Dodání implementace

Programátor dodá změny zdrojového kódu, migrace, testy, aktualizované SSOT/REQUEST_MATRIX/CONTEXT_COMPILER a přehled ověřovacích výsledků. Zdrojovou větev/main před zahájením načte znovu a změny od uvedeného SHA vyhodnotí podle `migration/README.md`; nesmí slepě přepsat cizí práci. Tento balík neobsahuje provozní credential, fonty ani soukromé runtime logy.

Akceptace vyžaduje zvlášť: (a) offline invarianty a CI, (b) ručně autorizované malé LIVE a LIVE→BATCH běhy, (c) programové ověření finální aplikace, (d) technickou a obsahovou kontrolu obrazů. Zelené CI bez těchto důkazů není certifikát funkčnosti produktu. Seznam přesných případů a očekávaných důkazů je v `acceptance/README.md`.