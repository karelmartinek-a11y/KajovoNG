# Kontext, modelové parametry, útrata a volání OpenAI

## 1. Kanonický model požadavku

Request se skládá pouze z registru kontraktu, instrukcí konkrétní fáze, schváleného modelového profilu a deterministického pracovního vstupu. `examples/requests/` obsahuje úplné offline vzory včetně skutečně vložených schémat, nikoli fragmenty s `schema:{}`. Identifikátory `file_demo_*` a `resp_demo_*` jsou výslovně testovací reference a nemají se odesílat produkčně.

Text/vision LIVE: `POST https://api.openai.com/v1/responses`, Authorization pouze z paměti, `Content-Type: application/json`. Povolená základní těla: `model`, `instructions`, `input`, `text.format`, `max_output_tokens`, `truncation`, `store`, `background`, `metadata`. Sampling vynechat, pokud capability zakazuje kombinaci s effort. `reasoning.effort` vložit jen pro reasoning model. `reasoning.summary` není potřebná pro splnění úlohy a standardně se neposílá. `stream` vynechat/false; tato změna nezavádí druhou streamovací transportní implementaci.

Pro dlouhé LIVE úlohy `background:true,store:true`. `background` u Responses je boolean; stejnojmenné pole Image API je naproti tomu enum pozadí obrazu, např. `opaque`. Tyto dvě masky se nesmějí sdílet. Batch Responses tělo vynechá `background` a `stream`, používá `store:false`. Návrat `completed` z Image endpointu nemá Responses schéma; klasifikátor musí být route-specific.

`metadata`: nejvýše 16 textových dvojic, klíč do 64 znaků, hodnota do 512 znaků. Ukládat jen `run_id`, `task_id`, `attempt_id`, `contract`, `work_order_hash`, `policy_version`. Žádný uživatelský zdrojový kód či přístupový token. Hodnota hash je úplný SHA-256, nikoli popis modelu.

## 2. Přesný postup sestavení před submit

1. Vyhodnotit schválení a deadline bez síťové generace.
2. Zafixovat explicitní model ID a capability snapshot. Ověřit požadovanou route, input modality, output schema a parametry.
3. Načíst celý požadovaný set artefaktů dle hashů. Selhání hashové kontroly blokuje; nesmí se použít jiná kopie jen proto, že má stejné jméno.
4. Zkonstruovat projekci. Ověřit všechny required komponenty a semantickou vazbu ID.
5. Vytvořit wire schema a prompt. Žádné programové výpisy z předchozích candidate nejsou implicitně přidány.
6. Doplnit finální transportní flags a metadata. Až poté měřit a hashovat request; následná mutace by zneplatnila rozpočet.
7. Spočítat aktuální input a output rezervu. Neznámé multimodální/historické složky nejsou nula.
8. Atomicky rezervovat rozpočet run+lineage, teprve potom zapsat submit intent a odeslat.
9. Po návratu uložit raw obálku a usage, klasifikovat, validovat, vytvořit kanonický artefakt nebo explicitní blokaci.

## 3. SourcePack a dlouhé vstupy

Segmentace je byte přesná: zdrojový UTF-8 text rozděl do intervalů `[start_byte,end_byte)`, nejvýše 65 536 bajtů; hledej konec řádku směrem zpět v posledních 4 096 bajtech a jinak poslední hranici kódového bodu. Žádné segmenty nevynechat, mezery a konce řádků patří do pokrytí. ID `SEG-000001` se přidělují podle pozice ve zmrazeném zdroji. Před segmentací validovat UTF-8; jiné kódování vyžaduje explicitní zvolený lokální dekodér a evidenci odvozených bajtů.

Když se A0R vejde do schváleného input budgetu, pošli původní text jednou v tomto requestu. Segmenty slouží jako zdrojové reference; nevkládej současně celý text i jeho jednotlivé segmenty.

Když se nevejde, rozděl segmenty do nejvýše 128 skupin s limitem 24 000 naměřených input tokenů na skupinu a vyvolej skutečnou obsahovou extrakci SOURCE_EXTRACT. Každá skupina má přesné segmenty, žádný překryv. Hraniční kontext může být sdílená navigační informace, ale nesmí být označen za nové normativní zdroje ani vytvořit duplicitní requirement. Výsledky jsou `SOURCE_FACTS_V1`; neztrácej původní dokument. Lokálně spoj fakta do registru; duplicitní explicitní obsah sjednoť pouze při stejných source_refs nebo po schválené sémantické ekvivalenci, nikoli fuzzy podobností.

A0R syntetizuje tento registr. Pokud se celý registr nevejde, neprováděj shrnutí shrnutí. Vrať `SCOPE_PARTITION_REQUIRED` se seznamem nepokrytých skupin. Takové omezení je úmyslný bezpečnostní a nákladový bod; implementátor nesmí předstírat, že libovolně velký projekt jde vždy uzavřít v jednom kontextu.

## 4. Prokázané versus předpokládané pokrytí

Byte coverage ověřuje, že se neztratil úsek zdroje. ID coverage ověřuje existenci vazeb. Ani jedna neprokazuje úplné porozumění lidskému požadavku. `semantic_coverage` je zvláštní review status, s uvedením člověka nebo konkrétního modelového posouzení. Source refs vygenerované modelem jsou vždy ověřeny proti reálným intervalům. Neexistující reference není dovolena jen proto, že odpověď splnila wire schema.

Při přechodu A0R→A1 jsou požadavky závazným pracovním vstupem. Původní zdroj je podle přesných refs dohledatelný a nejednoznačné části se explicitně přiloží. Dokud `semantic_coverage` nemá přijatelný důkaz podle schváleného quality policy, lze plný zdroj zachovat jednou i v další přípravě; musí být přiznán jeho náklad. Nikdy současně explicitní celý zdroj a serverová historie obsahující tentýž zdroj.

## 5. Kontextový režim

`artifact` je výchozí režim pro všechny výrobní etapy a mezikrokové transformace. Má čistý request bez `previous_response_id`/`conversation`; předává jen schválené projekce. A3 neobsahuje plný source pack, requirements ani architecture registry, ale konkrétní vybrané povinnosti a interfaces.

`conversation` je výslovná volba pro QA nebo uživatelskou kaskádu. V rámci jedné lane má request předchozí Response ID a pouze nové input položky. Instrukce se posílají znovu pro každý request. Přenos celé historie plus její explicitní kopie je zakázaný. Kontextová lane nesmí automaticky měnit model; jiný model vyžaduje novou lane a explicitní artefaktovou projekci.

Krátká tool sekvence je conversation jen uvnitř jednoho tasku; celkem nejvýše 4 Response generace a 8 custom tool calls. Tyto generace jsou zahrnuty do limitu placených requestů a zvlášť od strukturálních oprav. Vyčerpání turn limitu znamená `TOOL_TURN_LIMIT`, nikoli nový nezapočtený task. Nekombinovat repair loop × tool loop neomezeně: jedno task má absolutní strop 6 placených Response generací včetně všech oprav a tool pokračování, tento strop má přednost před dílčími limity.

Před novým conversation turnem měřit input včetně historie. Po expiraci provider objektu je možné vytvořit fresh request z uložených schválených artefaktů; důkaz musí říkat `context_rebuilt`, ne předstírat nepřerušenou paměť. Pokud původní informace nejsou dostupné, blokovat. Žádná automatická sémantická kompakce, která by mohla ztratit závazný požadavek. OpenAI compaction lze přidat až jako samostatně specifikovaný a testovaný adapter; v této změně se nepoužívá jako nosič SSOT.

## 6. Výstupní a vstupní rezervy

Výpočet pro text: `O = ceil(1.5 * V) + R + 1024`, kde V je schválený odhad viditelného výstupu a R reasoning rezerva z policy. V A3/B3 se V čte z konkrétního file_spec; ve fázi DETAIL není autoritou odhad jiného souboru. `O` nesmí překročit menší z doloženého limitu modelu a provozního maxima 98 304. Pokud nestačí, před submit vyžaduj menší odpovědnost nebo explicitně schválenou vyšší policy, nikoli tiše nižší reasoning.

Reasoning model: z pořadí `none,minimal,low,medium,high,xhigh,max` vybrat nejnižší podporovanou úroveň nejméně cílové. Když žádná taková není, model je pro daný profil nekompatibilní. Maximum Quality volí nejvyšší doloženou podporovanou úroveň a změří s ní nový rozpočet. Non-reasoning model pole reasoning vynechá. `temperature` a `top_p` výchozí orchestrace neposílá; uživatelská kaskáda smí poslat temperature pouze když to dovoluje modelová kombinace. Neodvozovat determinismus z temperature=0.

Celková kapacita: `I_safe + O + ceil(0.10 * context_window) + retrieval_reserve <= context_window` a `I_safe <= max_input_tokens` a `I_safe <= stage_input_hard_limit`. Retrieval rezerva je 8 192 tokenů při povoleném file_search; je to rezerva, ne přesně změřený budoucí výsledek. Při nulových tools se nepřičítá. O output tokeny se reasoning nepřičítá druhýkrát.

`max_output_tokens` po `incomplete/max_output_tokens` lze nejvýše dvakrát zvětšit na `ceil(1.5*old)`, jen do limitu a se schválenou volnou rezervou. Každý pokus vrací celý soubor od začátku. Když problém není způsoben výstupním limitem, zvýšení limitu není opravou. Výstupní useknutý JSON se neskládá naslepo.

## 7. Měření tokenů

Čistý text se měří doloženým tokenizerem pro přesný model, je-li k dispozici; fallback bytes/3 je pouze odhad. Konzervativní byte upper bound může bezpečně povolit malý request, nikoli prohlásit přesný billing. U příloh, image, remote history a lokálního odhadu blízkého 70 % limitu je povinný `POST /responses/input_tokens` s projekcí parametrů dovolených endpointem. Výsledek musí být svázán s hashem obsahově relevantních request polí a modelem. Metadata a background flags nesmějí způsobit použití měření jiného obsahu; plný WorkOrder hash se ukládá zvlášť.

Token counting je ne-generativní operace, nikoli placený modelový probe. Cenu endpointu není dovoleno v aplikaci vymýšlet; případný provozní náklad se eviduje odděleně od inference. Cache výsledku měření má 24 hodin a klíč zahrnuje model, vstup, instrukce, schema, nástroje i historii. Chybějící/neshodné měření u povinné přesné větve blokuje submit.

## 8. Cache

Výchozí optimalizace využívá automatickou provider cache a stabilní prefix. Instrukce fáze jsou na začátku a nemění se kvůli path/RunID. Dynamická data jsou v input. `prompt_cache_key` je tenant-scoped hash model+stage+schema+promptverze. Cache neukládá uživatelské odpovědi aplikace pod cizí tenant. `prompt_cache_options` z předchozího návrhu není povinný parametr: v této změně je vypnutý. `prompt_cache_retention:in_memory` je povoleno pouze s doloženou capability, jinak se vynechá ještě před schválením payloadu. Neposílat současně dva různé mechanismy řízení cache.

Cache není bezplatná paměť a nemění limit kontextu. Rezervace nákladu předpokládá cache miss. Až skutečné `usage.input_tokens_details.cached_tokens` dovolí vykázat konkrétní cache úsporu. Chybějící pole je unknown, ne vymyšlený hit. Neprovádět placené warmup requesty a neposílat padding pouze pro dosažení cache threshold.

## 9. Finanční ledger

Před během uživatel schválí max útratu, max input/output tokeny, max počet generací a povolení oprav. Výchozí UI návrh 25 USD není automatická autorizace. Předpokládaný cost se počítá z platného verzovaného ceníku a konkrétní route/tier; Batch sleva se neaplikuje na LIVE přípravné a review requesty. Neznámé cenové údaje se neodhadují názvem rodiny. Snapshot ceníku starší než sedm dní vyžaduje obnovení nebo explicitní uznání nejistoty před novou útratou.

SQLite transakce kontroluje `spent + active_reservations + proposed_reservation <= approved_limit` zároveň pro run i lineage. UNIQUE WorkOrder hash zabraňuje dvojité lokální rezervaci. V případě neznámé ceny default blokuje; explicitní token-budget režim může omezit objem, nikoli slibovat přesnou cenu v USD. V UI musí zůstat údaj Cena není známa.

Provider usage je idempotentní po `(provider, response_or_item_id)`. Request count a polling count jsou různé metriky. `output_tokens` již zahrnuje reasoning, `reasoning_tokens` se zobrazuje jako rozpad, nikoli přídavek. Image usage může mít jinou strukturu a pricing než text; normalize do route-specific záznamu, nikoli bez ověření násobit textovou sazbu.

Nejistý submit ponechá rezervaci `unknown` až do zjištění výsledku nebo ruční účetní reconciliace. Po explicitním odmítnutí serverem bez provedení lze rezervaci uvolnit; po časovém limitu nikdy automaticky. Skutečný náklad překračující rezervaci není záporná volná kapacita: zablokovat další mutace a uvést `BILLING_VARIANCE`, ne upravit minulá data.

## 10. Metriky růstu kontextu

Ukládat pro každý request velikost instrukcí, schema, pracovních artefaktů, originálů, historie, retrieval a opravné diagnostiky. Denominátor amplification používat jen pro známý korpus: součet skutečných input tokenů / tokeny unikátních explicitních komponent. Tokeny jedinečných komponent nejsou aditivně identické s tokenizací spojeného promptu; metriku označit jako diagnostický odhad. Pokud je historie nebo image složka neznámá, agregovaná hodnota je `null` s uvedením důvodu. Nevykazovat matematicky přesnou úsporu bez srovnatelné úplné úlohy.

Tvrdá kontrola nezakazuje běžné znovupoužití interface kontraktu pro více souborů; to je nutný náklad. Zakazuje přidání všech předchozích requestů, rekurzivní `snapshot.snapshot`, více kopií stejných artefaktů ve stejné významové roli a předávání nesouvisejících zdrojů bez zapsaného důvodu.

## Zdroje

Závěry o API se ověřují proti položkám OAI-RESP, OAI-STATE, OAI-SO, OAI-BATCH, OAI-CACHE, OAI-TOKENS a OAI-BG v `evidence/sources.json`. Limity aplikace jsou návrhová rozhodnutí, nikoli tvrzení, že mají totožnou hodnotu všechny modely OpenAI. Runtime vždy použije přísnější z aplikačního a doloženého modelového limitu.