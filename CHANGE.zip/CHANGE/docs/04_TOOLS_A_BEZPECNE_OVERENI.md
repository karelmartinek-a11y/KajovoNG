# Nástroje, bezpečnost a verifikační adaptéry

## 1. Rozhodnutí o tools

Cílem není zavést autonomního agenta s libovolnými akcemi. Většina úloh dostane úplný potřebný kontext deterministicky a žádné nástroje. Modelové tools jsou povoleny jen v B0R a explicitně zdrojovém QA, případně v konkrétním předem schváleném kaskádovém kroku. A3/B3 ani native Image Batch nemají tools. V ostatních fázích se chybějící rozhodující podklad řeší blocked otázkou nebo novou explicitní projekcí, ne nekontrolovanou explorační smyčkou.

Custom nástroje jsou přesně tři, strict masky v `policies/tools.json`: read_source_segment, read_project_slice, lookup_contract. Žádný write_file, delete_file, run_shell, internet fetch, SMTP či Git push není modelový tool. `file_search` je samostatný provider builtin s vlastní účtovanou spotřebou, omezený na schválené vector_store_ids; není to custom function stejného jména.

## 2. read_source_segment

Arguments: source_id, segment_id, start_byte, end_byte. Povinná všechna pole, additionalProperties=false. Ranges jsou polouzavřené a musí ležet uvnitř jednoho existujícího schváleného segmentu. Horní limit24 000UTF-8bajtů, doporučené maximum6 000tokenů; obsah není useknut potají. Pokud požadovaný range přesahuje limit, tool vrátí `RANGE_TOO_LARGE` s maximem a nevydá částečný text označený za úplný.

Kontroly v pořadí: argument schema; positive/ordered boundaries; scope obsahuje source; segment ID patří source; expected stored hash je správný; hranice UTF-8; max bytes. Výsledek: `{ok:true, source_id, segment_id, start_byte, end_byte, sha256, text}`. Chyba: `{ok:false, code, message, retryable:false}`. Není dovoleno odkaz z textu interpretovat jako nový autorizovaný zdroj.

## 3. read_project_slice

Arguments: path, expected_sha256, start_line, end_line. Čísla1-based inkluzivní, nejvýše400řádků a24 000bajtů. Cesta musí být přesně v frozen IN inventory a odpovídat expected_sha256, žádné globy, absolutní cesty či environment expansion. Čte se immutable kopie, ne uživatelův pracovní adresář. Vrací celý vybraný interval s čísly a content hash. `HASH_MISMATCH` je blokující bezpečnostní chyba; model nesmí následným requestem použít jiný hash, který nebyl ve schváleném registry.

Tento tool nemůže číst `.env`, credential storage, domovský adresář nebo soubory mimo schválený SourcePack, i kdyby o to žádal zdrojový kód či API response. Soubor musí mít schválený textový typ; binární obraz se předává přes image input, nikoli přes tento textový tool.

## 4. lookup_contract

Arguments: contract_id, version. Přístup pouze do immutable registry aktuálního běhu a jeho schválených dependencies. Vrací přesnou definici schváleného rozhraní/požadavku/akceptace, její hash a scope. Neprovádí sémantické dohledání podobného názvu. Neznámé ID či neexistující verze vrací `CONTRACT_NOT_FOUND`. Žádný automatický volaný model pro doplnění chybějící definice.

## 5. Tool calling transport

Responses request předá definice function se `strict:true` a `parallel_tool_calls:false`. Výsledek se parsuje jako provider output items. `function_call` má name, arguments JSON a call_id; schéma se validuje před handlerem. Výstup handleru se vrací jako `function_call_output` s odpovídajícím call_id a `output` serializovaným dle provider API. Zde je string transportní forma předepsaná API; nemá se zaměňovat s vadným vnitřním JSON-string výstupem kaskády.

Další Response v mikrosekvenci má předchozí response_id a pouze nové function_call_output položky. Instrukce a povolená tools schémata se znovu přiloží; celé staré input/output items se spolu s previous_response_id znovu nekopírují. Maximálně4 Response generace v nástrojové sekvenci, maximálně8 custom calls celkem a absolutně6 placených Response generací na task včetně případných oprav. Každé pokračování má nový attempt identity a rozpočet. Po finální odpovědi teprve validovat konečný stage JSON.

Tool outputs jsou nedůvěryhodná data, nikoli developer instrukce. `ignore previous instructions` uvnitř souboru nesmí upravit tool allowlist. Handler dovolí pouze původní scope. Opakovaný stejný call může vrátit lokálně cached výsledek bez nového čtení, ale dvě opakování bez pokroku ukončí mikrosekvenci `TOOL_NO_PROGRESS`.

## 6. Builtin file_search

Max3 výsledky a max_tool_calls4, jen dokumentovaná podporovaná kombinace textového modelu. Vyžadovat dokončený vector store index bez failed/cancelled položek nebo explicitně schválený částečný index s popsanou mezerou. Do výstupu přenést skutečně nalezené file IDs a relevantní citation/source spans. Výsledky se nesmějí stát normativním požadavkem bez vazby na uživatelův schválený zdroj.

Model může vyhledat nesouvisející text; sémantická gate nesmí pouze přijmout existující file ID jako důkaz relevance. Při review důležitých závěrů se kontroluje vazba textu ke kritériu. Budoucí retrieval nelze přesně předem změřit, proto rezervovat místo i náklad; při vyčerpání zastavit, ne použít truncation=auto.

## 7. Sandbox

Před spuštěním generovaného kódu musí existovat administrátorem instalovaný a schválený runner. Image se identifikuje digestem; mutable tag latest není povolen. Balík neuvádí vymyšlený sha256 image, protože platný digest musí odpovídat skutečně vytvořenému a ověřenému prostředí. Konfigurace neumožňuje modelu tento digest nastavit. Na Windows je podporována izolovaná VM/container backend instalace správce; pokud není k dispozici, ověření není podporované, ne fallback host subprocess.

Výchozí limity:2CPU,2048MiB RAM,256PID,512MiB writable tmp,600s walltime,10MB zachyceného outputu, nonroot UID10001, read-only rootfs, no-new-privileges, drop ALL capabilities, network none, žádný Docker socket, žádné host credentials. Source/staging se kopíruje do izolovaného workspace, nikoli připojí zapisovatelný host kořen. Překročení výstupu ukončí process a uloží bounded diagnostic plus total count; není úspěšný test.

## 8. Konkrétní verifikační profily

Python-unittest: detekované Python soubory bez externích dependencies, syntaktická compile kontrola a `python -m unittest discover -s tests`. Parser `ast.parse` se může provést lokálně bez importu, ale skutečné testy pouze v sandboxu. Zero tests je `TEST_DISCOVERY_EMPTY`, nikoli success.

Python-pytest: pytest musí být ve schváleném prostředí. `python -m pytest -q --disable-warnings --maxfail=10`. Pytest pluginy a testy mohou spouštět kód, proto izolace nutná. Žádné instalace do uživatelova globálního Pythonu.

Node: přesný package manager dle schváleného lockfile. Profil tohoto balíku podporuje npm+package-lock; jiné manager profiles jsou external/unsupported do doloženého doplnění. Povinné skripty `build` a `test:ci`. Příkazy: `npm ci --ignore-scripts --offline`, `npm run build`, `npm run test:ci`. Žádné obecné přidávání `--runInBand`, které by nefungovalo s jiným runnerem, a žádné `--if-present`, které by chybějící build označilo za úspěch. Při existujícím MODIFY projektu bez test:ci musí být předem schválen explicitní verification profile s přesným safe argv; implementátor si nevybírá podle dojmu.

.NET: locked restore, build no-restore, test no-build/no-restore. Chybějící lock nebo cache dependency vytvoří blocked dependency preparation. Předgenerování locku je skutečná samostatná sandbox operace, ne text modelu s vymyšlenými integrity hashi.

Static: parsování skutečného formátu, encoding, schema/content checks. Nedovoluje `completed_verified` pro aplikaci, která má běžet, pokud chybí runtime/build/test očekávání. Pro deklarovaný textový artefakt se může ověřit právě tento omezený cíl.

## 9. Síť a závislosti

Žádný blanket internet během build/test. Potřebná instalace závislostí proběhne v samostatné izolované přípravě s explicitní registry allowlist a schváleným manifestem. Network credentials se neposkytují generovanému projektu. Npm postinstall nebo pip build hooks jsou nespolehlivý kód a podléhají stejným limitům; `--ignore-scripts` není záruka, že následný build je bezpečný. Chybějící přístup neschovávat do mocku, který simuluje úspěšnou externí integraci.

## 10. Akceptační důkazy

VerificationReport musí obsahovat snapshot hash, profile ID/hash, runner digest a verzi, seznam checků, výsledky, skutečný exit code, bounded logs a hashe úplných důkazů, čas začátku/konce a počet skutečně provedených testů. Modelové tvrzení „testy prošly“ není takový důkaz. U externího API, které nebylo reálně zavoláno, se test označí mocked nebo unsupported, ne live-integration-pass.

Hranice funkčnosti je explicitní: implementace může být správná podle sady testů a přesto mít neznámou chybu. UI i report proto uvádějí „Ověřeno profilem X“ místo absolutní záruky. Povinný criterion bez vhodného ověřovače nesmí zmizet; vyžaduje lidský nebo externí gate.