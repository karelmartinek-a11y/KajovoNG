# Závazná rozhodnutí a veřejná rozhraní implementace

## D01–D15: rozhodnutí, která implementátor nepřehodnocuje

**D01.** Zachovat OpenAI Responses pro textové výstupy a vizuální review. Kresbu posílat přímo do doloženého Image API; nepřidávat nad ni další placený textový model jen kvůli sjednocení endpointu. `image_generation`, web search, computer use a shell nejsou v této změně modelové nástroje. Jejich absence není nevyužitá funkce: zvolený rozsah potřebuje přesný výsledek a rozpočet, nikoli co nejvíce nástrojů.

**D02.** Nové A3/B3/QFILE mají jediný wire výstup `FILE_CONTENT_V1`. QFILE bez určené cesty provede zvláštní plán jména a vyžádá jeho schválení. Nedovoluje se modelová cesta přímo použitá při zápisu.

**D03.** A2/B2 mají dva účelové druhy requestů: SPINE (soubory, rozhraní, alokace povinností) a DETAIL (jeden souborový kontrakt). Výsledek `IMPLEMENTATION_GRAPH_V3` sestaví aplikace lokálně. Neprovádět ještě jeden modelový call pro spojení již validovaných částí. DETAIL lze provádět souběžně nejvýše ve čtyřech LIVE úlohách; jde o přípravu, ne souborový Batch.

**D04.** A2Q/B2Q jsou pouze ve Maximum Quality nebo při výslovném samostatném požadavku na review. Standard vždy provede lokální sémantické kontroly. Nepřidávat neviditelný placený quality gate podle programátorem vymyšlené heuristiky.

**D05.** Review nevrací generický JSON Patch s libovolným `value`. Povoleno je pět typovaných operací `replace_requirement`, `replace_component`, `replace_interface`, `replace_file_entry`, `replace_file_spec`. Identita cíle a expected hash jsou kontrolovány před atomickou aplikací. Přidání nebo odstranění uzlu grafu patří do explicitní re-plánovací úlohy, ne do skrytého patch operation.

**D06.** Ceny a capability jsou data, ne úsudek podle názvu modelu. Výběr doporučení je pořadí z role policy protínané s dostupností účtu a požadovanými schopnostmi. Nový Standard doporučí silný model pro přípravu a viditelně levnější výrobní roli podle `policies/stages.json`. Stávající ručně uložené modelové volby se migrují jako explicitní. Obnova katalogu přenastaví doporučení jen v editovatelných návrzích, nikdy v již schválených WorkOrder.

**D07.** Nepodporovaná kombinace znamená blokaci. Žádné tiché odstraňování tools, změna velikosti obrázku, snížení effort, přepnutí modelu nebo zahazování kontextu pro dosažení zeleného výsledku.

**D08.** Výchozí Batch výroba je paralelní proti zmrazeným interface kontraktům. Vlny se vynutí pouze u explicitní content dependency. Existence importu sama o sobě neznamená požadavek přenášet kompletní dependency obsah.

**D09.** Zachovat forward-only kaskády. Verze 3 nezavádí obecné programové smyčky. Automatické opravné pokusy jsou oddělené a omezené; `max_visits` musí být 1. Konečný foreach nad zmrazeným seznamem lze vyjádřit předem rozepsaným DAG, nejvýše 100 prvků na uzel. Nikdy `eval`, libovolný Python nebo Jinja s přístupem k objektům.

**D10.** Profesionální foto prompt je volitelná skutečná funkce. Ruční finální prompt se bez požadavku uživatele nepřepisuje modelem. Technické úpravy jako kanonizace reference IDs nevyvolávají generaci.

**D11.** Ruční komiksový editor zůstává. Příběhový postup je samostatný nový vstup. Oba končí u stejného kompilátoru panelových WorkOrder a stejného importu/review.

**D12.** Vizuální hodnocení modelem je heuristické. Stav `completed_reviewed` se nesmí přejmenovat na deterministicky ověřenou shodu s originálem. U `uncertain` se vyžádá člověk; žádný průměr sebejistoty ani automatické tolerování porušení povinného kritéria.

**D13.** Žádný build/run/test na hostiteli. Administrátor dodá schválené sandbox image digesty. Balík neobsahuje vymyšlený digest. Chybějící infrastruktura je `VERIFIER_UNAVAILABLE`, ne důvod spustit kód neizolovaně.

**D14.** API klíče ani jejich úložiště nereorganizovat. Nový katalog používá oddělený fingerprint scoped účtu, base URL, organizace a projektu. Autorizační hlavičky nikdy nevstupují do evidence requestu. Přesné uživatelské podklady se uchovávají v chráněném artefaktovém úložišti; jejich tiché redigování by zničilo hashovou obnovu.

**D15.** Nevytvářet datované auditní zprávy v produkčním zdrojovém stromu. Evidence tohoto změnového balíku zůstává v balíku; produkční dokumentace popisuje platné chování. Při integraci zachovat pravidla `AGENTS.md`.

## Rozhraní nových modulů

Všechny veřejné funkce musí používat níže uvedené typy a vyvolávat pouze `OrchestrationError` se stabilním `code`, kromě explicitních standardních I/O chyb na nejnižší vrstvě, které adaptér převádí. Datové objekty jsou immutable dataclasses nebo validované immutable modely; mutable slovník se nekopíruje mezi workery bez zmrazení.

| Modul | Přesné rozhraní | Závazné chování |
|---|---|---|
| `contracts.py` | `load_contract(name: str) -> StageContract` | Načte registrovanou verzi a ověří SHA souboru. Neznámá verze blokuje, žádný fallback. |
| `contracts.py` | `validate_wire(name: str, raw_text: str) -> WireResult` | Odmítne duplicity JSON klíčů, nečíselné konstanty, okolní prose a odlišný kořen. Použije přesně schéma odeslané s requestem. |
| `contracts.py` | `validate_semantics(name: str, candidate: WireResult, registry: FrozenRegistry) -> ValidationReport` | Nic neopravuje na místě. Vrátí všechny relevantní chyby s pointery. |
| `source_pack.py` | `freeze_sources(inputs: Sequence[ApprovedInput], store: ArtifactStore) -> SourcePack` | Otevře a kopíruje zdroje jednou; path traversal, symlink/junction mimo scope a změna během čtení blokují. |
| `source_pack.py` | `segment_text(source: FrozenText, max_bytes: int = 65536) -> tuple[SourceSegment,...]` | Polouzavřené UTF-8 byte intervaly, bez ztráty či překryvu. Nikdy nerozdělí UTF-8 kódový bod. |
| `projection.py` | `project(stage: StageId, target: TargetId, registry: FrozenRegistry, bindings: tuple[Binding,...]) -> Projection` | Výběr pouze explicitních vazeb; plné required komponenty, bez statistické podobnosti. |
| `projection.py` | `verify_projection(p: Projection, store: ArtifactStore) -> None` | Ověří zdroj, selector, hash, roli, oprávnění, duplicity a úplnost deklarovaných povinností. |
| `work_order.py` | `freeze_order(config: ApprovedRun, task: TaskDefinition, projection: Projection) -> WorkOrder` | Připojí všechny hashe a důvěryhodný target. Pozdější UI změny nemají účinek. |
| `executor.py` | `build_payload(order: WorkOrder, projection: Projection, attempt: AttemptPolicy) -> PreparedRequest` | Jediný builder pro LIVE a Batch; změny jen v transportních příznacích. |
| `executor.py` | `classify_response(raw: ProviderResponse) -> ClassifiedResponse` | Status a refusal před parsováním. Tool call není finální odpověď. Neznámý status není success. |
| `executor.py` | `execute(order: WorkOrder, stop: StopToken) -> TaskResult` | Nejprve ledger+journal, potom transport; nedělá implicitní fallback ani změnu oprávnění. |
| `ledger.py` | `reserve(order_hash: str, limits: ReservationLimits) -> Reservation` | SQLite `BEGIN IMMEDIATE`; UNIQUE work_order_hash; kontrola run i lineage limitů; commit před submit. |
| `ledger.py` | `mark_submitted(reservation_id: str, provider_id: str | None, unknown: bool) -> None` | Neznámé ID s unknown drží celý odhad. |
| `ledger.py` | `settle(reservation_id: str, usage: UsageRecord) -> None` | Idempotentně právě jeden záznam dle provider_id/attempt. Stejné usage z pollingu nemění součet. |
| `waves.py` | `build_execution_dag(graph: ImplementationGraph) -> ExecutionDag` | Rozliší contract/content edges. SCC v content edges blokuje; contract SCC je společná kontraktní skupina. |
| `waves.py` | `ready_tasks(dag: ExecutionDag, evidence: EvidenceIndex) -> tuple[TaskId,...]` | Neotevře consumer bez všech vyžadovaných a aktuálních důkazů. |
| `verification.py` | `plan_checks(target: ArtifactSet, profile: VerifiedProfile) -> VerificationPlan` | Příkazy pouze z profilu, žádné modelové shell řetězce. |
| `verification.py` | `run_checks(plan: VerificationPlan, sandbox: SandboxHandle) -> VerificationReport` | Timeouts/exit code/stdout/stderr/hash prostředí se uloží; chybějící testy nejsou úspěch. |
| `tool_dispatch.py` | `dispatch(call: ToolCall, scope: ApprovedScope) -> ToolResult` | Jen tři read-only funkce z tools policy; všechny argumenty a rozsahy kontrolovat. |
| `image_slots.py` | `compile_slots(roles: Sequence[ImageRole], assets: FrozenAssetIndex) -> ReferenceSlots` | Nejprve deterministická deduplikace, potom indexy; zachová mapování každé role. |
| `publish.py` | `prepare_publish(staging: ArtifactSet, target: Path, expected: HashMap) -> PublishPlan` | Ověří konflikty před prvním přepisem; vytvoří undo manifest. |
| `publish.py` | `commit_publish(plan: PublishPlan) -> PublishReport` | Exkluzivní projektový lock, atomické jednotlivé zápisy, restartovatelný journal. |
| `repository.py` | `commit_transition(task_id: str, expected_revision: int, event: Event) -> TaskSnapshot` | Compare-and-swap revize a monotonní event sequence; duplicitní event id neprovede znovu. |

`ProviderTransport.send` přijímá již připravený request a vrací `RawTransportResult(body, status_code, headers_without_secrets, request_sent)`. Jediný povolený transportní retry je podle `policies/transports.json`; builder ani doménový executor neobalují tento call další generickou retry funkcí.

## Sémantická validační tabulka

| Kontrakty | Povinné lokální podmínky |
|---|---|
| SOURCE_FACTS | Segmenty a byte intervaly existují, přesně sedí hashe; každý zpracovaný segment má accounting; fact IDs unikátní. Segment accounting není důkaz významové úplnosti. |
| A0R/B0R | Neprázdný záměr, unikátní ID, explicitní požadavek má zdroj; derived má existující rodiče a necessity; povinné acceptance pokrývá požadavky; žádné neschválené rozšíření. |
| A1/B1 | Každý mandatory REQ má komponentu, neznámé odkazy blokují; B1 add/modify disjunktní a odpovídají zmrazenému IN; preservation může být splněn bez zápisu. |
| A2/B2 SPINE | Bez case-insensitive kolizí a file/directory kolizí; každé rozhraní má jednoznačný provider nebo explicitní víceproviderový kontrakt; externí balíčky nepatří do file dependencies. |
| A2/B2 DETAIL | Právě jedna specifikace k důvěryhodnému cíli, bindings přesně odpovídají provides/requires, všechny required facets přítomné; expected tokens kladné; nepovolený prázdný soubor zakázán. |
| REVIEW | accept má prázdné operations a žádné blocker/error issues; repair má alespoň jednu opravu ke konkrétní issue; expected hashes odpovídají, cílové ID se nesmí změnit. |
| FILE_CONTENT | Text bez nulových bajtů, ne nevalidní Unicode surrogate; prázdnost podle WorkOrder; žádný `path` či `chunking`; konkrétní parser/typové kontroly následují zvlášť. Nezakazovat obecně řetězec TODO uvnitř legitimních dat/testů. |
| QA | Evidence IDs skutečně poslané/retrievované; claim označený supported má alespoň jeden zdroj; odkaz sám neprokazuje pravdivost tvrzení. |
| QFILE_PLAN | Bezpečná relativní cesta, suffix odpovídá formátu; volba se potvrdí před výrobou; neznámý formát vede k otázce, ne příponě .txt přidané potají. |
| CASCADE | Rozhodnutí jen z enum, output shape přesně z registrovaného schema; příslušné typy se nepřevádějí na řetězce; required binding producent dominuje consumeru. |
| PHOTO_PLAN | Žádné nové změny bez vazby na žádost; preserve nesmí odporovat explicitní editaci; mask exact vyžaduje existující potvrzenou masku. |
| IMAGE_REVIEW | Každé mandatory kritérium hodnoceno právě jednou; slots existují; souřadnice v [0,1]; pass nesmí obsahovat nevyřešenou unrequested change. |
| COMIC_BIBLE/ENTITY | Explicitní volby aplikace nepozměněny; reference ve schváleném projektu, identity atributy mají zdroje, žádné prázdné povinné pravidlo. |
| COMIC_OUTLINE/SCRIPT/STORYBOARD | Jen existující entity, přesná návaznost scene/beat/dialogue IDs, žádná vynechaná povinná replika, panel IDs přidělené aplikací, layout nepřesahuje plátno. |
| COMIC_CONTINUITY_REVIEW | Pokrytí všech zadaných continuity checks, oprava jen vybraných panelů; nesmí měnit scénář místo opravování kresby. |
| REPAIR_PLAN | Target subset schváleného affected closure, existující error IDs, žádný skrytý nový scope; true requires_new_scope blokuje automatické provedení. |

Všechny lokální validátory musí přijímat zmrazený registr; přístup k měnícím se UI modelům je chyba. Každý výsledek s `blocked` má alespoň jednu otázku a nevytváří downstream payload.