# Doplňující normativní datové a transportní invarianty

Tento dokument konkretizuje hraniční situace společné všem workflow. `MUSÍ`, `NESMÍ` a `POUZE` jsou závazné požadavky. Schémata v balíku definují uzavřené množiny polí. Žádný runtime fallback nesmí obejít zde uvedené podmínky.

## 1. Identity, hashe a kanonizace

Kanonický JSON se zapisuje pomocí UTF-8, bez BOM, s `ensure_ascii=False`, `sort_keys=True`, `separators=(',', ':')` a `allow_nan=False`. Při čtení se odmítnou duplicitní klíče, NaN, Infinity a číselné hodnoty mimo konečný rozsah. Pracovní structured output musí být jediný JSON objekt; prose před/za objektem není dovolena. Starý tolerantní parser zůstává výhradně v pojmenovaném legacy importéru.

`schema_sha256` je SHA-256 kanonického JSON schématu, ne hash jeho odsazeného souboru. `file_sha256` je hash skutečných bajtů souboru v balíku. `source_sha256` se počítá nad původními bajty. `normalized_sha256` nad přesnými pracovními bajty obrázku. `content_sha256` nad UTF-8 obsahem výsledného textového souboru bez změny konců řádků. Změna konců řádků nebo EXIF normalizace je nová explicitní transformace, nikdy tichá oprava hashů.

`run_id`, `task_id`, `attempt_id`, `artifact_id` a `custom_id` přiděluje aplikace. Model nesmí vytvářet identitu placené operace, cílovou cestu A3/B3, provider ID, timestamp, cenu ani důkaz ověření. Významové lokální značky REQ/ARCH/IFACE v návrhu modelu jsou po validaci jedinečné uvnitř artefaktu; aplikace jejich význam svévolně nepřejmenovává. Řešení ID konfliktu patří do explicitní opravy kandidáta.

`request_hash` se počítá z přesného těla připraveného k odeslání včetně modelu, text.format, instructions, aktuálního input a příznaků background/store. `measurement_hash` identifikuje přesnou podmnožinu polí podporovaných endpointem input_tokens. Měření lze znovu použít pouze při shodném modelu a měřené reprezentaci. Změna pouze auditního metadata nesmí vyvolat novou tokenizaci, ale stále vytvoří nový request_hash. Po zmrazení requestu se neprovádí další skryté doplňování instrukcí.

Lokální artefaktová obálka, celý zdrojový snapshot, SQL záznam a pracovní projekce nejsou stejné objekty. Aplikace ukládá původ každého prvku, ale nepotřebnou auditní obálku neposílá modelu.

## 2. Vstup každé fáze

Každá fáze v `policies/stages.json` má `input_contract` a cestu `input_schema`. Před generací se její pracovní objekt validuje tímto schématem. Potom se serializuje právě jednou do jediného `input_text`. Přílohy se přidávají jen podle explicitního seznamu; totožná příloha se podruhé nepřidá přes generický `_append_io_reference`.

Pro konkrétní vstup nesmí existovat druhá nevázaná varianta „specification“ nebo „full_snapshot“. Pokud fáze potřebuje dodatečný důkaz, použije povolený read-only nástroj, anebo skončí `blocked` s přesným požadavkem. Přípravný výsledek nemůže potichu rozšířit uživatelský rozsah.

Příkladové soubory obsahují demonstrativní ID a zdroje. Produkční builder je vytvoří z ověřených artefaktů a nikdy neposílá řetězce `file_demo` nebo `resp_demo` jako náhradu skutečného prostředku.

## 3. Wire validita versus sémantická validita

Structured Outputs řeší tvar dat. Vztah „provider skutečně existuje v této verzi projektu“, shoda hashe a splnění uživatelského záměru jsou další, odlišné vlastnosti. Zákaz rozporu schéma/validator znamená, že např. typ a povolená konstanta `chunk_count` nesmějí být v každé vrstvě jiné. **Neznamená**, že každý syntakticky platný JSON je použitelný projekt.

Každý sémantický validator vrací strukturované issue s code, pointer, očekáváním a skutečností. Pokud vadný údaj pochází od modelu, nález jde dovnitř jednotné omezené opravné smyčky. Pokud je vadná konfigurace programu, autorizace, schéma nebo runtime stav, modelový repair se nesmí použít: šlo by o placený pokus opravit chybu aplikace.

Gate vrací tři výsledky: `accepted`, `repairable`, `blocked`. Při `blocked` musí existovat explicitní důvod; prázdné seznamy nejsou univerzální úniková cesta. Například prázdný seznam souborů pro požadavek na aplikaci není úspěšná implementace. Validní no-op MODIFY musí doložit, že změna již existuje a baseline akceptace ji ověřila.

## 4. Přesné závislosti obsahu

Každá FileEntry obsahuje `dependencies`, `content_dependencies` a `dependency_content_mode`. Platí:

```text
set(content_dependencies) <= set(dependencies)
mode == contract         <=> content_dependencies je prázdné
mode == verified_content <=> content_dependencies není prázdné
```

`dependencies` popisuje kontraktovou/importní vazbu. `content_dependencies` je přesná podmnožina souborů, jejichž hotový obsah je opravdu potřebný pro tvorbu cíle. Není dovoleno automaticky rozšířit tuto podmnožinu na všechny závislosti. Požadavek na obsah musí mít zdůvodnění v kontraktu cíle.

Topologické execution waves se plánují podle `content_dependencies`, nikoli podle všech importů. Cyklické importy s úplnými společnými interface kontrakty lze generovat paralelně. Cyklus skutečné závislosti na již dokončeném obsahu je neproveditelný a blokuje přípravu. Žádný programátor nesmí zvolit náhodné pořadí a doufat, že cyklus zmizí.

Ověřený provider musí mít platný obsahový hash, shodný contract_hash a důkaz přesně definované ověřovací úrovně. `file_contract_valid` není totéž jako runtime-integrated. Pro následující vlnu stačí úroveň deklarovaná daným závislostním kontraktem; pokud jde o integrační výsledek, schema-valid provider bez integračního důkazu nestačí.

## 5. Review a oprava struktury

Kvalitativní review má předepsanou množinu typovaných náhrad celých známých objektů. Nepřijímá obecné `value:any` ani libovolný JSON Patch. Aplikace do `review_targets` vloží druh, target_id, přesný selector a `expected_value_hash`. Model tento již známý hash pouze zopakuje; nesmí se po něm požadovat výpočet SHA-256.

Před aplikací každé náhrady se ověří existence cíle, druh, shoda původního hashe a zachování identity. Náhrady se aplikují do hluboké kopie. Potom se validuje celý nový graf včetně původu požadavků, rozhraní, všech cest, content dependencies, kapacit a akceptace. Teprve při celkovém úspěchu se nový graf publikuje jako nový artefakt. Selhání uprostřed nepozmění původní graf.

Přidání nebo odstranění souboru vyžaduje nový A2/B2 spine a související details, nikoli svévolnou neomezenou patch operaci. U současného MODIFY jsou povolené produkční souborové změny add/modify. Požadavek na delete/rename se nepřevádí na prázdný soubor; dokud nebude samostatně schválený migrační kontrakt s rollbackem, vrátí se explicitní blokace této operace.

## 6. Schéma kaskády

Nové definice používají typovaný DSL `SCHEMA_DSL_V1`; jeho uzly mají explicitní kind, properties/items/enum a povinné členy. Kompilátor generuje podporovanou podmnožinu JSON Schema. Uživatelský JSON výstup se přenáší jako skutečný objekt/pole, ne jako JSON uvnitř textového řetězce. Dvojí serializace výstupu je zakázána.

V první dodávané verzi editor schémat nepovoluje volitelná/nullable pole. Každý objekt má všechna pole required a additionalProperties=false; nejistota se vyjadřuje explicitním stavovým objektem. Toto omezení musí být viditelné v UI, nikoli zjištěné až placeným API requestem. Limity jsou v semantic_limits. Legacy nullable definice zůstávají čitelné, ale před novým během vyžadují explicitní ověřenou migraci.

Decision vrací pouze klíč z existujícího enum. Cílový step_id vlastní definice, nikoli model. Každá větev musí předem projít kontrolou dostupnosti vstupů přes dominátory grafu. Odbočka nesmí pokračovat do kroku, jehož povinný producent byl touto odbočkou přeskočen.

## 7. Klasifikace Responses a mikrosekvence nástrojů

Po každé provider odpovědi se nejprve klasifikuje skutečný stav. Pending se ukládá a polluje. Refusal/content_filter se nenutí obejít změnou promptu. Incomplete není finální JSON. Function calls jsou mezikrok, nikoli chybějící odpověď finálního schématu.

Aplikace spustí pouze tři read-only nástroje z policies/tools.json. Neznámý nástroj, neplatné argumenty, rozsah mimo schválené podklady a nesoulad hashe jsou deterministické chyby. Každé call_id je uloženo spolu s hashem argumentů a výsledkem. Opakovaný shodný call_id vrací tentýž uložený výsledek; jiný obsah pod stejným ID je konflikt. Další Responses request je znovu placený a znovu rezervovaný.

Maximálně čtyři Responses v nástrojové mikrosekvenci, nejvýše osm tool calls na úlohu a absolutně šest generativních Responses pro jednu úlohu včetně strukturálních oprav. Limit tří strukturálních pokusů je další nezávislé omezení; nesmí se násobit 3×4. Jakýkoli dosažený limit vrací blocker a zachová artefakty. A3/B3 Batch žádnou takovou interaktivní mikrosekvenci nemá.

## 8. Finanční účetnictví

Peněžní hodnoty se v produkčním ledgeru ukládají jako celé mikrojednotky USD; pro výpočty se použije Decimal a konečná rezervace se zaokrouhlí nahoru. Plovoucí float není povolený pro rozhodnutí, zda je povolen další request. Ceník je verzovaný se zdrojem a datem. `unknown` není nula.

Před odesláním dávky se v jediné transakci rezervují všechny její řádky. Dvě paralelní dávky nesmějí obě utratit tentýž zbývající rozpočet. Rezervace je idempotentní podle operation_id. Po neurčitém submitu zůstává obsazená; časový timeout ji neuvolní. Po potvrzeném odmítnutí před vznikem generace se může uvolnit pouze příslušným přechodem. Skutečné usage se zaúčtuje jednou podle provider operation ID.

Výstupní tokeny již zahrnují reasoning tokeny; reasoning se do ceny nepřičítá podruhé. Cached input je podmnožina vstupu, ne další vstup navíc. Neznámá obrazová cena nebo budoucí retrieval vyžaduje konzervativní horní mez, anebo výslovně schválenou omezenou politiku neúplné cenové znalosti. UI v takovém případě nesmí zobrazit garantovanou konečnou cenu.

## 9. Omezené záruky kompletnosti

Source coverage dokazuje, že každý zdrojový segment prošel zpracováním a má explicitní přiřazení, nikoli že model nikdy nepochopil větu chybně. Finální acceptance musí testovat důležité scénáře a u nejednoznačného záměru vyžádat potvrzení. Stejně tak vizuální reviewer není pixelový důkaz. Deterministická ochrana obrazové oblasti vzniká pouze lokální kompozicí proti přesně definované masce.

Stav `completed_verified` je vždy relativní ke konkrétní sadě kontrol a jejímu hashi. Není to tvrzení, že pro libovolný vstup neexistuje chyba. U QA může být cílem doručení odpovědi se zdrojovou evidencí; nesmí se na něj přenášet falešná záruka pravdivosti všech vět. U kaskády musí být explicitně zvolený final acceptance kontrakt, jinak končí jako výstupy doručeny, nikoli jako automaticky ověřený produkt.

## 10. Artefakty a zveřejnění

Zápis souboru je atomický, ale sada souborů není automaticky atomická. Výstup se nejprve připraví v izolovaném stagingu. Před publikací se porovnají hashe očekávaných původních souborů, symlinky/junctions a casefold kolize. Konflikt zachová staging i uživatelovy soubory. Nové projektové výstupy se publikují verzovaným adresářem, MODIFY používá rollback journal a explicitní per-file preconditions. Potvrzení hotovo se nesmí odeslat před durable commit.

Nová orchestrace používá vlastní SQL schéma z migration, nikoli přímé přepisování tabulek ComicStore. Napojení na ComicStore je přes idempotentní doménový outbox. Dvojí zpracování události nesmí vytvořit dvě aktivní verze téhož panelu.

## 11. Provozní podmínky bez libovolného výběru programátora

Digest schváleného runner image, skutečné project/account ID, platné credentials a doložené cenové sazby jsou provozní vstupy, nikoli architektonická rozhodnutí programátora. Programátor nesmí vyplnit smyšlený digest, nouzový veřejný obraz `latest`, testovací klíč ani odhad ceny podle názvu modelu. Pokud provozní schválení chybí, příslušná akce je disabled s jednoznačným důvodem.

Přidání dalšího jazyka, rendereru, mutujícího modelového nástroje nebo transportního parametru vyžaduje verzovanou změnu politiky, schéma, testy a aktualizaci SSOT. Není povolený skrytý fallback „spusť to na hostitelském systému“.