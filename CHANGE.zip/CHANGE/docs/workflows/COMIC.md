# Komiks — bible, entity, příběh, storyboard a obrazové panely

## 1. Dva rovnocenné vstupy

Zachovat stávající ruční zadání panelů s tokeny referenčních postav/prostředí, editaci bublin, historii verzí, knihovnu a export. Přidat novou samostatnou cestu Příběh. Ruční cesta nesmí bez dotazu spouštět outline/scénář ani měnit již napsané repliky. Obě cesty se sjednotí před `compile_panel_work_order` a používají stejnou obrazovou výrobu, reference, verze, review a export.

Výchozí source moduly: `comic_types.py`, `comic_service.py`, `comic_store.py`, `image_runtime.py`, `studio/comics.py`, `studio/comic_editor.py`. Pevné TEXT_MODEL/IMAGE_MODEL konstanty nahradit profilovým resolverem s explicitní volbou v UI, zpětně čitelné historické modely zachovat. Nový task vždy používá zmrazený model/capability snapshot, ne aktuální globální proměnnou při importu.

## 2. Modely, formáty a data

Text/vision role mají vlastní recommendation. Obrazová role vyžaduje native images/generation nebo edit a případně image Batch, nikoli obecný textový batch příznak. `PanelFormat` zachová cílové rozměry 1–16 384 px na hranu, nejvýše64MP, DPI150–600, pad/crop a explicitní experimental volbu. Skutečné modelové limity se uplatní navíc.

Všechna projektová data mají revision a immutable artefakty. User-authored style choices, originální reference, finální scénář a přesné repliky jsou autoritativní odděleně od generovaných stylistických elaborací. Nová bible již nesmí zahodit celou detailní kapitolu a nahradit ji jediným UI slovem „standardní“: aplikace drží explicit_options a generated_rules jako oddělené vrstvy, explicitní volba má přednost při kompilaci promptu.

## 3. Bible

COMIC_BIBLE přes Responses přijme popis zamýšleného komiksu, explicit_options a pouze stylové reference. Schema COMIC_BIBLE_V2 vrací pravidla s ID, kategorií a source refs, negativní omezení a continuity pravidla. Neřeší samotný scénář. Chybějící klíčový vizuální požadavek vrací otázku; není dovoleno překreslit reálnou referenci do jiného druhu prostoru bez schválení.

Před další fází musí být schválena bible revision. Opakované otevření projektu se stejnými input hashes nevolá model znovu. Změna explicit style choices invaliduje bible a dotčené reference/panely, nikoli přepíše původní obrázky. Uživatel vidí stale a může přejít na novou stylovou větev.

## 4. Entity a reference

Entita je character, environment nebo prop. COMIC_ENTITY vrací typovaný canonical descriptor: identity attributes, source/reference slots, mandatory invariants a ambiguity list. Důkaz identity vychází z uživatelem poskytnutých referencí; model nesmí samostatně rozhodnout, že jde o jinou osobu nebo nahradit chybějící reference vymyšlenou podobou. Chybějící reference je missing_input, nikoli neviditelná generace nového člověka.

Po schválení descriptoru se vytvoří image reference přes edit endpoint, případně generation pouze pokud uživatel výslovně zvolil novou smyšlenou entitu bez obrazové reference. Reference sheet je jeden obraz; postava front/three-quarter/profile podle explicitně zvolené šablony, prostředí široký pohled plus určené detaily. n=1. Bible a descriptor se do promptu vloží pouze v relevantní vizuální části, ne i celý příběh.

Každá reference má original asset, normalized asset, generated raw asset, postprocess asset a review status. Entity active_revision se změní pouze compare-and-swap proti očekávané entity revision. Výsledek doručený po ruční úpravě entity se uloží jako neaktivní variantní větev, nikdy nesmí přepsat novější práci.

## 5. Příběhová cesta

UI Příběh vyžaduje: lidské zadání, source references, zamýšlený počet panelů nebo povolený interval, jazyk dialogů, existující entity, tón a explicitní zákazy. Limit automatické nové cesty je64scén a512panelů na jednu schválenou výrobu. Historické větší manuální projekty se nemažou; lze zvolit omezený výběr panelů do nového běhu.

Sekvence je přesná: SOURCE/requirements pro příběh → COMIC_OUTLINE → schválení outline → COMIC_SCRIPT pro jednotlivé scény → COMIC_STORYBOARD pro jednotlivé scény → lokální kontrola návazností/layoutu → společný panelový compiler → image úlohy → review → lokální sazba → export. Nepřidávat samostatný call „shrň celý příběh“ po každé scéně.

### Outline

COMIC_OUTLINE_V1 vrací logline, konečný seznam scén a ending. Každá scéna má stable ID, dramatický účel, entity IDs, source refs, entry a exit state. Povinné zápletky a uživatelské body se vážou na scénu. Po schválení se ending nesmí v pozdějších scénách změnit bez nové outline revision.

### Scénář

COMIC_SCRIPT_V1 se volá pro jednu scénu. Vstup obsahuje její outline záznam, definovaný předchozí exit state, následující entry contract, relevantní entitní a příběhové invarianty. Nemá kompletní text všech předchozích scén. Výstup beats s action, cast, dialogue a continuity změnami. Přesné dialogue texty se po schválení stávají samostatnými textovými artefakty s ID.

`required_panel_count` musí sedět do schváleného intervalu a součet přes všechny scény do celkového limitu. Žádné vytvoření tisíců panelů proto, že jedna scéna vygenerovala dlouhý text. Překročení je `PANEL_BUDGET_EXCEEDED` a vyžádá nové rozvržení, ne tiché vynechání scén.

### Storyboard

Aplikace přidělí panel IDs podle schváleného počtu. COMIC_STORYBOARD_V1 vrátí přesně tuto množinu, scene ID, beat IDs, akci, kameru, entity states, location a text areas odkazující dialogue ID. Text bublin se neopakuje v každém panelovém obrazu. Neznámá replika, chybějící povinný beat, neexistující entita nebo přesahující box blokují výrobu.

## 6. Lokální kontinuita

Před obrazovou výrobou deterministicky ověřit: scene/beat/dialogue/panel IDs existují; posloupnost respektuje schválenou outline; required dialogue ID jsou přiřazena právě jednou, pokud není explicitně schváleno opakování; postavy a místa mají ready reference; změny stavů mají svého autora; explicitní zákazy bible se nemění. Nelze algoritmicky dokázat literární kvalitu či plnou logiku přirozeného textu, proto je navíc review outline/scénáře podle schválené quality policy nebo lidské schválení.

Předání stavebního stavu mezi scénami je kontrakt, ne generativní shrnutí libovolného množství historie. Pokud stav neodpovídá, opravit konkrétní scénu nebo schválit novou revizi outline; nepřidávat celé dosavadní scénáře do dalšího promptu „aby si model vzpomněl“.

## 7. Kompilace image referencí — povinná oprava indexování

Současný `ComicService.compile_panel` vypočítá některé image_index ještě před finální deduplikací asset listu. Nový algoritmus:

1. Vybudovat logické role: případný edit_base, entity references seřazené stable entity ID, potom style references seřazené stable asset ID.
2. Pro každou roli načíst immutable normalized asset hash a transform policy hash.
3. V tomto pořadí vytvořit jedinečný fyzický seznam podle dvojice hashů. Všechny role i při duplicitě zachovat v mapě role→slot.
4. Teprve nyní přiřadit slotům 1-based indexy.
5. Descriptor každé entity odkazuje na výsledný slot_id a index. Žádný starý index z kroku1 nesmí přežít.
6. Ověřit limit referencí dle skutečného unique count i modelové capability. Nedostatečnou kapacitu neřešit zahazováním postav.

Povinný regresní případ: edit_base, první entity a style reference mají stejné bytes; druhá entity má jiné bytes. Výsledek má dva fyzické obrázky, první tři role index1 a druhá entita index2. Reference nesmí ukazovat mimo seznam ani na špatnou identitu.

## 8. Panelový image prompt

Obsahuje přesný relevantní bible rule set, scénu/akci/kameru, relevantní entity descriptors, explicitní role mapu image slots a geometrii textových oblastí. Neobsahuje celé knihovní snapshots, všechny nepoužité entity, raw Responses ani kompletní scénáře sousedů. Přímé nejbližší sousední continuity stavy jsou malá konkrétní data, ne další kopie jejich image outputs.

Prompt výslovně zakazuje kreslit dialogové bubliny, captions a SFX; ty sází aplikace. I když SFX UI povolí, přidává se lokální textový overlay, nikoli nekontrolovaný obrazový text. Model musí ponechat prostor podle text areas. Editace panelu používá vybranou raw obrazovou verzi jako edit_base, ne již opatřený textem export, aby se text nezdvojil.

Endpoint: images/edits při alespoň jedné referenci, images/generations pouze bez referencí a se schválenou tvorbou od nuly. Stejná native image policy jako PHOTO, ale jiný doménový acceptance profil. Žádné automatické přepnutí z edit na generation po chybě reference.

## 9. Batch panely

Všechny nezávislé panely mohou být zpracovány společně podle model+endpoint+wave. Odlišné endpointy jsou oddělené dávky. WorkOrder zafixuje project revision, bible revision, entity revisions, panel prompt hash, overlays hash, target format a base version. Po návratu výsledek aktivovat pouze pokud všechny očekávané revize zůstaly stejné. Jinak uložit jako variantu s příznakem stale_input, nabídnout ruční převzetí a nepoškodit aktuální panel.

Generování dalších panelů nesmí dostávat všechny dříve vzniklé obrázky. Záměrná obrazová kontinuita vyžadující přímou předchozí kresbu musí být explicitní závislost na konkrétním přijatém assetu; scheduler pak vytvoří wave. Takových dependencies má být jen nezbytné minimum, protože prodlužují Batch workflow.

## 10. Technická a vizuální kontrola

Technická kontrola je společná s PHOTO: skutečný formát, dekódování, rozměry, complete image count, hash a bezpečný postprocess. Vizuální review ověřuje reference identity, cast, kompozici, povinnou akci, vyhrazené textové oblasti a bible omezení. COMIC_REVIEW používá okno maximálně dvou sousedních panelů s jejich storyboardy a konkrétními continuity kritérii. Není nutné přikládat celý komiks každému review.

Model review pass → completed_reviewed, uncertainty → needs_review. Identita a detaily mohou být chybně posouzené; pro vydání určené k veřejnému použití se zachovává možnost povinného lidského schválení všech panelů. Nepoužívat průměr skóre, který zakryje selhání jednoho povinného atributu postavy.

## 11. Cílené opravy

Automatická další kresba maximálně jedna na panel a jen v rozpočtu. Opravuje konkrétní failed kritéria při zachování schválené scény. Změna příběhu není image repair. Pokud problém vyžaduje nový scénář, vytvoří se explicitní revision a invalidují jen dotčené panel WorkOrder a jejich continuity sousedé. Ostatní přijaté panely zůstávají.

Při změně jedné entity invalidovat panely, které na její revision opravdu odkazují. Změna globální bible invaliduje všechny panely používající onu bible revision, ale staré verze se nesmažou. Pokud je výsledek drahý a již existuje, ukázat rozsah a očekávanou novou cenu před autorizací, ne automaticky regenerovat celou knihovnu.

## 12. Lokální textová sazba

Dialogue texty se berou z approved script/human editor beze změny. Layout převede normalized box na cílové pixely a určené DPI. Font musí být dostupný v instalaci se schválenou licencí; při chybě se nabídne explicitní volba a nevkládá se do artefaktu neznámý náhradní font bez evidence. Tento změnový ZIP žádné fonty nepřikládá.

Počáteční text size12pt, nejvýše18pt, minimum10pt při cílovém DPI. Použít skutečné QFontMetrics/layout měření v rendereru; při overflow zmenšovat po0,5pt do10pt. Jestli text stále nevejde, `TEXT_OVERFLOW`, ne uříznutí, zmenšení podminimum nebo modelové přepsání repliky. Počet overlay<=40, každá box uvnitř plátna, dvě textové body boxes se nesmějí překrývat bez explicitní ruční autorizace kompozice. Tail má svoje normalized souřadnice a nesmí skrýt další povinný text.

Sazba je samostatný odvozený asset; raw kresba zůstává bez bublin. Při změně jen textu nebo fontu se AI kresba nespouští znovu. SHA renderu zahrnuje raw image hash, dialogue hashes, boxes, font identity, velikosti, DPI a renderer verzi.

## 13. Export a finální stav

PNG export jednotlivých panelů a ZIP panelů používá skutečné final rendered assets. PDF export se skládá lokálně z přijatých renderů podle explicitního page layoutu a uloží pořadí panelů, DPI, padding/crop transformace a profile hash. Změna DPI metadat sama nevytváří vyšší nativní rozlišení; UI to musí uvést. Výstup se kontroluje otevřením/počtem stránek, úplností panel IDs a nepřítomností text overflow.

Projekt je completed_reviewed, pokud všechny povinné panely prošly modelovým review a lokální sazbou; completed_human_approved po potvrzení aktuálních hashů člověkem. `completed_verified` se používá pouze pro deterministické technické exportní brány s jejich přesným omezeným významem, ne jako tvrzení dokonalé identity nebo literární kvality. Mixed accepted/failed výsledek je partial a export přijatých variant je explicitně označen.

## 14. Restart, knihovna a kompatibilita

Při restartu pro každý operations record znovu ověřit status/journal, nevolat `_entity` či `_bible` znovu jen proto, že UI nevidí aktivní worker. Zapsaný image_submitting bez potvrzení je submission_unknown. U nativní LIVE Image operace nemusí existovat vyhledatelný provider response objekt; tento případ nelze automaticky opravit novou generací bez rizika duplicitní ceny.

Migrace SQLite je transakční, s předchozí zálohou schématu a control sum počtů projektů/entity/panel/version/asset. Originály a historické operace zůstávají čitelné. Nové narrative tabulky a orchestration references se přidají, ne nahrazují staré assets. Koš/archivace zůstávají lokální explicitní operace; smazání lokálního panelu nesmí automaticky smazat sdílenou vzdálenou referenci.