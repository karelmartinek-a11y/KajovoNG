# GENERATE a MODIFY — přesný výrobní postup

## 1. Stávající kód a rozsah změny

Výchozí cesty jsou `runs/generate.py`, `runs/modify.py`, `delivery_preparation.py`, `requirements.py`, `context_compiler.py`, `generate_batch.py`, `runs/file_execution.py`. Main již používá samostatné přípravné kontexty, strict výstupy, omezené opravy a úplné souborové odpovědi. Tyto vlastnosti zachovat. Nová změna nepřepisuje opravený A3 zpět na chunking.

Zásadní doplnění: skutečně verzované mezikrokové kontrakty, SourcePack, menší oddělené A2 části, samostatné výrobní modely také pro MODIFY, trvalý checkpoint `plan_ready`, univerzální budget/journal, cílené ověření a publikace. Přesné wire masky jsou v `contracts/wire`, nikoli jen slovní popis polí.

## 2. Konfigurace před zahájením

Požadované UI hodnoty: workflow, text zadání, schválené zdroje, výstupní adresář, modely přípravy a výroby, Standard/Maximum Quality, LIVE/BATCH výroba, stop_after_plan, budget, verification_profile, automatické opravy off/within_approval. U MODIFY povinný zmrazený IN; dry_run booleovský. Vše se zapíše do `RUN_CONFIG_V2` a schválení `EXECUTION_AUTHORIZATION_V1`.

GENERATE nesmí změnit existující cizí soubor bez expected hash a souhlasu. MODIFY add nesmí mířit na existující cestu; modify musí mířit na existující povolený textový soubor. Odstranění a rename nejsou součástí tohoto kontraktu: uživatelský požadavek je vyjádřen jako needs_input nebo explicitní změna scope. Implementátor nesmí zapnout delete skrytým mapováním na prázdný content.

## 3. Fáze A0 / B0: lokální příjem

Nevyvolává OpenAI. Zmrazí SourcePack, případné originály a inventář projektu. Uloží file hashes, byte sizes a typy. Přílohy stejného assetu se nenahrávají dvakrát v rámci účtu/purpose, pokud existující vzdálené ID je platné. Odpověď upload není důkaz, že model zdroj četl; tento rozdíl se eviduje.

`plan_ready` a `stop_after_plan` zůstávají dostupné po restartu. Neprovádět placené technické potvrzení přijetí každých 20 000 znaků. Dlouhý text řeší SourcePack/extraction politika z dokumentu o kontextu.

## 4. A0R/B0R

A0R zpracuje zdrojový záměr, požadavky, invarianty, flows, lifecycles a acceptance. B0R navíc oddělí požadovanou změnu od zachovávaného chování a migrací. Výstup musí projít wire a sémantickou validací před A1/B1.

B0R smí použít read-only nástroje pro předem schválený projektový inventář. `read_project_slice` vrací zmrazené řádky, ne živý obsah souboru, který se mezitím změnil. Nejvýše 4 calls v jedné odpovědi a 8 v tasku. Když potřebuje více obsahu, vrátí missing_input; neobchází limit dalším nepřiznaným taskem.

Baseline ověření MODIFY se provede před B1 v sandboxu, pokud byl schválen dostupný profil. Uložit seznam existujících selhání, verze prostředí a hash všech vstupů. Nedostupná baseline není čistá baseline. Profil `baseline_required=true` blokuje bez důkazu; při uživatelem výslovně povoleném neověřeném režimu musí zůstat neověřený i finální výsledek.

## 5. A1/B1

A1 spotřebuje validované requirements a vybere architekturu a integrační pravidla. Musí existovat komponenta pro každý mandatory požadavek. External packages mají registry a verzi/constraint, ovšem model nesmí vymýšlet lockfile integrity. Lockfile vzniká pouze opravdovým package managerem v samostatně schváleném sandboxu.

B1 určí disjunktní add/modify/preserve seznamy a mapu ovlivněných rozhraní. Seznam musí respektovat IN snapshot. Přímé reference na interní soubory se ověří proti inventáři. Názvy externích knihoven nejsou interní paths. Pokud plán rozšiřuje scope mimo schválenou změnu, program nepostoupí na B2.

A1 již nemá `deliverable_policy.max_lines_per_chunk`. Zachovat pole pouze ve starém čtecím adaptéru. Nevyžadovat po modelu transportní bookkeeping, který aplikace zná.

## 6. A2_SPINE/B2_SPINE

Jedna LIVE úloha navrhne autoritativní index souborů, přesná veřejná rozhraní, dependencies a vlastníky globálních povinností. Otevřené symboly se nesmějí nahradit pouze větou „propojit moduly“. Pro symbolové rozhraní je povinná importní cesta/export, signatura a typy, chybová sémantika a lifecycle. Pro HTTP rozhraní metoda/path, request/response kontrakty a stavové kódy; pro event pojmenování, payload a doručovací/idempotency semantics; pro persistence transakční hranice a reprezentace.

`interfaces.definition/input_contract/output_contract` jsou implementační definice, nikoli zdrojový kód provideru. Jejich strojově analyzovatelnou přesnost lze ověřovat jen adapterem pro konkrétní jazyk/protokol; pouhý neprázdný string není důkaz funkčnosti. V přejímce se vyžaduje parser/interface test pro zvolený stack.

`dependency_content_mode=contract`: consumer nepotřebuje implementační obsah provideru. `verified_content`: požaduje přesný obsah a musí uvést důvod. Právě tento příznak vytváří výrobní čekací hranu. Standardní import knihovny ani samotné `requires` jej nevynucuje.

Binární prostředky nesmí zůstat neřešenými soubory se skeletonem. Pro každou `binary_required` položku `resource_deliveries` určí přesný producer: existující asset, samostatný image workflow, lokální renderer nebo povinný ruční vstup. Bez připraveného assetu zůstává celý projekt `partial`; nevytvořit falešný prázdný PNG.

## 7. A2_DETAIL/B2_DETAIL

Pro každý textový generate/add/modify soubor vytvořit jednu LIVE úlohu DETAIL. WorkOrder již obsahuje target path; výstup `A2_FILE_SPEC_V1`/`B2_FILE_SPEC_V1` cestu neopakuje. Vstup je cílový file_entry, jeho relevantní requirements, interfaces a globální povinnosti. U B2_DETAIL také úplný originální cílový soubor a pouze nezbytné přímé zdrojové závislosti.

Každý kontrakt definuje behavior, konkrétní facets, required_facets, interface bindings, acceptance IDs, given/when/then scénáře, expected_visible_tokens, allow_empty a preserved behavior. Chybějící kritický detail vrací blocked, nikoli ready s TODO. Default allow_empty=false. Oprávněné prázdné `__init__.py` musí být výslovně deklarováno již zde.

Preserved soubor v B2 nemusí být znovu odborně generován: jeho provider kontrakt vzniká lokálně z ověřené existující definice nebo z B0R/B1 důkazu. Jeho původní bajty se nepředávají do výrobní generace. Expected hash je povinný, protože downstream reuse musí odhalit změnu originálu.

## 8. Lokální sestavení a brány grafu

Aplikace spojí SPINE a DETAIL do `IMPLEMENTATION_GRAPH_V3`. Každý povinný detail je právě jednou, žádná neznámá cesta. Všechny refs se resolvují, každý required interface má provider v povolené dependency množině. Žádné casefold/file-directory kolize, absolutní cesty, `..`, alternate data stream nebo Windows rezervovaná jména. Relativní cesty mají interně `/`.

Rozlišit dva grafy: (a) contract dependency graph a jeho SCC, (b) actual content dependency graph. Cyklické kontraktní rozhraní lze koordinovat ze zmrazených signatur. Cyklické vyžadování již ověřeného skutečného obsahu je neproveditelné a blokuje. Pokud A potřebuje obsah B, ale B potřebuje pouze kontrakt A, B lze vyrobit první; nezakazovat to jen kvůli SCC v kontraktním grafu.

Po lokálním sestavení není žádný „AI merge“ stejných dat. Zapsat hash grafu, source/requirements/plan hashes a bezpečný checkpoint. V případě stop_after_plan skončit `plan_ready` bez A3/B3.

## 9. A2Q/B2Q a opravy grafu

Maximum Quality přidá review aktuálního grafu proti záměru a acceptance. Výstup je `STRUCTURE_REVIEW_V1`. Typované replacements mají očekávaný hash nahrazované hodnoty. Aplikovat celou sadu na kopii, ověřit registry/coverage/dependency/facets a až poté transakčně publikovat novou revizi. Původní graph zůstává nedotčený.

Review nesmí oslabit mandatory požadavek, odstranit acceptance ani změnit autoritativní explicitní volbu. Oprava chybějícího souboru/rozhraní může vyžadovat nový SPINE. Takový re-plan je samostatně evidovaná úloha, nejvýše jeden automatický re-plan na generaci projektu a jen v předem schváleném repair budgetu. Již přijaté věcně nezměněné DETAIL objekty se znovu negenerují.

## 10. A3/B3 LIVE

Cílová jednotka je úplný jeden soubor. Vstup `FileContext` obsahuje: target path a action z WorkOrder, konkrétní file_spec, relevantní requirements/acceptance, precise shared interfaces, povinné globální invariants, případné vybrané ověřené dependency artefakty a u modify úplný originál. Neobsahuje celý auditní snapshot, historii ostatních souborů ani předchozí kandidáty.

Použít jeden builder jako pro Batch. Model vrací pouze `{content:string}`. Po dekódování ukládat obsah přesně jako UTF-8 bez BOM; žádné automatické přidávání/odstraňování newline. BOM uvnitř požadovaného obsahu je formátová chyba, pokud souborový kontrakt neurčuje jinak. Program provede wire→content→syntax→interface brány a uloží výsledek do stagingu.

Při schema/content chybě nejvýše dva opravné pokusy s čerstvým stejným kontextem a posledním chybným kandidátem. Nikdy kandidát1+2+3. Opravný prompt obsahuje přesné chyby. Každý pokus se měří znovu, nezíská bezplatně větší kontext. Při stejné dvojici candidate hash/error signature dvakrát zastavit jako `NO_PROGRESS`.

## 11. A3/B3 BATCH a vlny

Výběr Batch nemění přípravu, kontrakty ani verification. Změní jen transport samostatných výrobních tasků. `custom_id` je application-owned krátká stabilní identita task+attempt, bez path. Model+endpoint+wave+policy tvoří skupinu. Rozdělit stabilním pořadím task ID, nejvýše 50 000 položek a 195 MB cílově; finální UTF-8 JSONL musí být pod 200 MB.

Před odesláním validate všechny rows a rezervuj celou dávku. Nahrát přesně pracovní JSONL purpose=batch, uložit jeho hash a input_file_id, potom jediný POST /batches s completion_window=24h. Žádná zkušební dávka. Pokud nelze rezervovat celek, batch se neposílá částečně potají; UI nabídne menší výběr a nové schválení.

Consumer čekající na `verified_content` dostane nejdříve providerův obsah, který prošel přesně deklarovanou provider acceptance. Staticky korektní provider se nesmí označit za integračně prověřenou celou aplikaci. Doklad má target hash, contract hash a verification profile. Pokud plné ověření provideru závisí na dosud neexistujícím consumeru, použít ověřitelný interface/static gate pro dependency transfer a finální integrační gate po kompletaci. Profil musí tento rozdíl jmenovat; zakázat kruhovou závislost na „už celé hotové aplikaci“.

## 12. Import a opakování

Stáhnout output i error soubor, zachovat raw byty. Zmapovat custom_id na uložený immutable row. Odmítnout neznámé/duplicitní ID, nesoulad endpoint/model binding a nekompletní Response. Zpracovat i úspěšné položky z expired/cancelled/failed terminal dávky, pokud poskytovatel skutečně dodal jednotlivé completed odpovědi. Neukončené položky zůstanou chybějící.

Samotný import nikdy nespouští novou generaci. Je restartovatelný a idempotentní; již přijatý hash se nezapisuje znovu. Neúspěšné položky se po autorizaci odešlou jako nová pracovní dávka pouze pro chybnou množinu. Množina závislých consumerů se nejdříve znovu ověří; jejich regenerace je nutná pouze při změně relevantního kontraktu/obsahu nebo prokázané chybě, nikoli plošně.

## 13. Verifikace a opravná eskalace

Po všech povinných artefaktech sestavit čistý sandbox snapshot. Povinné brány: parser všech podporovaných formátů; deklarované interfaces; build; test suite; acceptance coverage; deklarovaný smoke. Nedostupná závislost, nula skutečně spuštěných testů, chybějící očekávaný endpoint nebo absentující profil blokují `completed_verified`.

Diagnostický normalizátor převádí compiler/test chyby na omezený seznam `ErrorRecord`, zachovává raw důkaz lokálně. Oprava souborové chyby neprovádí nový A0R. Interface conflict eskaluje na skupinu a případně graph. Produktový rozpor vyžaduje nový scope approval. Automatické systémové repair generace projektu jsou nejvýše dvě; nedovoleno vytvořit třetí novou lineage jen pro obejití limitu.

MODIFY porovnává stejné baseline checks se změněnou verzí. Nově vzniklé selhání je regrese. Předexistující selhání zůstane explicitně uvedené a neumožní tvrdit, že projekt je bezchybný. Nové akceptační testy schválené změny nesmějí být odvozeny jen od toho, co model náhodou implementoval.

## 14. Finální výstup

`completed_verified` pouze po přijetí všech povinných důkazů pro přesný final snapshot. `files_complete_unverified` je přiznaný mezistav/neověřený deliverable. `partial` znamená chybějící povinné položky. `verification_failed` musí zachovat soubory i důkazy pro další práci. Vypsat v UI kolik validních artefaktů vzniklo, co chybí a která brána blokuje; nepoužít univerzální neurčité „špatná struktura“.

Publikace chrání uživatelské změny expected hash kontrolou. Dry-run vrátí diff, manifest a verification report ze stagingu; IN/OUT ani Git se nemění. Volba Převzít neověřené musí mít v UI i exportu zřetelný status a nesmí přepsat verification evidence na passed.