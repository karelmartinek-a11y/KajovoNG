# Fotografie — od zadání po přijatý obraz

## 1. Cesty a závazné zachování funkcí

Upravit `photo_prompt.py`, `photo_batch.py`, `image_runtime.py`, `studio/photos.py` a společný transport. Zachovat výběr konkrétních fotografií, šablony, ruční prompt, profesionalizaci, Batch přehled, stažení, původní soubory a historii úloh. Výběr v UI je explicitní; neodesílají se automaticky všechny fotografie v seznamu či adresáři.

Nová sekvence: lokální validace a zmrazení → volitelný PHOTO_PLAN → schválení WorkOrder/rozpočtu → skutečná image editace → technická validace → obsahový review → nejvýše jedna autorizovaná cílená oprava → přijetí nebo needs_review. Stejný mechanismus se používá pro malý LIVE image požadavek i Batch. LIVE volba je nově přesně řízená, ne automatický dražší fallback po nepřijaté dávce.

## 2. Modely a readiness UI

Katalog se načte z account-scoped cache při otevření aplikace; není třeba nejdříve ručně navštívit Modely. Po úspěšném explicitním refresh se uloží validovaná metadata, všechny editovatelné selectory vyberou doporučení pro svůj účel. Prompt/vision model a native Image model jsou oddělené role. Obrazový selector vyžaduje image_edit pro danou route; pouhá podpora image input u textového modelu nestačí.

Readiness má stavy loading, ready, cached, refresh_failed_using_cache, no_compatible_model, missing_key. Tlačítko Spustit je aktivní jen při reálném kompatibilním modelu, nejméně jedné vybrané validní fotografii, neprázdném finálním zadání a schválené cenové/tokenové policy. Loading nesmí být vysvětleno chybným „nejsou vybrány fotografie“. Technické selhání katalogu se neobejde natvrdo vyplněným modelem.

## 3. Zmrazení a normalizace zdrojů

Ke každému obrázku vytvořit original asset z přesných bajtů a normalized asset. Před přijetím kontrola skutečného formátu a plného dekódování: Pillow verify i load, statický PNG/JPEG/WebP, rozměry a maximální velikost podle minima policy/modelu. Sjednotit současný rozdíl foto100MB a comic50MB; aplikace používá policy50 000 000 bajtů nebo přísnější limit modelu. Image vstup odlišit od obecného Files API upload limitu.

Normalizace jednou: EXIF orientation → RGB/RGBA → PNG bez soukromých EXIF metadat. Původní bytes zůstanou uchované, stejně tak popis transformace. Input path je jen původní jméno; upload používá zmrazený asset, ne později změněnou fotografii. Ověřit hash před uploadem a po načtení z artefaktového úložiště. Chybějící originál se nesmí nahradit jinou verzí stejného názvu.

Deduplikace dvou fyzických cest se stejným normalized obsahem může sdílet upload, nikoli ztratit dvě uživatelem požadované výstupní položky. Každý výstup má vlastní target_id; stejné input bytes a stejné schválené instrukce lze reuse jen s explicitním `reuse_identical_result=true` nastavením, jinak jde o dvě záměrné variace a dvě rezervace.

## 4. Ruční versus profesionalizované zadání

Ruční finální prompt je autoritativní. Aplikace z něj lokálně vytvoří jednu operaci `other` a jedno povinné review kritérium „splnit tuto žádost“ plus explicitní preserve policy z UI; žádné placené přepisování navíc. Jemnější kritéria si uživatel může zadat sám.

Tlačítko Profesionalizovat vyvolá `PHOTO_PLAN_V1` jednou pro skupinové zadání. Model dostane žádost, povolené úpravy a preserve požadavky, nikoli automaticky všechny originální fotografie. Je-li nutná vizuální interpretace konkrétní fotografie, UI tuto volbu uvede a vytvoří samostatný per-image plán; nesmí skrytě přidat stovky vision callů. Výsledek plánu se zobrazí a schválí; původní text zůstane dohledatelný. Rozšíření úpravy mimo žádost nebo neurčitá identita objektu znamenají blocked otázku.

Finální image prompt sestaví lokální renderer v deterministickém pořadí: přesné edit instructions → preserve invariants → vazby referenčních slotů → cílový formát/kompozice. Nevkládá JSON Schema ani systémovou historii do image promptu. Zvolený text se hashově sváže s image WorkOrder.

## 5. Native Image request

Editace: `POST /v1/images/edits`; obraz bez reference generace jen v příslušném explicitním workflow, nikoli default Fotografií. JSON body používá ověřenou modelovou cestu `images:[{file_id:...}]` podle capability a aktuální dokumentace; implementátor nesmí vytvořit hybrid multipart/JSON, který endpoint nepodporuje. Pro podporované JSON file-ID image requesty je přesný vzor v examples. Model s jiným doloženým transportem vyžaduje samostatný schválený adapter a není implicitně eligible.

Povinné parametry: přesný image model, prompt, n=1, size, quality, output_format a image background. Výchozí output png, quality high, background opaque. `input_fidelity` se přidá jen když profile přesně doloží podporu zvolené hodnoty; jeho nepřítomnost je rozhodnuta před schválením. Neposílat textové `reasoning`, `text.format`, `max_output_tokens`, boolean background ani previous_response_id do Image API.

Rozměry neodvozovat pomocí startswith názvu. Použít capability.allowed_sizes nebo capability numeric limits. Při preserve_aspect enumerate legální rozměry a minimalizovat `abs(log((w/h)/(source_w/source_h)))`, potom rozdíl plochy od vybraného cíle, potom menší plochu a lexikograficky w,h. Při žádném legálním kandidátu blokovat. UI zobrazí generovací i finální rozměr; upscaling v postprocess se neoznačuje za nativní detail modelu.

## 6. Batch

Každá vybraná fotografie je vlastní task. Sdílená dávka má stejný endpoint/model/wave/policy, ale odlišné custom_id. Input_file_id a JSONL hash se uloží před submit. Po ztrátě odpovědi se provádí přesná stránkovaná reconciliace; žádný druhý POST bez výslovného nové rizikové autorizace. Limit50k/200MB se kontroluje na finálních bajtech.

Výsledky nejsou v garantovaném pořadí. Mapovat přes uložený custom_id. Každá položka může uspět či selhat nezávisle; chybu status400/missing b64 nelze označit downloaded. Nedokončené položky se neopakují spolu s již přijatými bez požadavku na novou variantu.

## 7. Technická validace výsledku

Musí existovat právě jeden obrazový výsledek. Base64 dekódování není validace fotografie. Před importem provést signature/format check, Pillow verify/load, statickou frame count, model/policy limity, skutečný output format a rozměry. Výsledek s neodpovídajícím PNG/JPEG nelze opravit pouhým přejmenováním přípony. Uložit raw output odděleně od lokálně převedeného exportu; lokální převod na jiný formát je vlastní evidentní operace.

Ověřit transparentnost proti požadavku, výstupní target a očekávané postprocess kroky. Poškozený soubor s validní base64 jde do failed, nikoli do dalšího vision review. Uložení je atomické a hashově ověřené. Kód testující `fake-png-bytes` musí čekat odmítnutí; validní test používá skutečné dekódovatelné obrazové bajty.

## 8. Obsahové review

PHOTO_REVIEW přes Responses vision dostane originál, kandidáta, finální edit instructions a přesnou acceptance/preserve sadu. Ne všechny ostatní fotografie. Schema IMAGE_REVIEW_V1 vyžaduje per-criterion pass/fail/uncertain a evidence regiony/reference slots. Aplikace sama vyhodnotí celkový stav: všechna mandatory kritéria přesně jednou pass a žádné nevyřešené unrequested change → `completed_reviewed`; fail → opravná fronta; uncertain nebo chybějící kritérium → needs_review.

Modelové hodnocení není kalibrovaný měřicí přístroj. Nepoužívat automatický práh „confidence >0,8 znamená zaručeně správně“. Identita člověka, jemné texty, geometrie a malé artefakty mohou být posouzeny chybně; u kritických marketingových či věrnostních úprav vyžadovat lidské přijetí. Potvrzení člověka je svázáno s kandidátovým hashem, ne pouze filename.

Výchozí review je LIVE, nejvýše dvě paralelní úlohy, aby po image Batch nevznikalo další zbytečné čekání24h. Uživatel může předem zvolit review Batch; UI musí ukázat další okno čekání a samostatnou rezervaci. Tato volba nemění kritéria.

## 9. Přesně omezená oprava

Automatická obsahová oprava je maximálně jedna další image generace po prvním kandidátovi. Musí být autorizovaná již při startu nebo nově po review. Vstup: původní obraz, aktuální kandidát jako druhý slot, původní závazné zadání a konkrétní failed kritéria. Nepřibalovat všechny předchozí varianty, logy ani generované posudky jako další volný záměr.

Potom znovu technická validace a review proti původnímu zadání. Pokud druhá verze selže nebo je nejistá, zastavit needs_review. Nepřeskočit na jiný model, nezkoušet nekonečně nové prompty. Uživatel může spustit další variaci, ale jde o nové viditelné schválení v téže lineage a se společným limitem útraty.

## 10. Pixelově chráněné oblasti

Přesnou shodu nevyžádaných oblastí nelze garantovat promptem. Režim `local_exact_composite` proto vyžaduje uživatelem schválenou binární masku. Po generaci aplikace složí změněné pixely jen tam, kde mask=1, a všude jinde vezme pixely normalizovaného originálu. Exact znamená shodu dekódovaných normalizovaných pixelů, nikoli shodu původních komprimovaných JPEG bajtů. Uložit origin/normalized/mask/candidate/composite hashe.

Rozměrové zarovnání musí být předem definováno; pokud model nedodá požadovanou velikost, provést pouze schválenou transformaci nebo blokovat. Není dovoleno masku dynamicky posunout podle modelového názoru. Antialias/feather varianta je jiný režim a nemá nárok tvrdit pixel exact. V této verzi je podporována jen binární maska a lokální přesné složení.

## 11. Výstupy a UI

U každé fotografie zobrazit originál, zvolený kandidát, skutečné rozměry, model, route, cenu/nejistotu, technickou validaci a obsahové hodnocení odděleně. Staženo, technicky validní, modelem zkontrolováno a člověkem přijato jsou čtyři rozdílné vlastnosti. Žádný plně zelený „hotovo“ jen po zápisu bytes.

Export názvů používá application target a bezpečné řešení kolizí `name_edited`, následně příponu krátkého task ID. Žádné přepsání originálu; explicitní nahradit originál je mimo tento změnový rozsah. Zrušení pozorování nezruší provider Batch, remote cancel musí být potvrzen. Výstupy i po přerušení zůstávají obnovitelné bez opětovné útraty.