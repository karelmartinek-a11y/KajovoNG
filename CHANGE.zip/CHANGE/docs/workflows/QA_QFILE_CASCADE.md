# QA, QFILE a kaskády

## 1. QA — textová odpověď jako produkt

QA není zkrácený GENERATE. Nevyžaduje A0R/A1/A2, pokud uživatel výslovně nežádá přípravu softwarového produktu. Vstup je otázka, schválené zdroje a explicitní režim kontextu. Výstup `QA_ANSWER_V2` obsahuje answer, claims s evidence IDs a certainty a limitations. Doménová aplikace vykreslí answer běžně, evidence a nejistoty odděleně; uživateli neukazuje strojovou obálku místo odpovědi.

Nová QA používá `artifact` kontext; Pokračovat v rozhovoru zvolí uživatel a tím se přepne do `conversation` s konkrétní lane. Na nový dotaz bez této volby se historie nepřipojuje. UI ukazuje, že předchozí vstupy mohou být znovu účtovány. Před každým turnem universal BudgetGate včetně serverové historie. Model smí používat pouze připojené file_search/read-only nástroje dle scope, nikoli obecný web či host shell.

Tvrzení `certainty=supported` musí referencovat existující odeslaný nebo právě retrievovaný evidence record. Citace není automaticky důkaz, že tvrzení je pravdivé. U zdravotních/právních/finančních nebo časově proměnlivých dotazů tento interní workflow bez schváleného aktuálního zdroje uvádí omezení; nevyplňuje jistotu modelem. Stav odpovědi je `answer_delivered` v UI mapovaný na `completed_unverified`, není `completed_verified`, pokud neexistuje explicitní check profile.

Refusal se zobrazí jako refusal, ne jako chyba JSON a nevynucuje se opakovaně. Incomplete/max_output je samostatný neúspěch s možností autorizovaného dalšího plného pokusu, ne slepený text vydávaný za úplný. Max 3 pokusy včetně prvního. Pokud QA nemá strukturované claims, generování prázdných falešných zdrojů je chyba; povolený je prázdný claims seznam a zřetelně neověřená odpověď.

## 2. QFILE — jeden soubor

### 2.1 Určení cíle

Přidat UI pole Výstupní cesta a Výstupní formát. Je-li cesta výslovně vyplněná, aplikace ji ověří, zafixuje do WorkOrder a žádný plánovací model pro název nevolá. Je-li cesta prázdná a uživatel zvolí Navrhnout název, provést QFILE_PLAN_V1 a ukázat proposed_path, format, purpose a acceptance. Uživatel potvrdí před placenou výrobou souboru. Není dovoleno použít libovolnou path z následné modelové odpovědi při zápisu.

Současný `runs/qfile.py` obsahuje rozporný inline vzor s chunk_count=0 a max500 řádky proti přísnému jednorázovému wire kontraktu. Tento inline text odstranit, stejně jako duplicitní připojování stejných IO instrukcí. Nový QFILE používá společný FILE_CONTENT_V1 a stejný parser a repair jako A3/B3.

### 2.2 Výroba a přijetí

Vstup: text požadavku, důvěryhodný target path/format, explicitní allow_empty, relevantní přílohy a acceptance. Žádné requirements/plán všech souborů. Výstup přesně `{content:string}`. JSON/TOML/YAML/XML/SVG/HTML/kód se kontroluje dostupným parserem bezpečně bez spuštění. SVG/XML parser vypne external entities, externí síťové zdroje se nestahují. Prostý text má encoding a explicitní obsahové kontroly, nikoli vymyšlený test funkčnosti.

CSV je v této aplikaci textový artefakt, ne import spustitelného makra. Při tabulkovém použití varovat u buněk začínajících `=`, `+`, `-`, `@`; data se tiše nepřepisují, bezpečný export je výslovná policy. PDF/docx/xlsx nejsou výsledkem přejmenování raw textu. Takový požadavek musí směřovat do schváleného lokálního rendereru s vlastní datovou maskou a skutečnou validací, jinak `FORMAT_UNSUPPORTED`.

QFILE BATCH v této změně nezavádět; zachovat jeden LIVE soubor. Případné hromadné nezávislé QFILE lze vyjádřit kaskádou jednotlivých úloh v pozdější verzi, ne skrytě změnit existující toggle. Stav `file_written_unverified` se mapuje na completed_unverified. Samotný kompletní content není důkaz splnění literárního/odborného zadání.

## 3. Kaskáda v3 — cílový kontrakt

Lokální definice je `CASCADE_DEFINITION_V3`: immutable id, start_step_id, steps, final_outputs, final_acceptance. Každý krok má kind, context_mode, lane, instructions, input/output contract, explicitní bindings, lokální vstupy, model, execution, max_visits=1, decision_targets a acceptance IDs. Neopírat vazby o číslo řádku v UI; viditelné pořadí je jen projekce stabilních ID.

Typy kroků: `ai`, `local_transform`, `decision`, `file_render`. AI a modelové decision volají Responses. local_transform a file_render jsou deterministické povolené funkce aplikace a nesmějí skrytě zavolat AI. File render může přijmout už validovaný text nebo typovaný dokumentový model; nikdy nesmí z JSON textu vytvořit zdánlivé binární PDF jen změnou přípony.

## 4. Přímý typovaný JSON místo serializace do stringu

Současná deterministická kaskáda instruuje model, aby JSON hodnotu vrátil serializovanou do řetězce. Nový output contract vloží konkrétní JSON schéma přímo jako podobjekt. Například `items` je skutečné pole objektů, nikoli string obsahující `[{...}]`. Maska pro ukázkovou extrakci je v CASCADE_EXTRACT_V1 a negativní vzor v `examples/negative/cascade_json_string.json` musí být odmítnut.

Na wire je pro každý krok jeden schema root. Klíče vznikají z application-owned output IDs s krátkým stabilním hashem, nikoli pouze ořezem viditelného názvu na64 znaků. Kontrolovat kolize před uložením definice. Dva názvy, které se po normalizaci shodují, nesmějí sdílet výstupní pole. Jméno v UI není strojová identita.

## 5. Schéma uživatelského kroku

UI umožní přímo sestavit podporovaný DSL: object fields, array items, string, integer, number, boolean a enum. `SCHEMA_DSL_V1` je typovaný strom; generovaná schema proposal není JSON vložený do stringu. Návrh schématu AI se vyvolá pouze tlačítkem Navrhnout kontrakt a je účtovanou pracovní operací. Po schválení se DSL lokálně zkompiluje do JSON Schema, verzuje a hash zmrazí. Při každém běhu se stejné schéma znovu negeneruje.

Podpora: nejvýše128 vlastností v uživatelském kontraktu, hloubka8, nejvýše100 enum hodnot na pole, žádné externí `$ref`, žádný executable validator od modelu. Ostatní JSON Schema konstrukce UI v této verzi nenabízí. Všechny objects jsou closed a všechny props required. Volitelné hodnoty jsou samostatnou explicitní nullable variantou jen tam, kde ji podporuje kompilátor; bez této volby se `null` nepřijímá.

Vzorky nepodporovaných či příliš velkých schémat se odmítají před placeným taskem. Neopravovat uživatelovo schema tichým odstraněním constraints. Nová verze schema invaliduje jen kroky, jejichž input/output kontrakt skutečně změnila, a jejich závislé výstupy.

## 6. Kompilace vazeb

Před spuštěním zkompilovat celý graf. Binding definuje source_step_id, source_output_name, selector JSON Pointer, expected_contract a required. Každý zdroj musí být před consumerem; required producer musí consumeru dominovat v řídicím grafu. Pokud je zdroj dostupný jen v jedné větvi rozhodnutí, druhá větev musí mít explicitní local default s vlastním kontraktem nebo consumer není validní.

Type assignability je přesně omezená: shodné primitive types; integer lze vložit do number; enum producenta musí být podmnožina enum consumeru; array vyžaduje kompatibilní items; object musí dodávat všechna required pole consumeru a při closed consumeru nesmí přidávat jiná; nullable producent není přiřaditelný nenullable consumeru. Žádné automatické string→number, JSONstring→object ani modelové opravování typů. Runtime znovu validuje konkrétní přenesenou hodnotu.

Decision vrací pouze enum value; target mapu vlastní definice. Neexistující value nevybere „nejbližší“ větev. Neznámý target, zpětný skok nebo cyklus blokuje preflight. Přeskok kroku se eviduje skipped_by_branch a nepočítá se jako dokončená generace. Povinný finální výstup ze skipped větve nesmí vytvořit completed stav.

## 7. Kontext kaskády

V režimu artifact se do každého kroku vloží pouze jeho deklarované bindings a lokální input. Nedědí automaticky předchozí odpověď jen kvůli stejnému context_id. Takový současný mechanismus by opakoval explicitní output zároveň v provider historii.

V conversation režimu se smí použít stejná lane pouze pro stejný schválený model a společný konverzační účel. Běžné mezikrokové hodnoty z této lane se nepřipojují explicitně znovu; vstup obsahuje jen nové položky a pokyn. Pokud uživatel potřebuje přesné strojové bindings starého výstupu, zvolí artifact režim. UI tuto kombinaci validuje a neumožní „obojí pro jistotu“.

Vektorové vyhledávání je doplňková evidence, ne jediný nosič mandatory binding. Každý input_file je deduplikovaný podle immutable asset identity; obsah stejného souboru se nevkládá současně inline i jako příloha bez explicitního rozdílného účelu.

## 8. LIVE/BATCH uvnitř kaskády

Základní sekvenční kaskáda zůstává LIVE. Nová v3 smí označit konkrétní AI uzly BATCH pouze v artifact režimu, bez custom tools a bez aktivní conversation lane. Scheduler seskupí nezávislé ready uzly podle endpoint/model/contract policy, ne celou kaskádu. Decision uzel se batchuje jen tehdy, když nemá časově kritickou interakci; v této verzi default zůstává LIVE a UI Batch volbu pro decision nenabízí.

Přechod na consumer čeká na převzetí a sémantické přijetí konkrétní položky, ne pouze provider batch completed. Není dovoleno odkazovat `previous_response_id` na jiný řádek téže dávky: pořadí není garantovaná orchestrace. U externího timeoutu uložit manifest a vrátit batch_pending.

## 9. Lokální transformace

Povolené operace: `json_pointer`, `select_fields`, `concat_text`, `format_template`, `render_json`, `render_csv`, `render_markdown`, `write_text_artifact`. Argumenty jsou typované a uložené v definici. Template substituce smí odkazovat pouze předem zkompilované binding names; žádný přístup k atributům libovolného Python objektu, žádné funkce, import ani filesystem. Regex v transformacích se v této verzi nepovoluje kvůli neomezené složitosti a nejasným bezpečnostním hranicím.

Výstup transformace projde stejným wire-equivalent lokálním schématem jako AI output. Lokální chyba není důvod generativně „uhodnout správná data“. Přepnutí na AI by bylo novou schválenou změnou definice.

## 10. Resume a konečný stav

Resume cache musí ověřit hash definice každého předchozího kroku, input bindings, model/policy a skutečné output hash. Pokračovat od pozdějšího kroku smí použít jen existující relevantní artefakty. Předchozí odpověď na serveru smazaná po retenci nebrání artifact režimu, pokud jsou kanonické výstupy dostupné; conversation režim musí rekonstruovat explicitně nebo blokovat.

Opravy jsou max initial+2, no-progress2. Celkový run budget platí napříč všemi kroky a dávkami. Kaskáda končí úspěšně jen s dostupnými final_outputs a splněným final_acceptance. Jinak finished execution může znamenat `completed_unverified`, `partial` nebo `needs_review`; není automaticky „hotový celek“.

Legacy v1/v2 definice se nikdy nepřepíše při otevření. Migrace vytvoří novou v3 kopii a vyžádá schválení změny původního implicitního context_id chování. Staré běhy zůstávají čitelné; nové odesílání legacy payloadu s duplicitním kontextem se bez migrace nepovolí.