# Stavové stroje, obnova, UI a podpůrné procesy

## 1. Dvě úrovně stavu

Task lifecycle je přesně v `state_machines/task.json`. Doménové názvy A0R, plan_ready, image_review a podobné jsou fáze/substavy, nikoli alternativní implementace status semantics. Run aggregate se odvodí ze všech povinných tasků a finálního acceptance profilu, ne z posledního zeleného workeru.

Terminální úspěchy mají odlišnou sílu: completed_unverified (doručeno, funkčnost neověřena), completed_reviewed (prošlo heuristickou/modelovou kontrolou), completed_human_approved (člověk přijal konkrétní hash), completed_verified (všechny povinné deterministické brány konkrétního profilu). Člověk ani model nemohou pozměnit výsledek neúspěšného technického checku na passed; mohou pouze schválit odlišné přijetí neověřeného výsledku s novou autorizací.

Žádný event nesmí přeskočit povinné guardy. Každý zápis stavu je compare-and-swap proti revision, append-only EventRecord má unique event_id a monotonní sequence. Neznámý event/state přechod je programmer error a blokuje provedení mutace. Modelový text „hotovo“ se nepoužívá k řízení stavu.

## 2. Přesná klasifikace odpovědi

Po přijetí provider obálky: nejdříve zkontrolovat odpovídající request/response ID a typ obálky pro route. queued/in_progress → remote_pending. failed/cancelled/expired → remote terminal failure, ale batch může obsahovat využitelné jednotlivé completed položky. incomplete nikdy nejde do canonical accepted artefaktu. Refusal je samostatný blocked důvod. completed s function calls není finální file/plan odpověď; validovat calls a pokračovat v omezené tool sekvenci. completed s finálním textem bez pending calls → strict JSON parse a semantic gate.

Neznámý provider status nebo nejednoznačné současné finální výstupy jsou `PROVIDER_PROTOCOL_UNSUPPORTED`. Zachovat raw a nevymyslet fallback parser typu vyber první JSON v textu. Historický legacy parser pro staré logy může zůstat tolerantní, ale nový wire parser musí být strict.

## 3. Zastavení a zrušení

Stop: přeruší místní práci na bezpečné hranici; u odeslané vzdálené operace zachová provider ID a rezervaci. Timeout HTTP/polling není cancel. Remote cancel: samostatné uživatelovo rozhodnutí; odeslat endpointový cancel jednou, potom retrieve do potvrzení. Pokud provider mezitím dokončil práci, převzít skutečný completed stav místo předstíraného zrušení. Cena již proběhlé práce se neztratí.

U práce dosud nesubmitované uvolnit rezervaci, task cancelled. U unknown submission nelze bezpečně prohlásit cancelled bez dohledání; UI tlačítko je Zastavit místní sledování, nikoli Zaručeně zrušit účetní operaci.

## 4. Restart a přesná obnova

Po startu nejprve načíst journal a immutable artefakty. Pro každý nedokončený task ověřit WorkOrder hash, schema/policy verzi a source refs. Se známým provider ID provést pouze retrieval. S neznámým ID a submitting intent přejít do submission_unknown. Nová generace se nesmí spustit proto, že RAM neobsahuje starý worker.

Batch reconciliace: úplná paginace s detekcí opakovaného cursoru, filtrovat přesné input_file_id a endpoint, ověřit očekávaný model přes uloženou lokální dávku/vrácená metadata. Právě jedna shoda → připojit; více shod → potřeba lidské účetní reconciliace; nula → zůstává unknown. Žádný algoritmus „po minutě nic nevidím, odešlu znovu“.

Historie Pokračovat vytváří nový Run ID a LineageRecord, ale reuses přijaté nezměněné artefakty, nikoli replatí jejich výrobu. Opravit tvoří nové tasky pouze v ovlivněné množině. Klonovat jako nové zadání je jediná akce, která otevře editovatelnou kopii bez okamžitého běhu. Zdrojový běh se nemění.

## 5. UI matice

| Stav | Povolené akce | Zakázané akce |
|---|---|---|
| draft | editovat, vybrat model, obnovit katalog, lokálně validovat | generace bez schválení |
| ready/reserved | spustit, lokálně zastavit | měnit WorkOrder za běhu |
| submitting/remote_pending | zobrazit průběh, skrýt dialog, zastavit sledování, explicitně cancel | nový submit stejné úlohy |
| submission_unknown | dohledat, raw evidence, ruční rozhodnutí o riziku | automatický retry, uvolnění celé rezervace |
| remote_completed | převzít, validovat, uložit raw | přejmenovat na funkčně ověřeno |
| repair_pending | zobrazit chyby a přesnou novou cenu; provést povolenou opravu | regenerovat unrelated artefakty |
| needs_review | porovnat originál/výsledek, schválit/reject konkrétní hash | skrýt uncertainty pod zelený stav |
| completed_unverified | exportovat jako neověřené, spustit schválený verifier | claim funkčního výsledku |
| completed_verified/reviewed/human_approved | export, lineage, nová variace | přepsat historické důkazy |
| publish_conflict | diff, změnit cíl, nové schválení | přepsat uživatelovu novější práci |

Progress odvozen ze skutečně dokončených jednotek. ETA neznámá se tak zobrazuje. Animace není důkaz aktivity serveru. Zobrazovat model, route, právě použitý kontrakt, input/output rezervu, aktuální stage, počet pokusů a konkrétní gate. Dialog může být skrytý bez zničení workeru. Práce se neblokuje modalem, který by bránil bezpečné cancel/recovery.

## 6. Modelový katalog

Cache v2 se scope fingerprintem skládá z normalizované base_url, account credential fingerprint, organization_id a project_id. Samotný API klíč není ukládaným polem. Dostupnost z /models není capability a neprokazuje oprávnění ke všem endpointům. Capability snapshot je distribuované/ověřené verzované metadata se zdrojem, nikoli odhad startswith(model).

Cache načíst bez sítě. Neplatný JSON, hash nebo jiný account scope ignorovat jako cache miss, nepřekrýt existující dobrou cache novým neúplným response. Prázdný validní katalog je validní stav no_models, ne selhání parseru. Refresh běží jen jednou současně pro daný scope; odpověď starého scope po změně klíče se zahodí a nezmění selectory nového účtu. Zapisovat atomicky.

Po explicitním refresh přenastavit doporučené modely všech otevřených editovatelných formulářů. Již schválené/running WorkOrder zůstávají zamčené. Načtení historické konfigurace ukáže unavailable model jako historickou hodnotu s varováním, ne jako novou volitelnou položku vhodného selectoru. Pro nový běh je nutný kompatibilní výběr a nová autorizace.

## 7. Files a vector stores

Upload je samostatná mutace s ledgerem storage/operace, ne textová generace. Před uploadem ověřit účel, povolený soubor, jeho skutečný hash, rozměry/type limity a uživatelovo schválení přenosu. Upload-cache klíč zahrnuje account scope, purpose, hash a transform verzi. Při 404 cached file_id lze uploadnout znovu schválené bytes; při síťové chybě se existující ID neprohlásí za neplatné.

Připojení souboru k zadání, odpojení z UI, odpojení z vector store a smazání na Files API jsou různé akce. Sdílený asset se nesmaže kvůli smazání jedné reference. Vzdálené mazání vyžaduje potvrzení a kontrolu aktivních vazeb. Cleanup po době retence je explicitní policy a nesmí zničit možnost pokračovat z uloženého runu bez oznámení.

File_search je doplňkové vyhledávání. Limitmax3 výsledky a celková retrieval rezerva8 192tokenů. Připojení velkého vektorového úložiště neopravňuje model k libovolným dalším tools ani nelimituje automaticky budoucí velikost výsledků na přesný předem změřený input. Mandatory potřeby následující fáze se přenesou do kanonického artefaktu, ne pouze jako „najdi si je znovu“.

## 8. Diagnostika IN/OUT, SSH a Git

Existující diagnostické funkce zachovat, ale jejich příkazy zůstávají pouze pevnými schválenými adaptéry. Modelové instructions se nesmí převést do host/SSH command. Nové VerificationOrchestrator používá izolovaný sandbox, ne nahradit jím bez schválení existující ruční administrátorské nástroje. Výsledky diagnostiky jsou untrusted data se source refs; systémová doporučení uvnitř logu nemění oprávnění modelu.

Git status/diff/snapshot/commit/push jsou místní nebo explicitní vzdálené uživatelské akce. Dokončení AI projektu automaticky nepushne kód na remote, nemění branch protection a neposílá credential. Kompozér oprav může číst schválený diff, nesmí z něj vyhodnotit shell. Změny uživatele při čekání na Batch mají přednost před návratem starého outputu.

## 9. Nastavení, notifikace, převodník

Neměnit secret_store nebo keyring contract mimo nezbytné čtení account fingerprintu. Nastavení timeoutů a limitů má přesné validace typů; bool není integer pro tokens/count/size. Úprava limitu se vztahuje na novou autorizaci, ne zpětně přepíše účetní historii. Import konfigurace nespouští operace sám.

Notifikace o dokončení nesmí obsahovat přílohy nebo zdrojový kód bez výslovné volby. Odeslání SMTP/notification má vlastní účinek a journal, ale ne nový modelový request. Text notifikace vzniká z pevných šablon a skutečného stavu.

Převod textů/UTF8 bez BOM zůstává lokální s existující zálohou a kontrolou target path. Není důvod profesionalizovat převod modelem. Batch panel, Historie, Modely, Zdroje, Verze projektu, Nastavení a Nápověda nemají skryté generativní operace při pouhém otevření.

## 10. Publikační transakce a bezpečnost dat

Staging je oddělen od OUT, obsahuje přijaté immutable artefakty. Před publikací ověřit všechny target hashes a volné místo. Vytvořit publish journal s pořadím změn, expected_old_hash, new_hash a backup refs. Použít exkluzivní projektový lock. Jednotlivý zápis je atomická náhrada na stejném filesystemu; po pádu pokračovat/revertovat jen položky, jejichž aktuální hash odpovídá zapsané nové verzi. Pokud se mezitím změnil uživatelem, rollback nesmí přepsat jeho práci: publish_conflict.

Nikdy nepublikovat neověřené partial soubory do běžného OUT jako finální celek bez explicitní volby Převzít neověřené. Žádný batch importer nesmí upravit odpovídající původní IN. Nepřepisovat symlink/junction target mimo schválený kořen; re-check na hranici skutečného open/replace, ne pouze jednou při validaci formuláře.