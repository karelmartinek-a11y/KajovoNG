"""Executable reference invariants. No provider access and no production side effects."""
from __future__ import annotations
import hashlib
import json
import math
import re
import sqlite3
from copy import deepcopy
from pathlib import PurePosixPath
from typing import Any

class InvariantError(ValueError):
    def __init__(self, code: str, message: str):
        self.code=code
        super().__init__(f'{code}: {message}')

def canonical_bytes(value: Any) -> bytes:
    def check(x: Any) -> None:
        if isinstance(x,dict):
            if any(not isinstance(k,str) for k in x):
                raise InvariantError('CANONICAL_KEY','JSON object keys must be strings')
            for v in x.values():check(v)
        elif isinstance(x,list):
            for v in x:check(v)
        elif isinstance(x,float) and not math.isfinite(x):
            raise InvariantError('NONFINITE','JSON does not permit non-finite values')
    check(value)
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()

def parse_json_strict(text: str) -> dict:
    def pairs(items):
        out={}
        for key,value in items:
            if key in out:raise InvariantError('DUPLICATE_KEY',key)
            out[key]=value
        return out
    def bad(x):raise InvariantError('NONFINITE',str(x))
    try:
        parsed=json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
    except json.JSONDecodeError as e:raise InvariantError('INVALID_JSON',str(e)) from e
    if not isinstance(parsed,dict):raise InvariantError('ROOT_NOT_OBJECT','Expected object')
    canonical_bytes(parsed)
    return parsed

def validate_safe_path(path: str) -> str:
    if not isinstance(path,str) or not path or path!=path.strip():raise InvariantError('PATH_INVALID','Empty or padded path')
    if any(c in path for c in '\\:<>\"|?*') or path.startswith('/') or any(ord(c)<32 or ord(c)==127 for c in path):raise InvariantError('PATH_INVALID',path)
    parts=path.split('/')
    if any(p in ('','.', '..') or p.endswith((' ','.')) for p in parts):raise InvariantError('PATH_INVALID',path)
    reserved={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
    if any(p.split('.')[0].upper() in reserved for p in parts):raise InvariantError('PATH_INVALID',path)
    return PurePosixPath(path).as_posix()

def validate_graph(graph: dict) -> None:
    files=graph['spine']['files']; names=[validate_safe_path(f['path']) for f in files]
    folded=[p.casefold() for p in names]
    if len(set(folded))!=len(folded):raise InvariantError('PATH_COLLISION','Case-insensitive duplicate')
    for p in folded:
        if any('/'.join(p.split('/')[:i]) in folded for i in range(1,len(p.split('/')))):
            raise InvariantError('PATH_COLLISION','File is ancestor directory')
    by_path={f['path']:f for f in files}; interfaces={x['id']:x for x in graph['spine']['interfaces']}
    if len(interfaces)!=len(graph['spine']['interfaces']):raise InvariantError('INTERFACE_DUPLICATE','Duplicate ID')
    for f in files:
        deps=set(f['dependencies']); content=set(f.get('content_dependencies',[]))
        if not deps<=by_path.keys() or f['path'] in deps:raise InvariantError('UNKNOWN_DEPENDENCY',f['path'])
        if not content<=deps:raise InvariantError('CONTENT_DEPENDENCY_INVALID',f['path'])
        if (f['dependency_content_mode']=='verified_content') != bool(content):raise InvariantError('CONTENT_MODE_INVALID',f['path'])
        if not set(f['requires']+f['provides'])<=interfaces.keys():raise InvariantError('UNKNOWN_INTERFACE',f['path'])
        for ident in f['requires']:
            providers=set(interfaces[ident]['providers'])
            if not providers & (deps|{f['path']}):raise InvariantError('PROVIDER_MISSING',ident)
    execution_waves(graph)
    specs={x['path']:x['spec'] for x in graph['file_specs']}
    expected={f['path'] for f in files if f['kind']=='text' and f['action']!='preserve'}
    if not expected<=specs.keys():raise InvariantError('FILE_SPEC_MISSING','Missing mandatory detail')
    for path,s in specs.items():
        if type(s['expected_visible_tokens']) is not int or s['expected_visible_tokens']<1:
            raise InvariantError('OUTPUT_ESTIMATE_INVALID',path)
        if not s['acceptance_ids'] or not s['test_scenarios']:raise InvariantError('ACCEPTANCE_MISSING',path)
        if not set(s['required_facets'])<={x['kind'] for x in s['facets']}:raise InvariantError('FACET_MISSING',path)

def execution_waves(graph: dict) -> list[list[str]]:
    pending={f['path']:set(f.get('content_dependencies',[])) for f in graph['spine']['files']}
    waves=[]
    while pending:
        ready=sorted(p for p,d in pending.items() if not d)
        if not ready:raise InvariantError('CONTENT_DEPENDENCY_CYCLE','No task can start')
        waves.append(ready)
        pending={p:ds-set(ready) for p,ds in pending.items() if p not in ready}
    return waves

def compile_image_slots(roles: list[dict]) -> dict:
    by_key={}; slots=[]; mapping={}
    for r in roles:
        if r['role_id'] in mapping:raise InvariantError('ROLE_DUPLICATE',r['role_id'])
        key=(r['normalized_sha256'],r['transform_policy_hash'])
        if key not in by_key:
            index=len(slots)+1
            by_key[key]=index
            slots.append({'index':index,'slot_id':f'IMAGE-{index:03d}','normalized_sha256':key[0],'transform_policy_hash':key[1]})
        mapping[r['role_id']]=by_key[key]
    if len(slots)>16:raise InvariantError('IMAGE_REFERENCE_LIMIT','Too many unique images')
    return {'slots':slots,'role_to_index':mapping}

def classify_response(raw: dict) -> str:
    status=raw.get('status')
    if status in ('queued','in_progress'):return 'remote_pending'
    if status=='incomplete':return 'incomplete'
    if status in ('failed','cancelled','expired'):return 'remote_failed'
    if status!='completed':raise InvariantError('PROVIDER_STATUS_UNKNOWN',str(status))
    out=raw.get('output') or []
    if any(c.get('type')=='refusal' for x in out if isinstance(x,dict) for c in x.get('content',[]) if isinstance(c,dict)):
        return 'refusal'
    if any(x.get('type')=='function_call' for x in out if isinstance(x,dict)):return 'tool_calls'
    if isinstance(raw.get('output_text'),str) or any(c.get('type')=='output_text' for x in out if isinstance(x,dict) for c in x.get('content',[]) if isinstance(c,dict)):
        return 'final_text'
    raise InvariantError('PROVIDER_OUTPUT_MISSING','Completed response has no usable output')

def apply_replacements(targets: dict, operations: list[dict]) -> dict:
    new=deepcopy(targets);seen=set()
    allowed={'replace_requirement','replace_component','replace_interface','replace_file_entry','replace_file_spec'}
    for op in operations:
        ident=op['target_id']
        if op['op'] not in allowed:raise InvariantError('PATCH_OPERATION_DENIED',op['op'])
        if ident not in targets or ident in seen:raise InvariantError('PATCH_TARGET_INVALID',ident)
        if sha(targets[ident])!=op['expected_value_hash']:raise InvariantError('PATCH_STALE',ident)
        replacement=op['replacement']
        for key in ('id','path'):
            if key in targets[ident] and replacement.get(key)!=targets[ident][key]:raise InvariantError('PATCH_IDENTITY_CHANGE',ident)
        seen.add(ident);new[ident]=deepcopy(replacement)
    return new

def assert_projection_unique(components: list[dict]) -> None:
    keys=set()
    for c in components:
        key=(c['artifact_id'],c['sha256'],c['selector'],c['role'])
        if key in keys:raise InvariantError('CONTEXT_DUPLICATE','Same component in same role')
        if not c.get('reason'):raise InvariantError('CONTEXT_REASON_MISSING',c['artifact_id'])
        keys.add(key)

def bounded_repair_input(base: dict, candidate: dict, errors: list[dict]) -> dict:
    if any(k in base for k in ('repair','history','previous_candidates')):raise InvariantError('REPAIR_RECURSION','Base must be original approved input')
    return {'base':deepcopy(base),'candidate':deepcopy(candidate),'errors':deepcopy(errors[:50])}

class BudgetLedger:
    """SQLite concurrency reference; integer microUSD; no network or GUI."""
    def __init__(self,path: str,limit: int):
        if type(limit) is not int or limit<0:raise InvariantError('LIMIT_INVALID','Nonnegative integer required')
        self.path=path
        with self._db() as c:
            c.executescript('CREATE TABLE IF NOT EXISTS budget(id INTEGER PRIMARY KEY CHECK(id=1), ceiling INTEGER NOT NULL, frozen INTEGER NOT NULL DEFAULT 0); CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY, cost INTEGER NOT NULL CHECK(cost>=0), state TEXT NOT NULL, actual INTEGER, provider_id TEXT UNIQUE);')
            c.execute('INSERT OR IGNORE INTO budget(id,ceiling) VALUES(1,?)',(limit,))
    def _db(self):return sqlite3.connect(self.path,timeout=10,isolation_level=None)
    def reserve(self,id: str,cost: int) -> bool:
        if type(cost) is not int or cost<0:raise InvariantError('COST_INVALID','Nonnegative integer required')
        c=self._db()
        try:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT cost FROM reservations WHERE id=?',(id,)).fetchone()
            if old:
                if old[0]!=cost:raise InvariantError('RESERVATION_CONFLICT',id)
                c.commit();return False
            ceiling,frozen=c.execute('SELECT ceiling,frozen FROM budget WHERE id=1').fetchone()
            used=c.execute("SELECT COALESCE(SUM(CASE WHEN state='settled' THEN actual WHEN state='released' THEN 0 ELSE cost END),0) FROM reservations").fetchone()[0]
            if frozen or used+cost>ceiling:raise InvariantError('BUDGET_EXCEEDED','Reservation rejected before submit')
            c.execute('INSERT INTO reservations(id,cost,state) VALUES(?,?,?)',(id,cost,'reserved'));c.commit();return True
        except Exception:
            c.rollback();raise
        finally:c.close()
    def mark_unknown(self,id: str) -> None:
        with self._db() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT state FROM reservations WHERE id=?',(id,)).fetchone()
            if not row or row[0] not in ('reserved','unknown'):raise InvariantError('STATE_INVALID',id)
            c.execute("UPDATE reservations SET state='unknown' WHERE id=?",(id,));c.commit()
    def release(self,id: str) -> None:
        with self._db() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT state FROM reservations WHERE id=?',(id,)).fetchone()
            if not row or row[0]!='reserved':raise InvariantError('RELEASE_UNSAFE',id)
            c.execute("UPDATE reservations SET state='released' WHERE id=?",(id,));c.commit()
    def settle(self,id: str,provider_id: str,actual: int) -> bool:
        if type(actual) is not int or actual<0:raise InvariantError('COST_INVALID','Nonnegative actual required')
        c=self._db()
        try:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT cost,state,actual,provider_id FROM reservations WHERE id=?',(id,)).fetchone()
            if not row:raise InvariantError('RESERVATION_UNKNOWN',id)
            if row[1]=='settled':
                if row[2:]!=(actual,provider_id):raise InvariantError('USAGE_CONFLICT',id)
                c.commit();return False
            if row[1]=='released':raise InvariantError('SETTLE_RELEASED',id)
            c.execute("UPDATE reservations SET state='settled',actual=?,provider_id=? WHERE id=?",(actual,provider_id,id))
            if actual>row[0]:c.execute('UPDATE budget SET frozen=1 WHERE id=1')
            c.commit();return True
        except Exception:
            c.rollback();raise
        finally:c.close()
    def used(self) -> int:
        with self._db() as c:
            return c.execute("SELECT COALESCE(SUM(CASE WHEN state='settled' THEN actual WHEN state='released' THEN 0 ELSE cost END),0) FROM reservations").fetchone()[0]
