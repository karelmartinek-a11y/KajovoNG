from __future__ import annotations
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from invariants import (InvariantError, BudgetLedger, parse_json_strict, canonical_bytes, validate_safe_path, validate_graph, execution_waves, compile_image_slots, classify_response, apply_replacements, assert_projection_unique, bounded_repair_input, sha)
ROOT=Path(__file__).resolve().parents[1]

class ReferenceTests(unittest.TestCase):
    def graph(self):return json.loads((ROOT/'examples/local/implementation_graph.json').read_text())
    def test_01_duplicate_json_keys(self):
        with self.assertRaises(InvariantError):parse_json_strict('{"a":1,"a":2}')
    def test_02_no_surrounding_prose(self):
        with self.assertRaises(InvariantError):parse_json_strict('prefix {"a":1}')
    def test_03_nonfinite(self):
        for value in ['{"a":NaN}','{"a":Infinity}','{"a":1e999}']:
            with self.assertRaises(InvariantError):parse_json_strict(value)
    def test_04_stable_canonical_hash(self):
        self.assertEqual(sha({'b':2,'a':1}),sha({'a':1,'b':2}))
    def test_05_paths(self):
        for p in ['../x','/x','a/../b','a\\b','C:x','NUL.txt','x/','a//b',' a.py']:
            with self.assertRaises(InvariantError):validate_safe_path(p)
        self.assertEqual(validate_safe_path('src/app.py'),'src/app.py')
    def test_06_valid_graph(self):validate_graph(self.graph())
    def test_07_missing_provider(self):
        g=self.graph();g['spine']['interfaces'][0]['providers']=['unknown.py']
        with self.assertRaises(InvariantError):validate_graph(g)
    def test_08_missing_acceptance(self):
        g=self.graph();g['file_specs'][0]['spec']['acceptance_ids']=[]
        with self.assertRaises(InvariantError):validate_graph(g)
    def test_09_contract_parallel(self):
        self.assertEqual(execution_waves(self.graph()),[['adder.py','tests/test_adder.py']])
    def test_10_verified_content_wave(self):
        g=self.graph();f=g['spine']['files'][1];f['content_dependencies']=['adder.py'];f['dependency_content_mode']='verified_content'
        self.assertEqual(execution_waves(g),[['adder.py'],['tests/test_adder.py']])
    def test_11_content_cycle(self):
        g=self.graph();a,b=g['spine']['files'];a['content_dependencies']=[b['path']];b['content_dependencies']=[a['path']]
        with self.assertRaises(InvariantError):execution_waves(g)
    def test_12_image_slots_after_dedup(self):
        roles=[{'role_id':r,'normalized_sha256':h,'transform_policy_hash':'t'} for r,h in [('base','a'),('entity1','a'),('entity2','b'),('style','a')]]
        result=compile_image_slots(roles)
        self.assertEqual(result['role_to_index'],{'base':1,'entity1':1,'entity2':2,'style':1})
        self.assertEqual(len(result['slots']),2)
    def test_13_image_reference_limit(self):
        roles=[{'role_id':str(i),'normalized_sha256':str(i),'transform_policy_hash':'t'} for i in range(17)]
        with self.assertRaises(InvariantError):compile_image_slots(roles)
    def test_14_refusal_and_incomplete(self):
        self.assertEqual(classify_response(json.loads((ROOT/'examples/responses/provider-refusal.json').read_text())),'refusal')
        self.assertEqual(classify_response(json.loads((ROOT/'examples/responses/provider-incomplete.json').read_text())),'incomplete')
    def test_15_tool_response_not_final(self):
        self.assertEqual(classify_response(json.loads((ROOT/'examples/responses/provider-tool-call.json').read_text())),'tool_calls')
    def test_16_unknown_provider_status(self):
        with self.assertRaises(InvariantError):classify_response({'status':'almost_done'})
    def test_17_atomic_patch_rejection(self):
        targets={'REQ-1':{'id':'REQ-1','value':'old'}}
        op={'op':'replace_requirement','target_id':'REQ-1','expected_value_hash':'wrong','replacement':{'id':'REQ-1','value':'new'}}
        with self.assertRaises(InvariantError):apply_replacements(targets,[op])
        self.assertEqual(targets['REQ-1']['value'],'old')
    def test_18_patch_identity_rejection(self):
        targets={'REQ-1':{'id':'REQ-1','value':'old'}}
        op={'op':'replace_requirement','target_id':'REQ-1','expected_value_hash':sha(targets['REQ-1']),'replacement':{'id':'REQ-2','value':'new'}}
        with self.assertRaises(InvariantError):apply_replacements(targets,[op])
    def test_19_no_duplicate_context(self):
        c={'artifact_id':'a','sha256':'h','selector':'/x','role':'required','reason':'test'}
        with self.assertRaises(InvariantError):assert_projection_unique([c,c])
        assert_projection_unique([c,{**c,'role':'comparison','reason':'different authorized role'}])
    def test_20_no_recursive_repair(self):
        base={'input':'approved'};last=bounded_repair_input(base,{'bad':1},[])
        with self.assertRaises(InvariantError):bounded_repair_input({'repair':last},{},[])
        again=bounded_repair_input(base,{'bad':2},[])
        self.assertNotIn('history',again);self.assertEqual(again['base'],base)
    def test_21_concurrent_reservations(self):
        with tempfile.TemporaryDirectory() as d:
            ledger=BudgetLedger(str(Path(d)/'ledger.db'),10)
            def reserve(n):
                try:return ledger.reserve(str(n),7)
                except InvariantError:return False
            with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(reserve,[1,2]))
            self.assertEqual(sum(results),1);self.assertEqual(ledger.used(),7)
    def test_22_unknown_never_released(self):
        with tempfile.TemporaryDirectory() as d:
            ledger=BudgetLedger(str(Path(d)/'ledger.db'),10);ledger.reserve('x',8);ledger.mark_unknown('x')
            with self.assertRaises(InvariantError):ledger.release('x')
            with self.assertRaises(InvariantError):ledger.reserve('y',3)
            self.assertEqual(ledger.used(),8)
    def test_23_usage_idempotency(self):
        with tempfile.TemporaryDirectory() as d:
            ledger=BudgetLedger(str(Path(d)/'ledger.db'),10);ledger.reserve('x',8)
            self.assertTrue(ledger.settle('x','response-1',3));self.assertFalse(ledger.settle('x','response-1',3));self.assertEqual(ledger.used(),3)
    def test_24_billing_variance_freezes(self):
        with tempfile.TemporaryDirectory() as d:
            ledger=BudgetLedger(str(Path(d)/'ledger.db'),10);ledger.reserve('x',8);ledger.settle('x','response-1',9)
            with self.assertRaises(InvariantError):ledger.reserve('y',1)
            self.assertEqual(ledger.used(),9)
    def test_25_sql_migration(self):
        with sqlite3.connect(':memory:') as c:
            c.executescript((ROOT/'migration/001_orchestration.sql').read_text())
            names={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertTrue({'runs','work_orders','reservations','usage_records','domain_outbox'}<=names)
    def test_26_source_bytes_exact(self):
        pack=json.loads((ROOT/'examples/local/source_pack.json').read_text());raw=(ROOT/'examples/local/source_text.txt').read_bytes()
        import hashlib
        self.assertEqual(pack['sources'][0]['sha256'],hashlib.sha256(raw).hexdigest())
        intervals=pack['sources'][0]['segments'];self.assertEqual(intervals[0]['start_byte'],0);self.assertEqual(intervals[-1]['end_byte'],len(raw))

if __name__=='__main__':unittest.main()
