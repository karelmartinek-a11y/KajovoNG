# Přijetí změny a hranice důkazů

## Tři oddělené výsledky

**Kontrola specifikace:** schémata lze načíst, příklady splňují předepsané typy, negativní příklady jsou skutečně odmítány, vazby na fáze a cíle existují, referenční algoritmy procházejí jednotkovými testy. Toto ověřuje `tools/validate_package.py`.

**Integrační offline CI KájovoNG:** skutečný kód aplikace splňuje scénáře `catalog.json` v izolovaném prostředí se simulovaným poskytovatelem. Tato simulace musí používat reálné tvary Responses a chyb; pomocná fixture nesmí potichu doplňovat chybějící pole testovaného kandidáta. Úspěch těchto testů není důkaz reálné generace.

**Placený acceptance poskytovatele:** ručně autorizovaný běh používá skutečný účet a model, uchová přesné request/response evidence, tokeny, cenu a vytvořený výsledek. U programu spustí bezpečné ověření v sandboxu, u fotografie/komiksu oddělí technický dekodér, modelové vizuální posouzení a lidské potvrzení. Bez tohoto důkazu nesmí vydání obsahovat tvrzení „ověřeno skutečným OpenAI“.

## Přesný pracovní příkaz implementátora

Dodat `scripts/live_acceptance.py` do aplikace. Tento soubor v CHANGE není vydáván za již hotovou integraci. Implementátor musí dodržet toto rozhraní:

```sh
python scripts/live_acceptance.py --case generate-live --confirm-paid --authorization /secure/authorization.json --out /isolated/acceptance
python scripts/live_acceptance.py --case generate-batch --confirm-paid --authorization /secure/authorization.json --out /isolated/acceptance
python scripts/live_acceptance.py --case photo-batch --confirm-paid --authorization /secure/authorization.json --out /isolated/acceptance
python scripts/live_acceptance.py --case comic-panels --confirm-paid --authorization /secure/authorization.json --out /isolated/acceptance
```

Povolené `--case`: přesně čtyři uvedené hodnoty. Chybějící `--confirm-paid`, neplatná/expirující autorizace, nesoulad účtu nebo neznámá sazba bez explicitní token-only autorizace znamenají exit code 2 před jakýmkoli generativním POST. `--out` musí být nový izolovaný adresář mimo produkční IN/OUT a knihovnu COMICS. API klíč se čte existujícím SecretStore; nepředává se argumentem, nezapisuje do JSON ani reportu.

Autorizace má schema `contracts/local/EXECUTION_AUTHORIZATION_V1.schema.json`. Jedna autorizace určuje účet, rozsah pracovních operací, expiraci, peněžní/tokenové limity a maximální počet requestů. Nevytváří se automaticky spuštěním testu. Demo soubor v examples není platnou autorizací produkčního účtu.

### generate-live

Zadání: malý Python projekt `adder.py` se sčítáním dvou celých čísel a testy v `test_adder.py`, bez externí sítě či balíčků. Projde skutečné A0R → A1 → A2 spine/details → A3. Výsledek se ověří profilem `python-unittest` v schváleném sandboxu. Očekává se exit 0 testů, alespoň jeden vykonaný test a správný výsledek pro kladná, záporná a nulová čísla. Model nesmí testy vypnout nebo změnit akceptaci. Evidence propojí zdrojový záměr, oba soubory a report.

### generate-batch

Stejná úloha; A0R/A1/A2 běží LIVE, pouze hotové souborové work orders v Batch. Před prvním Batch submit se uloží celé mapování custom_id a rozpočtová rezervace. Test musí podporovat přerušení procesu po potvrzení batch_id a následné převzetí bez nového placeného submitu. Čekání má časový limit a návrat pending, nikoli falešné selhání nebo dokončení. Když se dávka neukončí v místním časovém limitu, skript vrátí exit 3 s ID pro obnovu, ne exit 0.

### photo-batch

Použít uživatelem schválenou neosobní testovací fotografii. Úloha upraví světelnost bez změny obsahu. Zachovat SHA-256 originálu, normalizovaný vstup a všechny verze. Převzetí musí dekódovat skutečný PNG/JPEG/WebP. Vizuální posouzení má předepsaná kritéria, zjištěné vady a nejistotu. Ani kladné modelové posouzení se nevydává za matematický důkaz shody pixelů. Lidské schválení se zaznamená samostatně.

### comic-panels

Použít fiktivní postavu a dvě scény, bez reálných osob a bez chráněných podkladů třetích stran. Vytvořit bibli, descriptor/reference, dva panely s návazností. Otestovat deduplikaci stejné reference ve více rolích. Text dialogů přidává lokální sazba; výstupní PNG a PDF musí obsahovat stejné schválené texty a neclipované bubliny. Samostatně zaznamenat kontinuitu, technickou validitu a lidské schválení. Plný story mode se ověří navazujícím produkčním scénářem katalogu; test dvou panelů není důkaz libovolného dlouhého příběhu.

## Povinné důkazní artefakty skutečného acceptance

`acceptance_result.json` musí uvést minimálně commit aplikace, case, run_id, account fingerprint, modely a capability verze, parametry requestů, hash autorizace, custom_id mapování, provider IDs, počet generativních POST, skutečné usage, odhad/skutečnou cenu a její známé mezery, seznam vytvořených souborů s hashi, verifikační profil a výsledek. Evidence nesmí obsahovat Authorization header ani API klíč.

Exit codes: 0 = case splnil vlastní předepsaná kritéria; 1 = ověřené nesplnění; 2 = zablokováno před spuštěním; 3 = vzdálená práce pokračuje / výsledek je neurčitý; 4 = výstup vyžaduje lidskou obsahovou kontrolu. Počítač nesmí mapovat 3 nebo 4 na zelené dokončení.

## Povinné testovací techniky

Každý scénář má given/when/then, seznam zakázaných vedlejších účinků a důkaz. Testy nesmějí jen tvrdit, že byla volána metoda. Musejí kontrolovat konkrétní payload, změněné soubory/DB, rezervace a počet skutečně simulovaných POST.

Injectovat pád před zápisem submit intent, po intent a před síťovým zápisem, po síťovém zápisu před ID, po uložení ID, po stažení před commit a po commit před UI událostí. U všech poloh prokázat, že restart nezpůsobí skrytou druhou placenou výrobu. Zvlášť otestovat dvě paralelní rezervace rozpočtu, závod změny API účtu, současnou uživatelskou editaci a import, duplicitní provider výsledek a nedokončený Batch.

Testy kontextu musí porovnat skutečnou stromovou reprezentaci, ne pouze hledat podřetězec „history“. Ověří nepřítomnost vnořeného snapshotu, řetězce candidate1→candidate2 a dvojího předání stejného zdroje jako input_file i inline text bez zdokumentovaného účelu.

## Vydání

Podmínkou merge je existující úplná CI sada, nové scénáře a nezhoršené prahy pokrytí; prahy se nesmějí snížit. Podmínkou tvrzení o živé funkčnosti jsou skutečné acceptance výsledky. Není dovoleno generovat report s vyplněnými hodnotami PASS bez spuštění kontroly. Součástí tohoto CHANGE je definice budoucích integračních scénářů, nikoli předstírané výsledky těchto scénářů.