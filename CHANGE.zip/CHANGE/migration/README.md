# Implementační pořadí, migrace a předání do main

## 1. Základ a drift

Výchozí porovnání používá commit `c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4`. Před úpravou zjistit aktuální HEAD hlavní větve, uložit jej do implementačního reportu a projít změny od tohoto SHA v každé cestě z `file_map.json`. Nepřepisovat uživatelovu novější práci. `tools/check_baseline.py --repo /cesta/KajovoNG` vytváří pouze lokální diagnostiku; neprovádí checkout, push ani síťové operace.

Repozitář respektuje `AGENTS.md` a `docs/SSOT.md`. Tento balík určuje novou cílovou produktovou logiku. Po implementaci musí být změněné kontrakty promítnuté do SSOT a generované REQUEST_MATRIX. Historické zprávy a staré JSONL se nepřepíší, aby zdánlivě odpovídaly nové verzi.

## 2. Pracovní balíky v závazném pořadí

| WP | Závisí na | Implementace | Povinný výsledek |
|---|---|---|---|
| WP00 | nic | Načíst HEAD, existující testy, mapu API callsites a všechny artefaktové verze | Zapsaná výchozí inventura a žádné nezdokumentované změny secrets/CI limitů |
| WP01 | WP00 | StageContractRegistry, strict parser, semantic errors, nové wire/local/input schemas | Schema parity a negative fixtures; oddělený legacy reader |
| WP02 | WP01 | ArtifactStore, SourcePack, hash/provenance, read-only tool scopes | Byte přesná obnova a reference integrity |
| WP03 | WP01–02 | WorkOrder, approval, ledger, persistent attempt journal | Atomic reserve, at-most-one automatic submit, unknown recovery |
| WP04 | WP03 | Common request builder, classifier, token count, model capability binding | Žádná doménová cesta neobchází rozpočet/klasifikaci |
| WP05 | WP02–04 | GENERATE/MODIFY preparation, A2 SPINE/DETAIL, typed reviews | Plan-ready bez opakování přípravy; B modelové role |
| WP06 | WP05 | FILE_CONTENT_V1, stejný LIVE/Batch builder, waves a v4 manifest | Cílená výroba, struktura bez path/chunk modelových polí |
| WP07 | WP03–06 | Verification adapters, isolated runner, publish journal | Pravdivé completed_verified a ochrana OUT |
| WP08 | WP04 | QA a QFILE | Odstraněné QFILE rozpory, explicitní filename plán a kontext |
| WP09 | WP01–04 | Cascade v3 compiler/runtime/DSL | Typové bindings, forward graph, bez JSON-string duplicity |
| WP10 | WP03–04 | Shared image policy/slots/upload cache | Reálné image decode, scope/hash, index-after-dedup |
| WP11 | WP10 | PHOTO plán/manual path/review/repair/UI | Jeden autorizovaný repair, vizuální status oddělený |
| WP12 | WP10–11 | COMIC bible/entities/manual panel path | Zachovaná knihovna/verze a přesné reference |
| WP13 | WP12 | COMIC outline/script/storyboard/continuity/render/export | Kompletní příběhová cesta bez přepisování manuálního editoru |
| WP14 | WP03–13 | Historie/Operations/katalog/Batch/zdroje/diagnostika | Jednotné lifecycle, bez skrytých generací při otevření UI |
| WP15 | WP01–14 | SQL migrace, restart scénáře, legacy imports, dokumentace | Nedestruktivní migrace a shoda UI s runtime |
| WP16 | WP15 | Kompletní offline CI a negativní testy | Žádné snížené limity či odstraněné behaviorální testy |
| WP17 | WP16 | Samostatně autorizované placené acceptance | Skutečné provider request/response a finální funkční/vizuální evidence |

WP00–WP16 nejsou náhradou WP17. Výsledek je možné vydat jako implementováno/offline ověřeno, ale nikoli tvrdit reálnou úspěšnou výrobu bez odpovídající evidence.

## 3. Databáze

`001_orchestration.sql` zakládá nové společné orchestration tabulky v samostatné DB. Nepoužívat ho jako destruktivní skript na existující ComicStore. SQLite musí podporovat transakce, foreign keys a json_valid; kontrola capability proběhne před migrací. Při nepodporovaném prostředí se nic částečně nemigruje.

Před migrací vytvořit ověřitelnou zálohu schématu a DB. Zapsat counts a integritu všech projektů/entity/panel/version/asset. Nové doménové odkazy do společného ledgeru se doplní jen pro nové tasky; historická data se označí legacy bez vymyšlených usage/cen. Cross-store dokončení používá outbox: společná operace uloží pending event, doménová transakce aplikuje expected revision a event ID idempotentně, následně outbox applied. Po pádu krok zopakovat podle event ID; conflict nezmění aktuální panel.

Migrate-on-open musí být transakční. Přerušená migrace se buď celá vrátí, nebo má explicitní resume journal. Migrace nikdy nevolá OpenAI. Obsah původních response/file artefaktů se nemění a jejich hash se zachová.

## 4. Verze kontraktů

Staré A0R/A1/A2/A3/B... zůstávají čitelné. Nové běhy používají nové wire názvy a manifest4. Nová implementace nesmí přejmenovat starou JSON odpověď na nový kontrakt bez validované explicitní transformace.

Starý Batch manifest1/2/3 se dá importovat původním readerem bez nové útraty. Opakované odeslání starého payloadu je dovoleno pouze přes explicitně vygenerovaný nový WorkOrder s kompatibilními schválenými podklady. Chybějící implementační detail znamená potřebu nové přípravy, nikoli full-snapshot fallback.

Kaskádu1/2 migrovat do nové kopie3; implicitní konverzační návaznost musí být v UI vysvětlena a potvrzena. Původní soubor se nezničí. Modelový katalog v1 načíst bezpečně, ale capability znovu odvodit z nové ověřené distribuované matice a přidat scope base_url/org/project. Nedostupné hodnoty jsou null; nejsou známé jen proto, že cache obsahovala staré názvy.

## 5. Přísně zachované části

Zachovat secrets/keyring, Windows start.bat workflow, provozní adresáře, možnost detached oken, legacy prohlížení, ruční editor komiksu, Photo templates, explicitní výběr fotografií, dry-run a lineage akce. Neodstraňovat bezpečnostní řešení z původního kódu za účelem snazšího testu. Neprovádět grafický redesign, nesouvisející refaktoring nebo přepis všech modelových metadat bez doloženého důvodu.

## 6. Testy a vydání

Minimálně: `python -m pytest -q`; existující Ruff kontrola `python -m ruff check --select F,B,E9 kajovo kajovong utf8nobom tests Build`; `python -m pip check`; stávající kritické coverage gates. Přidat nové behaviorální testy do vhodných modulů, ne pouze testy datových konstant.

Změnový report má rozlišit testované zdrojové cesty, skutečné placené acceptance, neprovedené integrace a zbývající nejistoty. Obecné „CI zelené, všechno funguje“ není přípustný výsledek. Ke každému novému finálnímu statusu dodat screenshot skutečného UI, odpovídající evidence ID a test přechodu. Grafické snímky mohou být offline demo pouze pokud jsou tak výslovně označeny.