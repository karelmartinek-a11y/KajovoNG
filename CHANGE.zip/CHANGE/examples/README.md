# Příklady a testovací vzory

Tyto soubory jsou úplné **syntetické testovací příklady** odpovídající dodaným schématům. Nejsou to zachycené odpovědi skutečného OpenAI účtu. Identifikátory `resp_demo`, `file_demo`, `RUN-DEMO` a podobné hodnoty slouží k vysvětlení protokolu; neodesílejte je poskytovateli. Modelová jména jsou rolemi navržené politiky, ale skutečná dostupnost se musí předem ověřit účtovým katalogem a capability profilem.

`inputs/` obsahuje pracovní vstup každé fáze. `responses/` obsahuje správné modelové výsledky a zvlášť provider envelope pro refusal, incomplete a tool call. `negative/` obsahuje záměrně chybná data, která se nesmějí akceptovat. `local/` ukazuje lokální artefakty, work orders, manifesty, zdroje a autorizační struktury. `requests/` obsahuje celé Responses JSON body a nativní Image API body, nikoli komentářové pseudokódy.

## Textová výrobní úloha

Základní scénář používá dvě skutečně související Python cesty, sčítání dvou celých čísel a unit test. Requirements, plán, rozhraní a jednotlivé file contracts se vztahují ke stejnému záměru. Modelová A3 odpověď obsahuje pouze `content`; target path zůstává v lokálním work order. Příklad nepovažujte za obecný vzor počtu souborů pro jakoukoli aplikaci.

## JSONL

Každý řádek je samostatný JSON objekt s unique custom_id, metodou POST, explicitním endpointem a úplným body. JSONL není JSON array. Dva řádky stejné dávky si neposkytují konverzační paměť. LIVE příprava se do každého řádku neopakuje jako celý transcript.

## Obrázková fixture

Malý PNG vytvořený deterministicky v balíku je pouze fixture technické integrity bajtů. Není to vygenerovaná ani upravená fotografie. Úspěch dekodéru této fixture nijak neprokazuje obsahovou správnost obrazové AI. V tomto balíku nejsou fotografie osob ani provozní referenční fotografie hotelu.

## Autorizace a ceny

Příklady lokálních autorizačních struktur nejsou souhlasem se skutečným účtováním. Hash nebo prázdná/null cenová hodnota v syntetickém záznamu nesmí být interpretována jako ověřené oprávnění nebo cena nula. Produkční autorizaci vytváří UI po zobrazení účtu, modelů, scope, rizik a rozpočtu. Proměnné prostředí a skutečné secret hodnoty do balíku nepatří.

## Pořadí validace

Ověřit provider status → klasifikovat refusal/incomplete/tool → parsovat finální JSON → wire schema → sémantický kontrakt proti frozen work order → vytvořit kanonický artefakt → spustit odpovídající acceptance. Negativní příklad se nesmí „spravit“ automatickým doplněním očekávaných polí v testovací fixture.

Seznam přiřazení příkladů ke schématům je v `acceptance/schema_examples.json`. Každá dodaná fáze má vedle odpovědního schématu také vlastní vstupní schéma; univerzální libovolný `input:any` není povolený pracovní kontrakt.