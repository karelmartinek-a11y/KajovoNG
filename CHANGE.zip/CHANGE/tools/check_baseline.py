"""Read-only baseline check against a local KajovoNG checkout. No network."""
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path)
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    baseline=json.loads((root/'evidence/baseline.json').read_text())
    mapping=json.loads((root/'migration/file_map.json').read_text())
    def git(*args):return subprocess.run(['git','-C',str(a.repo),*args],text=True,capture_output=True,check=True).stdout.strip()
    head=git('rev-parse','HEAD');status=git('status','--porcelain')
    changed=git('diff','--name-only',baseline['observed_commit'],head).splitlines()
    paths=[x['path'] for x in mapping['existing']]
    report={'head':head,'baseline':baseline['observed_commit'],'same_commit':head==baseline['observed_commit'],'working_tree_dirty':bool(status),'changed_since_baseline':changed,'impacted_mapped_paths':sorted(set(changed)&set(paths)),'missing_mapped_files':[x for x in paths if not (a.repo/x).is_file()],'automatic_apply_permitted':False}
    raw=json.dumps(report,indent=2)+'\n'
    if a.output:a.output.write_text(raw,encoding='utf-8')
    print(raw)
    return 0
if __name__=='__main__':raise SystemExit(main())
