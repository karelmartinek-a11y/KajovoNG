"""Offline validation of the change specification, never of live OpenAI behavior."""
from __future__ import annotations
import argparse, contextlib, hashlib, io, json, sys, unittest, sqlite3
from pathlib import Path
import jsonschema

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def strict_shape(node,path='root'):
    if isinstance(node,dict):
        if node.get('type')=='object':
            props=node.get('properties',{})
            assert node.get('additionalProperties') is False,(path,'open object')
            assert set(node.get('required',[]))==set(props),(path,'optional property')
        for k,v in node.items():
            if k not in ('enum','description'):strict_shape(v,path+'/'+k)
    elif isinstance(node,list):
        for i,v in enumerate(node):strict_shape(v,path+'/'+str(i))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--strict',action='store_true');ap.add_argument('--report',type=Path,default=ROOT/'VALIDATION_REPORT.json');args=ap.parse_args()
    report={'scope':'Offline specification package and reference invariants only. No KajovoNG runtime or provider requests executed.','provider_calls':0,'production_code_modified':False,'checks':[],'errors':[]}
    def check(name,fn):
        try:
            value=fn();report['checks'].append({'name':name,'status':'passed','detail':value})
        except Exception as e:report['errors'].append({'name':name,'error':str(e)})
    def schemas():
        fs=sorted((ROOT/'contracts').rglob('*.schema.json'))
        for f in fs:
            data=json.loads(f.read_text());jsonschema.Draft202012Validator.check_schema(data)
            if '/wire/' in f.as_posix():strict_shape(data)
        return {'schema_count':len(fs),'wire_strictness_checked':True}
    check('schemas',schemas)
    def examples():
        entries=read('acceptance/schema_examples.json');seen=set()
        for e in entries:
            data=read(e['path']);schema=read(e['schema']);valid=jsonschema.Draft202012Validator(schema).is_valid(data)
            assert valid==e['valid'],(e['path'],list(jsonschema.Draft202012Validator(schema).iter_errors(data))[:1])
            key=(e['path'],e['schema']);seen.add(key)
        return {'indexed_example_count':len(entries),'unique_example_pairs':len(seen),'negative_examples':sum(not e['valid'] for e in entries)}
    check('schema_examples',examples)
    def requests():
        entries=read('examples/requests/index.json')
        for e in entries:
            x=read(e['path']);b=x['body'] if e['route']=='responses_batch' else x
            fmt=b['text']['format'];assert fmt['strict'] is True and fmt['type']=='json_schema'
            assert fmt['schema']==read('contracts/wire/'+e['output_contract']+'.schema.json')
            assert b['truncation']=='disabled';assert b['max_output_tokens']>0
            text=b['input'][0]['content'][0]['text'];value=json.loads(text)
            jsonschema.Draft202012Validator(read(e['input_schema'])).validate(value)
            if e['route']=='responses_batch':
                assert x['method']=='POST' and x['url']=='/v1/responses'
                assert not(set(b)&{'previous_response_id','conversation','background','tools','stream'})
                assert b['store'] is False
        return {'response_request_examples':len(entries),'all_are_unsubmitted_examples':True}
    check('requests',requests)
    def registry():
        stages=read('policies/stages.json')['stages'];contracts=read('policies/contracts.json')
        for st in stages:
            assert st['contract'] in contracts['wire'];assert (ROOT/st['prompt_file']).is_file();assert (ROOT/st['input_schema']).is_file()
        for ident,record in contracts['wire'].items():
            schema=read(record['path']);assert hashlib.sha256(canonical(schema)).hexdigest()==record['schema_sha256'],ident
        ids=[s['id'] for s in stages];assert len(ids)==len(set(ids))
        return {'stages':len(stages),'registry_hashes_valid':True}
    check('registry',registry)
    def goals():
        cases=read('acceptance/catalog.json')['cases'];mapping=read('acceptance/goals_matrix.json')
        for i in range(1,12):
            g=f'G{i:02d}';assert mapping[g];assert all(any(c['id']==id and g in c['goals'] for c in cases) for id in mapping[g])
        assert len({c['id'] for c in cases})==len(cases)
        return {'goals':11,'production_acceptance_cases_defined_not_executed':len(cases)}
    check('eleven_goals_traceability',goals)
    def fsm():
        m=read('state_machines/task.json');states=set(m['states']);pairs=[]
        for t in m['transitions']:
            assert t['from'] in states and t['to'] in states and t['guard'];pairs.append((t['from'],t['event']))
        assert len(set(pairs))==len(pairs)
        assert not any(t['from']=='submission_unknown' and t['to']=='submitting' for t in m['transitions'])
        return {'states':len(states),'transitions':len(pairs)}
    check('state_machine',fsm)
    def tests():
        sys.path.insert(0,str(ROOT/'reference'))
        suite=unittest.defaultTestLoader.discover(str(ROOT/'reference'),pattern='test_reference.py')
        stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        (ROOT/'acceptance/REFERENCE_TEST_LOG.txt').write_text(stream.getvalue(),encoding='utf-8')
        assert result.wasSuccessful(),stream.getvalue()
        return {'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)}
    check('reference_algorithm_tests',tests)
    def hygiene():
        bad=[]
        for f in ROOT.rglob('*'):
            if f.is_file() and f.suffix.lower() in {'.ttf','.otf','.woff','.woff2','.pem','.p12','.key','.db'}:bad.append(str(f.relative_to(ROOT)))
            if f.is_file() and f.suffix.lower() in {'.md','.json','.py','.sql','.txt'}:
                raw=f.read_bytes();assert not raw.startswith(b'\xef\xbb\xbf'),str(f)
                raw.decode('utf-8')
        assert not bad,bad
        return {'no_fonts_credentials_or_runtime_databases':True,'utf8_no_bom':True}
    check('package_hygiene',hygiene)
    report['status']='passed' if not report['errors'] else 'failed'
    args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
