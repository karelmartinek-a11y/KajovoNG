"""Overi kontrolni soucty distribucniho baliku bez site a bez zmen obsahu."""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    manifest = root / 'MANIFEST.sha256'
    if not manifest.is_file():
        print('MISSING: MANIFEST.sha256', file=sys.stderr)
        return 2
    failed = []
    seen = set()
    for no, line in enumerate(manifest.read_text(encoding='utf-8').splitlines(), 1):
        try:
            expected, name = line.split('  ', 1)
        except ValueError:
            failed.append(f'LINE {no}: malformed record')
            continue
        if len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected):
            failed.append(f'LINE {no}: malformed SHA-256')
            continue
        path = root / name
        if name in seen or Path(name).is_absolute() or '..' in Path(name).parts or not path.is_file() or path.is_symlink():
            failed.append(f'UNSAFE_OR_MISSING: {name}')
            continue
        seen.add(name)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            failed.append(f'MISMATCH: {name}')
    if failed:
        print('\n'.join(failed), file=sys.stderr)
        return 1
    print(f'PASS: {len(seen)} files match MANIFEST.sha256')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
