# CHANGE — změnový repozitář KájovoNG

**Určeno implementátorovi, nikoli jako již dokončená verze aplikace.** Balík obsahuje normativní zadání, strojové kontrakty, konkrétní pracovní prompty, příklady volání, migrační rozhraní a ověřovací postupy pro celý KájovoNG. Neobsahuje produkční klíče, placené běhové logy, fonty ani distribuční kopii původního repozitáře.

## Výchozí bod

Repozitář: `karelmartinek-a11y/KajovoNG`. Auditovaná větev `main`, commit `c4bacbd9f94337cbdf4bd6d95f53cff981b1f5d4`. Tento SHA je referenční základ návrhu, nikoli pokyn vrátit budoucí implementaci na starý commit. Před programováním spusťte `tools/check_baseline.py` proti skutečnému pracovnímu stromu; novější změny zachovejte a zkontrolujte jejich průnik s mapou změn.

## Pořadí čtení a závaznost

1. `ZADANI.md` — cíl změny, všech jedenáct invariantů a společný kontrakt výrobní platformy.
2. `docs/01_ROZHODNUTI.md` — závazná architektonická rozhodnutí, funkční rozhraní a validační pravidla.
3. `docs/02_KONTEXT_ROZPOCET_API.md` — konstrukce requestů, přesné kontexty, zdroje, náklady, tokeny a opravy.
4. `docs/workflows/` — úplné životní cykly GENERATE, MODIFY, QA, QFILE, kaskád, fotografií a komiksu.
5. `docs/03_STAVY_OBNOVA_UI.md` a `docs/04_TOOLS_A_BEZPECNE_OVERENI.md` — obnova, souběh, nástroje, UI, bezpečnost a skutečné ověření.
6. `docs/05_DRATOVE_A_DATOVE_INVARIANTY.md` — doplňující pravidla pro hashování, datové identity, schémata, migrace a hotové příklady.
7. `migration/README.md` a `migration/file_map.json` — pracovní balíky a přímé vazby na původní moduly.
8. `acceptance/README.md`, `acceptance/catalog.json`, `acceptance/goals_matrix.json` — důkazní podmínky přijetí změny.

Strojové soubory `contracts/`, `policies/` a `state_machines/` jsou normativní pro názvy, typy, hodnoty a limity; text vysvětluje jejich algoritmus a účel. Explicitní lokální omezení jsou pravidly produktu, nikoli tvrzením, že OpenAI má totožný limit. Příklady nikdy nepřebíjejí schéma. Při zjištění skutečného rozporu implementátor nesmí zvolit vlastní variantu: změnu zablokuje jako `SPEC_CONFLICT` a uvede oba zdroje rozporu. Nesmí si pomoci uvolněním validátoru.

## Obsah

- `contracts/wire/`: schémata strukturovaných odpovědí modelu. Neobsahují programem již známá souborová metadata.
- `contracts/input/`: přesně typované pracovní vstupy jednotlivých fází.
- `contracts/local/`: lokální artefakty, konfigurace, manifesty, rozpočtové rezervace a evidence ověření.
- `policies/`: registr kontraktů a fází, explicitní modelové role, parametry, finanční a kontextové limity, pravidla obrázků a nástrojů.
- `prompts/`: skutečné instrukce pro každou fázi, nikoli obecné fráze „doplňte prompt“.
- `examples/`: úplné JSON requesty, JSONL dávky, příklady výsledků a úmyslně vadné vstupy.
- `state_machines/`: povolené přechody, události a podmínky. Chybějící přechod znamená zákaz.
- `reference/`: spustitelné referenční implementace kritických invariantů a jejich offline jednotkové testy; nejde o náhradu integrace do aplikace.
- `migration/`: mapování změn, SQL pro novou orchestrace evidenci a pravidla legacy.
- `evidence/`: podklady auditu a zdroje; ne obsah uživatelských provozních dat.
- `diagrams/`: textové Mermaid diagramy pracovních toků.

## Kontrola balíku

Po rozbalení přejděte do adresáře `CHANGE`. Použijte Python 3.12+ a prostředí s `jsonschema` řady 4, která je již závislostí KájovoNG. Kontrola neprovádí síťová ani generativní volání:

```sh
python -B tools/validate_package.py --strict
python -B tools/check_baseline.py --repo /cesta/ke/KajovoNG
```

Samostatné referenční testy lze spustit:

```sh
python -B -m unittest discover -s reference -p 'test_*.py' -v
```

`VALIDATION_REPORT.json` a `acceptance/REFERENCE_TEST_LOG.txt` uvádějí skutečný výsledek poslední kontroly tohoto balíku. `MANIFEST.sha256` pokrývá všechny ostatní dodané soubory. Kontrola balíku neověřuje implementaci KájovoNG, oprávnění účtu ani úspěch živé generace.

## Co je a není garantováno

Návrh stanovuje deterministicky vynutitelné vlastnosti: neplatný artefakt se nepředá dál, neautorizovaný placený request se neodešle, neurčitý submit se automaticky neopakuje, ruční změna se nepřepíše a „ověřeno“ vznikne jen z doložené sady kontrol. Úspěch každého modelového výstupu, bezchybnou aplikaci pro libovolné zadání ani dokonalou shodu fotografií a komiksových postav nelze odvodit z JSON schématu. Selhání a nejistota jsou proto explicitní výsledky, ne zakryté stavy.

Před uvolněním změny musí implementace prokázat všechny scénáře `acceptance/catalog.json`. Zvlášť se vykazuje offline CI, skutečný placený acceptance běh a případné lidské obsahové schválení. V tomto dodání nevznikla nová produkční úprava GitHub `main` ani nový placený OpenAI běh.