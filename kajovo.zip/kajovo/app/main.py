from __future__ import annotations

import os
import subprocess
import sys
import venv
from pathlib import Path

from ..core.config import load_settings


_BOOT_ENV_FLAG = "KAJOVO_BOOTSTRAP_ATTEMPTED"


def _get_repo_paths() -> tuple[Path, Path]:
    root = Path(__file__).resolve().parents[2]
    venv_dir = root / "venv"
    return root, venv_dir


def _venv_python(venv_dir: Path) -> Path:
    bin_dir = "Scripts" if os.name == "nt" else "bin"
    exe = "python.exe" if os.name == "nt" else "python"
    return venv_dir / bin_dir / exe


def _bootstrap_runtime_if_needed() -> None:
    """Ensure PySide6 is available, re-exec in repo venv or install if needed."""

    try:
        import PySide6  # noqa: F401
        return  # Already available in this interpreter
    except ModuleNotFoundError as exc:
        if exc.name != "PySide6":
            raise

    # Avoid looping forever if install keeps failing
    if os.environ.get(_BOOT_ENV_FLAG) == "1":
        raise ModuleNotFoundError(
            "PySide6 is missing. Activate the repo venv or run `pip install -r requirements.txt`."
        )

    root, venv_dir = _get_repo_paths()
    venv_python = _venv_python(venv_dir)

    # If repo venv exists and we're not inside it, re-exec there (PySide6 is already installed there).
    if venv_python.exists() and Path(sys.executable).resolve() != venv_python.resolve():
        os.environ[_BOOT_ENV_FLAG] = "1"
        os.execv(str(venv_python), [str(venv_python), "-m", "kajovo.app.main"])

    # Otherwise create/refresh the venv and install requirements, then re-run.
    if not venv_python.exists():
        venv_dir.mkdir(parents=True, exist_ok=True)
        venv.create(venv_dir, with_pip=True)

    subprocess.check_call(
        [str(venv_python), "-m", "pip", "install", "-r", str(root / "requirements.txt")]
    )

    os.environ[_BOOT_ENV_FLAG] = "1"
    os.execv(str(venv_python), [str(venv_python), "-m", "kajovo.app.main"])

def _load_fonts():
    from PySide6.QtGui import QFontDatabase

    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    res = os.path.join(root, "resources")
    reg = os.path.join(res, "montserrat_regular.ttf")
    bold = os.path.join(res, "montserrat_bold.ttf")
    for p in (reg, bold):
        if os.path.exists(p):
            QFontDatabase.addApplicationFont(p)

def main():
    _bootstrap_runtime_if_needed()

    # Ztlumime Qt QPA logy, ktere se na nekterych PC objevuji jako:
    # "monitorData: Unable to obtain handle for monitor ...".
    # Je to nefatalni, ale zbytecne to strasi v konzoli.
    rules = os.environ.get("QT_LOGGING_RULES", "")
    if "qt.qpa" not in rules:
        os.environ["QT_LOGGING_RULES"] = (rules + (";" if rules else "") + "qt.qpa.*=false").strip(";")

    from PySide6.QtCore import QCoreApplication, Qt
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import QApplication
    from ..ui.mainwindow import MainWindow
    from ..ui.splash import SplashScreen
    from ..ui.widgets import app_icon

    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    QCoreApplication.setAttribute(Qt.AA_DontUseNativeDialogs, True)
    app = QApplication(sys.argv)
    app.setApplicationName("Kájovo NG")
    app.setOrganizationName("Kájovo")
    app.setWindowIcon(app_icon())

    _load_fonts()

    # default font (falls back if Montserrat missing)
    f = QFont("Montserrat", 10)
    app.setFont(f)

    splash = SplashScreen(title="Kájovo NG", subtitle="Neural workspace")
    splash.show()
    splash.set_status("Preparing UI…")

    settings = load_settings()
    splash.set_status("Loading modules…")
    w = MainWindow(settings)
    splash.set_status("Ready")
    splash.finish()
    w.showMaximized()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
