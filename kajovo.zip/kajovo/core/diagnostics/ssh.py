from __future__ import annotations

import os, time, posixpath, tarfile
from typing import List, Tuple, Optional, Callable
import paramiko
from ..utils import ensure_dir

REMOTE_SCRIPT = r"""#!/usr/bin/env bash
set -o pipefail
set +e

outdir="$1"
mkdir -p "$outdir"/{system,hardware,storage,network,firewall,users_permissions,processes_services,packages,web,nginx,app,python,database,certs,cron_webhooks,logs,virtualization_containers}

write_cmd() { out="$1"; shift; cmd="$*"; if [ -z "$cmd" ]; then echo "NO COMMAND" > "$out"; return; fi; eval "$cmd" > "$out" 2>&1; }
write_if() { bin="$1"; out="$2"; shift 2; if command -v "$bin" >/dev/null 2>&1; then eval "$*" > "$out" 2>&1; else echo "NOT PRESENT: $bin" > "$out"; fi; }
write_file() { src="$1"; out="$2"; if [ -f "$src" ]; then cat "$src" > "$out" 2>&1; else echo "NOT PRESENT: $src" > "$out"; fi; }

# system
write_file /etc/os-release "$outdir/system/os_release.txt"
write_cmd "$outdir/system/uname_a.txt" "uname -a"
write_cmd "$outdir/system/uptime.txt" "uptime && who -b"
write_cmd "$outdir/system/locale_timezone.txt" "locale && (timedatectl 2>/dev/null || true)"
write_cmd "$outdir/system/hostname_hosts.txt" "hostnamectl 2>/dev/null || true; cat /etc/hosts; cat /etc/hostname 2>/dev/null || true"
write_cmd "$outdir/system/limits_summary.txt" "ulimit -a"
write_cmd "$outdir/system/sysctl_all.txt" "sysctl -a 2>/dev/null || true"

# hardware
write_if lscpu "$outdir/hardware/cpu.txt" "lscpu"
write_cmd "$outdir/hardware/memory_summary.txt" "free -h"
write_cmd "$outdir/hardware/dmesg_tail.txt" "dmesg | tail -n 200"

# storage
write_cmd "$outdir/storage/df_h.txt" "df -h"
write_cmd "$outdir/storage/df_i.txt" "df -i"
write_if lsblk "$outdir/storage/lsblk.txt" "lsblk -a"
write_cmd "$outdir/storage/mounts.txt" "mount"

# network
write_if ip "$outdir/network/ip_addr.txt" "ip a"
write_if ip "$outdir/network/routes.txt" "ip r"
write_file /etc/resolv.conf "$outdir/network/resolv.conf"
write_cmd "$outdir/network/ss_listen.txt" "ss -lntup 2>/dev/null || netstat -lntup 2>/dev/null || true"

# firewall
write_if ufw "$outdir/firewall/ufw_status.txt" "ufw status verbose"
write_if iptables "$outdir/firewall/iptables_rules.txt" "iptables -S"
write_if nft "$outdir/firewall/nft_rules.txt" "nft list ruleset"

# users/permissions
write_file /etc/passwd "$outdir/users_permissions/passwd.txt"
write_file /etc/group "$outdir/users_permissions/group.txt"
write_cmd "$outdir/users_permissions/sudoers.txt" "cat /etc/sudoers 2>/dev/null || true; ls -la /etc/sudoers.d 2>/dev/null || true"

# processes/services
write_cmd "$outdir/processes_services/ps_aux.txt" "ps auxww"
write_if systemctl "$outdir/processes_services/systemctl_running.txt" "systemctl list-units --type=service --state=running"

# packages
write_if dpkg "$outdir/packages/dpkg_list.txt" "dpkg -l"
write_if rpm "$outdir/packages/rpm_list.txt" "rpm -qa"
write_if apk "$outdir/packages/apk_list.txt" "apk info -vv"

# web
write_cmd "$outdir/web/web_roots.txt" "ls -la /var/www 2>/dev/null || true"
write_cmd "$outdir/web/web_sizes.txt" "du -sh /var/www/* 2>/dev/null || true"

# nginx
write_if nginx "$outdir/nginx/nginx_v.txt" "nginx -V"
write_if nginx "$outdir/nginx/nginx_t.txt" "nginx -t"
write_if nginx "$outdir/nginx/nginx_T.txt" "nginx -T"
write_cmd "$outdir/nginx/nginx_logs_tail.txt" "tail -n 200 /var/log/nginx/error.log 2>/dev/null || true; tail -n 200 /var/log/nginx/access.log 2>/dev/null || true"

# app
write_if systemctl "$outdir/app/systemd_units.txt" "systemctl list-unit-files"
write_file /etc/environment "$outdir/app/environment.txt"

# python
write_cmd "$outdir/python/which_python.txt" "which python3 2>/dev/null || which python 2>/dev/null || true"
write_if python3 "$outdir/python/python3_version.txt" "python3 --version"
write_if python3 "$outdir/python/pip3_version.txt" "python3 -m pip --version"
write_cmd "$outdir/python/venv_candidates_found.txt" "find / -name pyvenv.cfg 2>/dev/null | head -n 200"

# database
write_if systemctl "$outdir/database/postgres_status.txt" "systemctl status postgresql --no-pager"
write_if systemctl "$outdir/database/mysql_status.txt" "systemctl status mysql --no-pager"
write_if systemctl "$outdir/database/redis_status.txt" "systemctl status redis --no-pager"

# certs
write_if certbot "$outdir/certs/certbot_inventory.txt" "certbot certificates"

# cron/webhooks
write_cmd "$outdir/cron_webhooks/cron_list.txt" "crontab -l 2>/dev/null || true"
write_cmd "$outdir/cron_webhooks/cron_dirs.txt" "ls -la /etc/cron* 2>/dev/null || true"

# logs
write_if journalctl "$outdir/logs/journal_last500.txt" "journalctl -n 500 --no-pager"
write_cmd "$outdir/logs/syslog_tail.txt" "tail -n 200 /var/log/syslog 2>/dev/null || true"
write_cmd "$outdir/logs/auth_tail.txt" "tail -n 200 /var/log/auth.log 2>/dev/null || true"

# virtualization/containers
write_if docker "$outdir/virtualization_containers/docker_info.txt" "docker info"
write_if docker "$outdir/virtualization_containers/docker_ps.txt" "docker ps -a"
write_if docker "$outdir/virtualization_containers/docker_compose.txt" "docker compose ls"

tar -czf "$outdir.tar.gz" -C "$(dirname $outdir)" "$(basename $outdir)" 2>/dev/null || true
echo "TAR=$outdir.tar.gz"
"""

def collect_ssh_diagnostics(local_base_dir: str, host: str, username: str, key_path: str, password: str = "", on_line: Optional[Callable[[str], None]] = None, timeout_s: int = 600) -> Tuple[str, List[str]]:
    ensure_dir(local_base_dir)
    ts = time.strftime("%Y%m%d-%H%M%S")
    local_root = os.path.join(local_base_dir, f"Diag_{ts}")
    ensure_dir(local_root)

    def log(msg: str) -> None:
        if on_line:
            try:
                on_line(msg)
            except Exception:
                pass

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    pkey = None
    if key_path:
        try:
            pkey = paramiko.RSAKey.from_private_key_file(key_path, password=password or None)
        except Exception:
            try:
                pkey = paramiko.Ed25519Key.from_private_key_file(key_path, password=password or None)
            except Exception:
                pkey = None

    client.connect(hostname=host, username=username, pkey=pkey, password=(password or None), timeout=20)
    try:
        sftp = client.open_sftp()
        remote_script = f"/tmp/kajovo_diag_{ts}.sh"
        log("SSH: upload script...")
        with sftp.open(remote_script, "w") as f:
            f.write(REMOTE_SCRIPT)
        sftp.chmod(remote_script, 0o700)

        remote_outdir = f"/root/Diag_{ts}"
        log("SSH: run diagnostics script...")
        stdin, stdout, stderr = client.exec_command(f"bash {remote_script} {remote_outdir}", get_pty=True)
        channel = stdout.channel
        start = time.time()
        out_chunks: List[str] = []
        err_chunks: List[str] = []
        last_tick = 0.0
        while True:
            if channel.exit_status_ready():
                break
            if time.time() - start > timeout_s:
                raise RuntimeError("SSH diagnostics timeout.")
            if channel.recv_ready():
                out_chunks.append(channel.recv(65536).decode("utf-8", errors="ignore"))
            if channel.recv_stderr_ready():
                err_chunks.append(channel.recv_stderr(65536).decode("utf-8", errors="ignore"))
            if time.time() - last_tick > 10.0:
                log("SSH: running...")
                last_tick = time.time()
            time.sleep(0.2)
        # drain buffers
        while channel.recv_ready():
            out_chunks.append(channel.recv(65536).decode("utf-8", errors="ignore"))
        while channel.recv_stderr_ready():
            err_chunks.append(channel.recv_stderr(65536).decode("utf-8", errors="ignore"))
        out = "".join(out_chunks)
        err = "".join(err_chunks)
        with open(os.path.join(local_root, "_ssh_exec.txt"), "w", encoding="utf-8") as f:
            f.write("STDOUT\n"+out+"\n\nSTDERR\n"+err)

        tar_path = None
        for line in out.splitlines():
            if line.startswith("TAR="):
                tar_path = line.split("=",1)[1].strip()
        if not tar_path:
            tar_path = remote_outdir + ".tar.gz"

        local_tar = os.path.join(local_root, "diag.tar.gz")
        log("SSH: download bundle...")
        try:
            sftp.get(tar_path, local_tar)
        except Exception:
            # last resort: download single _ssh_exec only
            return local_root, [os.path.join(local_root, "_ssh_exec.txt")]

        extracted_root = os.path.join(local_root, "diag_extracted")
        os.makedirs(extracted_root, exist_ok=True)
        extracted_files: List[str] = []
        try:
            log("SSH: extract bundle...")
            with tarfile.open(local_tar, "r:gz") as tf:
                tf.extractall(path=extracted_root)
            for root, _, fnames in os.walk(extracted_root):
                for fn in fnames:
                    extracted_files.append(os.path.join(root, fn))
        except Exception:
            extracted_files = []
        files_out = extracted_files if extracted_files else []
        files_out.append(os.path.join(local_root, "_ssh_exec.txt"))
        return local_root, files_out
    finally:
        try:
            client.close()
        except Exception:
            pass
