from __future__ import annotations

import json, re
from typing import Any, Dict, List

class ContractError(Exception):
    pass

def extract_text_from_response(resp: Dict[str, Any]) -> str:
    if "output_text" in resp and isinstance(resp["output_text"], str):
        return resp["output_text"]
    out = resp.get("output")
    if isinstance(out, list):
        texts: List[str] = []
        for item in out:
            if isinstance(item, dict):
                content = item.get("content")
                if isinstance(content, list):
                    for c in content:
                        if isinstance(c, dict) and c.get("type") in ("output_text","text"):
                            t = c.get("text") or c.get("content") or ""
                            if isinstance(t, str):
                                texts.append(t)
        if texts:
            return "\n".join(texts)
    for k in ("text","content","message"):
        if isinstance(resp.get(k), str):
            return resp[k]
    return json.dumps(resp, ensure_ascii=False)

_JSON_OBJ_RE = re.compile(r"(\{.*\})", re.DOTALL)


def _repair_mismatched_brackets(text: str) -> tuple[str, bool]:
    stack: List[str] = []
    repaired: List[str] = []
    in_string = False
    escaped = False
    repaired_any = False
    for ch in text:
        if escaped:
            repaired.append(ch)
            escaped = False
            continue
        if ch == "\\" and in_string:
            repaired.append(ch)
            escaped = True
            continue
        if ch == '"':
            repaired.append(ch)
            in_string = not in_string
            continue
        if in_string:
            repaired.append(ch)
            continue
        if ch in "{[":
            stack.append(ch)
            repaired.append(ch)
            continue
        if ch in "}]":
            top = stack[-1] if stack else None
            if ch == "}" and top == "[":
                stack.pop()
                repaired.append("]")
                repaired_any = True
                continue
            if ch == "]" and top == "{":
                stack.pop()
                repaired.append("}")
                repaired_any = True
                continue
            if stack:
                stack.pop()
            repaired.append(ch)
            continue
        repaired.append(ch)
    return "".join(repaired), repaired_any

def parse_json_strict(text: str) -> Dict[str, Any]:
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        repaired, changed = _repair_mismatched_brackets(text)
        if changed:
            try:
                return json.loads(repaired)
            except Exception:
                pass
        source = repaired if changed else text
        m = _JSON_OBJ_RE.search(source)
        if m:
            candidate = m.group(1)
            try:
                return json.loads(candidate)
            except Exception:
                repaired_candidate, _ = _repair_mismatched_brackets(candidate)
                try:
                    return json.loads(repaired_candidate)
                except Exception:
                    pass
        raise ContractError("Response is not valid JSON (strict contract violated).")

def validate_paths(files: List[Dict[str, Any]]) -> None:
    seen = set()
    for f in files:
        p = f.get("path","")
        if not isinstance(p, str) or not p:
            raise ContractError("Invalid path in files[]")
        if p.startswith("/") or p.startswith("\\"):
            raise ContractError(f"Path must be relative: {p}")
        if ".." in p.split("/"):
            raise ContractError(f"Path cannot contain '..': {p}")
        if "\\" in p:
            raise ContractError(f"Path cannot contain \\: {p}")
        if p in seen:
            raise ContractError(f"Duplicate path: {p}")
        seen.add(p)
