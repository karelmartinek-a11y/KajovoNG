from __future__ import annotations
import os
from .widgets import (
    msg_info,
    msg_warning,
    msg_critical,
    msg_question,
    dialog_input_text,
    dialog_select_dir,
    TitleBar,
    app_icon,
)

import time
from typing import List, Optional, Dict, Any

from PySide6.QtCore import Signal, QThread, QTimer, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QListWidgetItem,
    QLineEdit, QLabel, QMessageBox, QSplitter, QDialog, QDialogButtonBox, QPlainTextEdit
)

from ..core.openai_client import OpenAIClient
from ..core.filescan import (
    ScanItem,
    SENSITIVE_NAMES,
    SECRET_PATTERNS,
    ext_of,
    is_probably_binary,
    is_versing_snapshot_dir,
    match_any_glob,
    scan_tree,
)
from ..core.compat import ALLOWED_EXTS
from ..core.utils import sha256_file, ts_code
from ..core.retry import with_retry, CircuitBreaker
from .widgets import BusyPopup
from .task_progress_dialog import TaskProgressDialog
from .upload_progress_dialog import UploadProgressDialog


class VectorStoresDeleteWorker(QThread):
    progress = Signal(int)
    subprogress = Signal(int)
    status = Signal(str)
    logline = Signal(str)
    finished = Signal(object, list, int, int)  # stores or None, errors, deleted, total

    def __init__(self, api_key: str, store_ids: List[str], retry_cfg, breaker_failures: int, breaker_cooldown_s: int):
        super().__init__()
        self.api_key = api_key
        self.store_ids = list(store_ids)
        self.retry_cfg = retry_cfg
        self.breaker_failures = breaker_failures
        self.breaker_cooldown_s = breaker_cooldown_s
        self._stop = False

    def request_stop(self):
        self._stop = True

    def _check_stop(self):
        if self._stop or self.isInterruptionRequested():
            raise RuntimeError("Canceled by user")

    def run(self):
        stores: List[dict] | None = None
        errors: List[str] = []
        deleted = 0
        total = len(self.store_ids)
        try:
            if not self.api_key:
                self.finished.emit(stores, ["Chybí OPENAI_API_KEY."], deleted, total)
                return
            client = OpenAIClient(self.api_key)
            breaker = CircuitBreaker(self.breaker_failures, self.breaker_cooldown_s)
            self.progress.emit(0)
            self.subprogress.emit(0)
            for idx, vs_id in enumerate(self.store_ids):
                self._check_stop()
                step = idx + 1
                self.status.emit(f"Store {step}/{total}: {vs_id}")
                self.logline.emit(f"Načítám soubory ve store {vs_id}...")
                files: List[Dict[str, Any]] = []
                try:
                    self.progress.emit(0)
                    self.logline.emit("Upload directory: start")
                    files = with_retry(lambda: client.list_vector_store_files(vs_id), self.retry_cfg, breaker)
                except Exception as e:
                    errors.append(f"{vs_id}: nelze načíst soubory ({e})")
                    self.logline.emit(f"Chyba při načítání souborů {vs_id}: {e}")
                    self.progress.emit(int(step * 100 / max(1, total)))
                    continue

                if files:
                    self.logline.emit(f"Mažu {len(files)} souborů ve store {vs_id}...")
                for f_idx, f in enumerate(files):
                    self._check_stop()
                    fid = f.get("id")
                    if not fid:
                        continue
                    self.status.emit(f"Mažu soubor {f_idx + 1}/{len(files)} ve store {vs_id}")
                    self.subprogress.emit(int((f_idx + 1) * 100 / max(1, len(files))))
                    try:
                        with_retry(lambda fid=fid: client.delete_vector_store_file(vs_id, fid), self.retry_cfg, breaker)
                    except Exception as e:
                        errors.append(f"{vs_id}/{fid}: {e}")
                        self.logline.emit(f"Chyba při mazání souboru {fid}: {e}")

                if files:
                    self.logline.emit(f"Removed {len(files)} files from vector store {vs_id}")
                self.status.emit(f"Mažu vector store {vs_id}")
                try:
                    with_retry(lambda: client.delete_vector_store(vs_id), self.retry_cfg, breaker)
                    deleted += 1
                    self.logline.emit(f"Deleted vector store: {vs_id}")
                except Exception as e:
                    errors.append(f"{vs_id}: {e}")
                    self.logline.emit(f"Chyba při mazání store {vs_id}: {e}")
                self.subprogress.emit(0)
                self.progress.emit(int(step * 100 / max(1, total)))

            try:
                stores = with_retry(lambda: client.list_vector_stores(), self.retry_cfg, breaker)
            except Exception as e:
                self.logline.emit(f"Refresh failed: {e}")
        except Exception as e:
            errors.append(str(e))
            self.logline.emit(f"Mazani preruseno: {e}")
        self.finished.emit(stores, errors, deleted, total)


class UploadDirectoryWorker(QThread):
    status = Signal(str)
    logline = Signal(str)
    progress = Signal(int)
    done = Signal(object, list, int, int, int, list, str)  # vs_id, errors, uploaded, added, total, vs_file_ids, err_msg

    def __init__(self, api_key: str, retry_cfg, breaker_failures: int, breaker_cooldown_s: int,
                 files, root_dir: str, vs_name: str):
        super().__init__()
        self.api_key = api_key
        self.retry_cfg = retry_cfg
        self.breaker_failures = breaker_failures
        self.breaker_cooldown_s = breaker_cooldown_s
        self.files = list(files)
        self.root_dir = root_dir
        self.vs_name = vs_name
        self._stop = False

    def request_stop(self):
        self._stop = True

    def _check_stop(self):
        if self._stop or self.isInterruptionRequested():
            raise RuntimeError("Canceled by user")

    def run(self):
        errors: list[str] = []
        uploaded = 0
        added = 0
        vs_id = ""
        vs_file_ids: list[str] = []
        vs_file_map: dict[str, str] = {}
        uploaded_files: list[tuple[ScanItem, str]] = []
        try:
            client = OpenAIClient(self.api_key)
            breaker = CircuitBreaker(self.breaker_failures, self.breaker_cooldown_s)

            total = len(self.files)
            self.logline.emit(f"Upload run start: {total} files, root={self.root_dir}, vs_name={self.vs_name}")
            # 1) Upload všech souborů na Files API
            for idx, it in enumerate(self.files, 1):
                self._check_stop()
                self.status.emit(f"Upload {idx}/{total}: {it.rel_path}")
                self.logline.emit(f"Files API upload: {it.rel_path}")
                self.progress.emit(int(idx * 100 / max(1, total * 2)))  # první polovina progress baru
                try:
                    self._check_stop()
                    res = with_retry(lambda p=it.abs_path: client.upload_file(p, purpose="user_data"), self.retry_cfg, breaker)
                    file_id = str(res.get("id") or "")
                    if not file_id:
                        raise RuntimeError("Prázdné file_id z Files API.")
                    uploaded += 1
                    uploaded_files.append((it, file_id))
                except Exception as e:
                    errors.append(f"{it.rel_path}: {e}")
                    self.logline.emit(f"Upload error {it.rel_path}: {e}")

            if not uploaded_files:
                raise RuntimeError("Žádný soubor se nepodařilo nahrát na Files API.")

            # 2) Založení vector store
            self._check_stop()
            self.status.emit("Vytvářím vector store...")
            vs = with_retry(lambda: client.create_vector_store(self.vs_name), self.retry_cfg, breaker)
            vs_id = str(vs.get("id") or "")
            if not vs_id:
                raise RuntimeError("API vrátilo prázdné id store.")
            self.logline.emit(f"Vector store: {vs_id}")

            # 3) Přidání souborů do store
            for idx, (it, file_id) in enumerate(uploaded_files, 1):
                self._check_stop()
                self.status.emit(f"Přidávám do store {idx}/{len(uploaded_files)}: {it.rel_path}")
                self.progress.emit(int((uploaded + idx) * 100 / max(1, total * 2)))  # druhá polovina progress baru
                try:
                    self._check_stop()
                    attrs = {
                        "abs_path": it.abs_path,
                        "rel_path": it.rel_path,
                        "local_path": it.abs_path,
                    }
                    vs_file = with_retry(lambda: client.add_file_to_vector_store(vs_id, file_id, attrs), self.retry_cfg, breaker)
                    vs_file_id = str(vs_file.get("id") or "")
                    if vs_file_id:
                        vs_file_ids.append(vs_file_id)
                        vs_file_map[vs_file_id] = it.rel_path
                    added += 1
                    self.logline.emit(f"Přidáno do store: {it.rel_path} (file_id={file_id})")
                except Exception as e:
                    errors.append(f"{it.rel_path} (add to store): {e}")
                    self.logline.emit(f"Chyba při přidání do store {it.rel_path}: {e}")

            # 4) Počkat na indexaci
            if vs_file_ids:
                self.logline.emit(f"Čekám na indexaci {len(vs_file_ids)} souborů...")
                self._wait_vector_store_files(client, vs_id, vs_file_ids, breaker, errors, vs_file_map)
                self.logline.emit("Indexace dokončena.")

            self.progress.emit(100)
            self.done.emit(vs_id, errors, uploaded, added, len(self.files), vs_file_ids, "")
        except Exception as e:
            self.done.emit(vs_id, errors, uploaded, added, len(self.files), vs_file_ids, str(e))

    def _wait_vector_store_files(
        self,
        client: OpenAIClient,
        vs_id: str,
        vs_file_ids: list[str],
        breaker: CircuitBreaker,
        errors: list[str],
        vs_file_map: dict[str, str],
        timeout_s: int = 180,
    ) -> None:
        # Dynamický timeout podle počtu souborů (min 180s, max 900s)
        timeout_s = max(180, min(900, timeout_s + 10 * len(vs_file_ids)))
        start = time.time()
        pending = set(vs_file_ids)
        while pending:
            self._check_stop()
            if time.time() - start > timeout_s:
                raise RuntimeError(f"Vector store index timeout ({vs_id}).")
            completed: list[str] = []
            for vs_file_id in list(pending):
                self._check_stop()
                try:
                    info = with_retry(lambda v=vs_id, f=vs_file_id: client.retrieve_vector_store_file(v, f), self.retry_cfg, breaker)
                except Exception as e:
                    self.logline.emit(f"Status {vs_file_id}: {e}")
                    continue
                status = str(info.get("status") or "")
                self.status.emit(f"Indexuji {vs_file_id}: {status}")
                if status == "completed":
                    completed.append(vs_file_id)
                elif status == "failed":
                    last_error = info.get("last_error") or {}
                    msg = last_error.get("message") or "Vector store indexing failed."
                    rel_path = vs_file_map.get(vs_file_id, "")
                    label = f"{rel_path} ({vs_file_id})" if rel_path else vs_file_id
                    errors.append(f"Indexace selhala {label}: {msg}")
                    self.logline.emit(f"Indexace selhala {label}: {msg}")
                    completed.append(vs_file_id)
            for done in completed:
                pending.discard(done)
            if pending:
                time.sleep(2.0)


class DirectoryScanWorker(QThread):
    status = Signal(str)
    logline = Signal(str)
    progress = Signal(int)
    done = Signal(list, str)  # items, err_msg

    def __init__(
        self,
        root: str,
        root_name: str,
        deny_dirs,
        deny_exts,
        allow_exts,
        deny_globs,
        allow_globs,
        max_size_bytes: int = 10 * 1024 * 1024,
        deny_dir_contains: list[str] | None = None,
    ):
        super().__init__()
        self.root = root
        self.root_name = root_name
        self.deny_dirs = deny_dirs
        # dodatečný filtr: přeskočí celé podstromy s těmito podřetězci (case-insensitive)
        self.deny_dir_contains = [s.lower() for s in (deny_dir_contains or [])]
        self.deny_exts = deny_exts
        self.allow_exts = allow_exts
        self.deny_globs = deny_globs
        self.allow_globs = allow_globs
        self.max_size_bytes = max_size_bytes
        self._stop = False

    def request_stop(self):
        self._stop = True

    def _check_stop(self):
        if self._stop or self.isInterruptionRequested():
            raise RuntimeError("Canceled by user")

    def _scan(self) -> list[ScanItem]:
        items: list[ScanItem] = []
        file_list: list[tuple[str, str]] = []

        for cur, dirs, files in os.walk(self.root):
            self._check_stop()
            kept = []
            for d in dirs:
                name_lower = d.lower()
                # přeskočíme adresáře podle přesného seznamu i podle podřetězců
                if d in self.deny_dirs or any(sub in name_lower for sub in self.deny_dir_contains):
                    continue
                if is_versing_snapshot_dir(d, self.root_name):
                    continue
                kept.append(d)
            dirs[:] = kept
            for fn in files:
                abs_path = os.path.join(cur, fn)
                rel_path = os.path.relpath(abs_path, self.root).replace("\\", "/")
                file_list.append((abs_path, rel_path))

        total = len(file_list)
        for idx, (abs_path, rel_path) in enumerate(file_list, 1):
            self._check_stop()
            if idx == 1 or idx % 25 == 0 or idx == total:
                pct = int(idx * 100 / max(1, total))
                self.progress.emit(pct)
                self.status.emit(f"Skenuji {idx}/{total}: {rel_path}")

            try:
                size = os.path.getsize(abs_path)
            except Exception:
                items.append(ScanItem(rel_path, abs_path, 0, None, False, "stat_failed", True))
                continue

            if self.allow_globs and not match_any_glob(rel_path, self.allow_globs):
                items.append(ScanItem(rel_path, abs_path, size, None, False, "not_in_allow_globs", False))
                continue
            if self.deny_globs and match_any_glob(rel_path, self.deny_globs):
                items.append(ScanItem(rel_path, abs_path, size, None, False, "deny_glob", False))
                continue

            ext = ext_of(rel_path)
            if self.allow_exts and ext not in [e.lower() for e in self.allow_exts]:
                items.append(ScanItem(rel_path, abs_path, size, None, False, "ext_not_allowed", False))
                continue
            if self.deny_exts and ext in [e.lower() for e in self.deny_exts]:
                items.append(ScanItem(rel_path, abs_path, size, None, False, "denied_extension", False))
                continue

            if size == 0:
                items.append(ScanItem(rel_path, abs_path, size, None, False, "empty_file", False))
                continue

            sensitive = (os.path.basename(abs_path).lower() in SENSITIVE_NAMES) or rel_path.lower().endswith(".env")
            if size > self.max_size_bytes:
                items.append(ScanItem(rel_path, abs_path, size, None, False, "too_large", sensitive))
                continue
            if ext not in {".png", ".jpg"} and is_probably_binary(abs_path):
                items.append(ScanItem(rel_path, abs_path, size, None, False, "binary", sensitive))
                continue

            secret_hit = False
            try:
                with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
                    head = f.read(20000)
                for rx in SECRET_PATTERNS:
                    if rx.search(head):
                        secret_hit = True
                        break
            except Exception:
                secret_hit = True

            if sensitive or secret_hit:
                items.append(ScanItem(rel_path, abs_path, size, None, False, "sensitive_or_secret_detected", True))
                continue

            sha = None
            try:
                sha = sha256_file(abs_path, max_bytes=5 * 1024 * 1024)
            except Exception:
                sha = None

            items.append(ScanItem(rel_path, abs_path, size, sha, True, "ok", False))

        items.sort(key=lambda x: x.rel_path)
        return items

    def run(self):
        try:
            self._check_stop()
            self.status.emit("Skenuji adresář...")
            self.logline.emit(f"Skenuji: {self.root}")
            items = self._scan()
            self.progress.emit(100)
            self.done.emit(items, "")
        except Exception as e:
            self.done.emit([], str(e))


class FilesSelectorDialog(QDialog):
    def __init__(self, client: OpenAIClient, retry_cfg, breaker: CircuitBreaker, parent=None):
        super().__init__(parent)
        self.client = client
        self.retry_cfg = retry_cfg
        self.breaker = breaker
        self.setWindowTitle("Kájovo NG — Vybrat soubory z Files API")
        self.setWindowIcon(app_icon())
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.resize(700, 500)
        from .theme import DARK_STYLESHEET
        self.setStyleSheet(DARK_STYLESHEET)

        v = QVBoxLayout(self)
        v.setContentsMargins(12, 12, 12, 12)
        v.setSpacing(10)

        self.titlebar = TitleBar("Files API", self)
        self.titlebar.request_close.connect(self.reject)
        v.addWidget(self.titlebar)
        top = QHBoxLayout()
        top.addWidget(QLabel("Filtrovat:"))
        self.ed_filter = QLineEdit()
        self.ed_filter.setPlaceholderText("text v id/filename")
        top.addWidget(self.ed_filter, 1)
        self.btn_refresh = QPushButton("Refresh")
        top.addWidget(self.btn_refresh)
        v.addLayout(top)

        self.lst = QListWidget()
        self.lst.setSelectionMode(QListWidget.MultiSelection)
        v.addWidget(self.lst, 1)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        v.addWidget(btns)

        self.ed_filter.textChanged.connect(self.apply_filter)
        self.btn_refresh.clicked.connect(self.load_files)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        self._all_files: List[Dict[str, Any]] = []
        self.load_files()

    def load_files(self):
        with BusyPopup(self, "Načítám Files API..."):
            try:
                self._all_files = with_retry(lambda: self.client.list_files(), self.retry_cfg, self.breaker)
            except Exception as e:
                msg_critical(self, "Files API", str(e))
                self._all_files = []
        self.apply_filter()

    def apply_filter(self):
        text = (self.ed_filter.text() or "").lower()
        self.lst.clear()
        for f in self._all_files:
            fid = f.get("id", "")
            name = f.get("filename", "")
            label = f"{fid}  |  {name}"
            if text and text not in fid.lower() and text not in name.lower():
                continue
            it = QListWidgetItem(label)
            it.setData(32, fid)
            self.lst.addItem(it)

    def selected_ids(self) -> List[str]:
        return [it.data(32) for it in self.lst.selectedItems() if it.data(32)]


class VectorStoresPanel(QWidget):
    logline = Signal(str)
    attached_changed = Signal(list)  # list[str]

    def __init__(self, settings, api_key: str, parent=None):
        super().__init__(parent)
        self.s = settings
        self.api_key = api_key
        self.client: Optional[OpenAIClient] = None
        self.breaker = CircuitBreaker(self.s.retry.circuit_breaker_failures, self.s.retry.circuit_breaker_cooldown_s)
        self._delete_worker: VectorStoresDeleteWorker | None = None
        self._delete_dialog: TaskProgressDialog | None = None

        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(8)

        top = QHBoxLayout()
        self.btn_refresh = QPushButton("Refresh")
        self.btn_create = QPushButton("Create")
        self.btn_upload_dir = QPushButton("Upload directory")
        self.btn_delete = QPushButton("Delete")
        self.btn_delete_all = QPushButton("Del ALL")
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_create)
        top.addWidget(self.btn_upload_dir)
        top.addWidget(self.btn_delete)
        top.addWidget(self.btn_delete_all)
        top.addStretch(1)
        v.addLayout(top)

        split = QSplitter()
        v.addWidget(split, 1)

        # Left: vector stores
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.addWidget(QLabel("Vector stores"))
        self.lst_vs = QListWidget()
        self.lst_vs.setSelectionMode(QListWidget.MultiSelection)
        lv.addWidget(self.lst_vs, 1)

        attach_row = QHBoxLayout()
        self.btn_attach = QPushButton("Attach →")
        self.btn_detach = QPushButton("← Detach")
        attach_row.addStretch(1)
        attach_row.addWidget(self.btn_attach)
        attach_row.addWidget(self.btn_detach)
        lv.addLayout(attach_row)

        lv.addWidget(QLabel("Attached to RUN"))
        self.lst_attached = QListWidget()
        self.lst_attached.setSelectionMode(QListWidget.MultiSelection)
        lv.addWidget(self.lst_attached, 1)

        # Middle: files in selected vector store
        middle = QWidget()
        rv = QVBoxLayout(middle)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.addWidget(QLabel("Files in selected store"))

        file_row = QHBoxLayout()
        self.ed_file_id = QLineEdit()
        self.ed_file_id.setPlaceholderText("file_id (from Files API)")
        self.btn_add_file = QPushButton("Add file")
        self.btn_add_from_files = QPushButton("Add z Files API")
        self.btn_list_files = QPushButton("List files")
        self.btn_remove_file = QPushButton("Remove selected")
        file_row.addWidget(self.ed_file_id, 1)
        file_row.addWidget(self.btn_add_file)
        file_row.addWidget(self.btn_add_from_files)
        file_row.addWidget(self.btn_list_files)
        file_row.addWidget(self.btn_remove_file)
        rv.addLayout(file_row)

        self.lst_files = QListWidget()
        rv.addWidget(self.lst_files, 1)

        # Right: details of selected file
        detail = QWidget()
        dv = QVBoxLayout(detail)
        dv.setContentsMargins(0, 0, 0, 0)
        dv.addWidget(QLabel("Detaily souboru"))

        self.lbl_detail = QLabel("—")
        dv.addWidget(self.lbl_detail)

        dv.addWidget(QLabel("Atributy ve Vector Store (JSON):"))
        self.ed_vs_attrs = QPlainTextEdit()
        self.ed_vs_attrs.setPlaceholderText('{"klic": "hodnota"}')
        dv.addWidget(self.ed_vs_attrs, 1)

        dv.addWidget(QLabel("Informace z Files API (jen čtení):"))
        self.ed_file_info = QPlainTextEdit()
        self.ed_file_info.setReadOnly(True)
        dv.addWidget(self.ed_file_info, 1)

        btn_detail = QHBoxLayout()
        self.btn_save_attrs = QPushButton("Uložit atributy")
        self.btn_refresh_detail = QPushButton("Obnovit detail")
        btn_detail.addWidget(self.btn_save_attrs)
        btn_detail.addWidget(self.btn_refresh_detail)
        dv.addLayout(btn_detail)

        split.addWidget(left)
        split.addWidget(middle)
        split.addWidget(detail)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 2)
        split.setStretchFactor(2, 2)

        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_create.clicked.connect(self.create_store)
        self.btn_upload_dir.clicked.connect(self.upload_directory)
        self.btn_delete.clicked.connect(self.delete_selected_store)
        self.btn_delete_all.clicked.connect(self.delete_all_stores)
        self.btn_list_files.clicked.connect(self.list_files)
        self.btn_add_file.clicked.connect(self.add_file)
        self.btn_add_from_files.clicked.connect(self.add_files_from_api)
        self.btn_remove_file.clicked.connect(self.remove_selected_file)
        self.btn_save_attrs.clicked.connect(self.save_selected_attrs)
        self.btn_refresh_detail.clicked.connect(self.show_selected_file_details)
        self.btn_attach.clicked.connect(self.attach_selected)
        self.btn_detach.clicked.connect(self.detach_selected)

        self.lst_vs.itemSelectionChanged.connect(self.list_files)
        self.lst_files.itemSelectionChanged.connect(self.show_selected_file_details)

        self.refresh()

        self._cur_files: Dict[str, Dict[str, Any]] = {}
        self._upload_worker: UploadDirectoryWorker | None = None
        self._scan_worker: DirectoryScanWorker | None = None
        self._upload_dialog: UploadProgressDialog | None = None
        self._pending_threads: list[QThread] = []

    def shutdown(self, timeout_ms: int = 3000) -> None:
        worker = self._delete_worker
        if worker and worker.isRunning():
            try:
                worker.requestInterruption()
            except Exception:
                pass
            if not worker.wait(timeout_ms):
                try:
                    worker.terminate()
                except Exception:
                    pass
                worker.wait(1000)
        try:
            if self._delete_dialog:
                self._delete_dialog.close()
        except Exception:
            pass
        self._delete_worker = None
        self._delete_dialog = None

    def _keep_thread(self, worker: QThread | None) -> None:
        if not worker:
            return
        if worker in self._pending_threads:
            return
        self._pending_threads.append(worker)
        worker.finished.connect(lambda *args, w=worker: self._forget_thread(w))

    def _forget_thread(self, worker: QThread | None) -> None:
        if not worker:
            return
        try:
            self._pending_threads.remove(worker)
        except ValueError:
            pass
        try:
            worker.deleteLater()
        except Exception:
            pass

    def _force_kill_worker(self, worker: QThread | None, reason: str) -> None:
        if not worker:
            return
        self._keep_thread(worker)
        try:
            if hasattr(worker, "request_stop"):
                worker.request_stop()
        except Exception:
            pass
        try:
            worker.requestInterruption()
        except Exception:
            pass
        try:
            worker.terminate()
        except Exception:
            pass
        def _check_done():
            try:
                if not worker.isRunning():
                    self._forget_thread(worker)
                else:
                    QTimer.singleShot(500, _check_done)
            except Exception:
                pass
        QTimer.singleShot(200, _check_done)
        self.logline.emit(f"Worker kill requested: {reason}")

    def _cancel_upload_flow(self, reason: str = "Zrušeno uživatelem") -> None:
        """
        Okamžitě ukončí běžící scan/upload pracovníka a uvolní dialog.
        Používá se pro Cancel/Storno i zavření křížkem.
        """
        dlg = self._upload_dialog
        if dlg:
            try:
                dlg.add_log(f"Zrušeno: {reason}")
                dlg.set_status("Ruším...")
                dlg.set_cancel_enabled(False)
            except Exception:
                pass
        self._force_kill_worker(self._scan_worker, "scan")
        self._force_kill_worker(self._upload_worker, "upload")
        self._scan_worker = None
        self._upload_worker = None
        if dlg:
            try:
                dlg.mark_done("Zrušeno.")
            except Exception:
                pass
            self._upload_dialog = None

    def _cancel_delete_flow(self, reason: str = "Zruseno uzivatelem") -> None:
        dlg = self._delete_dialog
        if dlg:
            try:
                dlg.add_log(f"Zruseno: {reason}")
                dlg.set_status("Rusim...")
                dlg.set_cancel_enabled(False)
            except Exception:
                pass
        self._force_kill_worker(self._delete_worker, "delete")
        self._delete_worker = None
        if dlg:
            try:
                dlg.mark_done("Zruseno.")
            except Exception:
                pass
            self._delete_dialog = None
        self._set_delete_controls_enabled(True)

    def set_api_key(self, api_key: str):
        self.api_key = api_key
        self.client = None
        self.refresh()

    def _need_client(self) -> bool:
        if not self.api_key:
            msg_warning(self, "OpenAI", "Nejdřív nastav OPENAI_API_KEY.")
            return False
        if self.client is None:
            self.client = OpenAIClient(self.api_key)
        return True

    def refresh(self):
        self.lst_vs.clear()
        self.lst_files.clear()
        self.lbl_detail.setText("—")
        self.ed_vs_attrs.setPlainText("")
        self.ed_file_info.setPlainText("")
        if not self._need_client():
            return
        with BusyPopup(self, "Načítám vector stores..."):
            try:
                data = with_retry(lambda: self.client.list_vector_stores(), self.s.retry, self.breaker)
                for vs in data:
                    vs_id = vs.get("id", "")
                    name = vs.get("name", "") or ""
                    created = vs.get("created_at")
                    created_s = ""
                    try:
                        if created:
                            created_s = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(created)))
                    except Exception:
                        created_s = str(created or "")
                    label = f"{vs_id}  |  {name}  |  {created_s}"
                    it = QListWidgetItem(label)
                    it.setData(32, vs_id)
                    self.lst_vs.addItem(it)
                self.logline.emit(f"Vector stores: {len(data)}")
                self._prune_attached()
            except Exception as e:
                msg_critical(self, "Vector stores", str(e))

    def _apply_vector_store_list(self, data: List[dict]) -> None:
        self.lst_vs.clear()
        self.lst_files.clear()
        self.lbl_detail.setText("—")
        self.ed_vs_attrs.setPlainText("")
        self.ed_file_info.setPlainText("")
        for vs in data or []:
            vs_id = vs.get("id", "")
            name = vs.get("name", "") or ""
            created = vs.get("created_at")
            created_s = ""
            try:
                if created:
                    created_s = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(created)))
            except Exception:
                created_s = str(created or "")
            label = f"{vs_id}  |  {name}  |  {created_s}"
            it = QListWidgetItem(label)
            it.setData(32, vs_id)
            self.lst_vs.addItem(it)
        self.logline.emit(f"Vector stores: {len(data or [])}")
        self._prune_attached()

    def _set_delete_controls_enabled(self, enabled: bool) -> None:
        self.btn_refresh.setEnabled(enabled)
        self.btn_create.setEnabled(enabled)
        self.btn_delete.setEnabled(enabled)
        self.btn_delete_all.setEnabled(enabled)
        self.btn_list_files.setEnabled(enabled)
        self.btn_add_file.setEnabled(enabled)
        self.btn_add_from_files.setEnabled(enabled)
        self.btn_remove_file.setEnabled(enabled)
        self.btn_save_attrs.setEnabled(enabled)
        self.btn_refresh_detail.setEnabled(enabled)
        self.btn_attach.setEnabled(enabled)
        self.btn_detach.setEnabled(enabled)

    def _start_delete_worker(self, store_ids: List[str], title: str) -> None:
        if self._delete_worker:
            msg_info(self, "Delete", "Mazání už běží.")
            return
        dialog = TaskProgressDialog(title, self, show_subprogress=True, allow_cancel=True)
        dialog.set_status(f"Připravuji mazání {len(store_ids)} store...")
        dialog.add_log(f"Počet store: {len(store_ids)}")
        worker = VectorStoresDeleteWorker(
            self.api_key,
            store_ids,
            self.s.retry,
            self.s.retry.circuit_breaker_failures,
            self.s.retry.circuit_breaker_cooldown_s,
        )
        self._delete_worker = worker
        self._delete_dialog = dialog
        self._set_delete_controls_enabled(False)
        self._keep_thread(worker)

        worker.progress.connect(dialog.set_progress)
        worker.subprogress.connect(dialog.set_subprogress)
        worker.status.connect(dialog.set_status)
        worker.logline.connect(dialog.add_log)

        dialog.set_cancel_handler(lambda: self._cancel_delete_flow("Mazani zruseno uzivatelem"))
        dialog.set_cancel_enabled(True)

        def on_done(stores: List[dict] | None, errors: List[str], deleted: int, total: int):
            dialog.mark_done(f"Mazání dokončeno ({deleted}/{total}).")
            if stores is not None:
                self._apply_vector_store_list(stores)
            if errors:
                msg_warning(self, "Delete", f"Smazáno: {deleted} / {total}\nChyby:\n" + "\n".join(errors[:6]))
            else:
                msg_info(self, "Delete", f"Smazáno {deleted} vector store.")
            self._delete_worker = None
            self._delete_dialog = None
            self._set_delete_controls_enabled(True)

        worker.finished.connect(on_done)
        dialog.show()
        worker.start()

    def _selected_vs_id(self) -> Optional[str]:
        sel = self.lst_vs.selectedItems()
        if not sel:
            return None
        # If multiple selected, use the first one for single actions.
        return sel[0].data(32)

    def create_store(self):
        if not self._need_client():
            return
        name, ok = dialog_input_text(self, "Create vector store", "Name")
        if not ok or not name.strip():
            return
        with BusyPopup(self, "Vytvářím vector store..."):
            try:
                vs = with_retry(lambda: self.client.create_vector_store(name.strip()), self.s.retry, self.breaker)
                self.logline.emit(f"Created vector store: {vs.get('id')} ({vs.get('name')})")
                self.refresh()
            except Exception as e:
                msg_critical(self, "Create", str(e))

    def delete_selected_store(self):
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        if not vs_id:
            return
        # Preload files so we can clean them up before deletion (API often rejects delete if files remain).
        files: List[Dict[str, Any]] = []
        try:
            files = with_retry(lambda: self.client.list_vector_store_files(vs_id), self.s.retry, self.breaker)
        except Exception as e:
            msg_critical(self, "Delete", f"Nelze načíst soubory ve store {vs_id}: {e}")
            return

        if msg_question(
            self,
            "Delete",
            f"Smazat vector store {vs_id} (soubory: {len(files)})?",
        ) != QMessageBox.Yes:
            return
        self._start_delete_worker([vs_id], "Mažu vector store...")

    def delete_all_stores(self):
        if not self._need_client():
            return
        count = self.lst_vs.count()
        if count == 0:
            msg_info(self, "Delete", "Nenalezeny žádné vector store.")
            return
        if msg_question(
            self,
            "Delete",
            f"Smazat všech {count} vector store včetně souborů?",
        ) != QMessageBox.Yes:
            return
        ids: List[str] = []
        for i in range(count):
            it = self.lst_vs.item(i)
            if it and it.data(32):
                ids.append(it.data(32))
        if ids:
            self._start_delete_worker(ids, "Mažu všechny vector stores...")

    def list_files(self):
        self.lst_files.clear()
        self._cur_files = {}
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        if not vs_id:
            return
        with BusyPopup(self, "Načítám soubory ve store..."):
            try:
                files = with_retry(lambda: self.client.list_vector_store_files(vs_id), self.s.retry, self.breaker)
                for f in files:
                    fid = f.get("id", "")
                    if fid:
                        self._cur_files[fid] = f
                    vs_file_id = f.get("id", "")
                    file_id = f.get("file_id", "")
                    status = f.get("status", "")
                    label = f"{vs_file_id}  |  file_id={file_id}  |  {status}"
                    it = QListWidgetItem(label)
                    it.setData(32, vs_file_id)
                    self.lst_files.addItem(it)
                self.logline.emit(f"Vector store {vs_id}: files={len(files)}")
                self.show_selected_file_details()
            except Exception as e:
                msg_critical(self, "List files", str(e))

    def add_file(self):
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        if not vs_id:
            msg_info(self, "Add file", "Nejdřív vyber vector store.")
            return
        file_id = (self.ed_file_id.text() or "").strip()
        if not file_id:
            msg_info(self, "Add file", "Zadej file_id.")
            return
        with BusyPopup(self, "Přidávám soubor..."):
            try:
                res = with_retry(lambda: self.client.add_file_to_vector_store(vs_id, file_id), self.s.retry, self.breaker)
                self.logline.emit(f"Added file to vector store: vs={vs_id} file_id={file_id} vs_file_id={res.get('id')}")
                self.list_files()
            except Exception as e:
                msg_critical(self, "Add file", str(e))

    def add_files_from_api(self):
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        if not vs_id:
            msg_info(self, "Add files", "Nejdřív vyber vector store.")
            return
        dlg = FilesSelectorDialog(self.client, self.s.retry, self.breaker, self)
        if dlg.exec() != QDialog.Accepted:
            return
        ids = dlg.selected_ids()
        if not ids:
            return
        with BusyPopup(self, "Přidávám soubory..."):
            ok_cnt = 0
            failures: List[str] = []
            for fid in ids:
                try:
                    res = with_retry(lambda f=fid: self.client.add_file_to_vector_store(vs_id, f), self.s.retry, self.breaker)
                    ok_cnt += 1
                    self.logline.emit(f"Added file to vector store: vs={vs_id} file_id={fid} vs_file_id={res.get('id')}")
                except Exception as e:
                    failures.append(f"{fid}: {e}")
            self.list_files()
            if failures:
                msg_warning(self, "Add files", f"Přidáno: {ok_cnt}/{len(ids)}\nChyby:\n" + "\n".join(failures[:5]))
            else:
                msg_info(self, "Add files", f"Přidáno {ok_cnt} souborů do {vs_id}.")

    def remove_selected_file(self):
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        if not vs_id:
            return
        sel = self.lst_files.selectedItems()
        if not sel:
            return
        vs_file_id = sel[0].data(32)
        if msg_question(self, "Remove file", f"Odstranit {vs_file_id} z vector store {vs_id}?") != QMessageBox.Yes:
            return
        with BusyPopup(self, "Odebírám soubor..."):
            try:
                with_retry(lambda: self.client.delete_vector_store_file(vs_id, vs_file_id), self.s.retry, self.breaker)
                self.logline.emit(f"Removed vector store file: {vs_file_id}")
                self.list_files()
            except Exception as e:
                msg_critical(self, "Remove file", str(e))

    # ---------- Attach / detach ----------
    def attach_selected(self):
        sel = self.lst_vs.selectedItems()
        for it in sel:
            vs_id = it.data(32)
            if not vs_id:
                continue
            if not any(self.lst_attached.item(i).data(32) == vs_id for i in range(self.lst_attached.count())):
                ni = QListWidgetItem(vs_id)
                ni.setData(32, vs_id)
                self.lst_attached.addItem(ni)
        self._emit_attached()

    def detach_selected(self):
        for it in self.lst_attached.selectedItems():
            row = self.lst_attached.row(it)
            self.lst_attached.takeItem(row)
        self._emit_attached()

    def attached_ids(self) -> List[str]:
        return [self.lst_attached.item(i).data(32) for i in range(self.lst_attached.count()) if self.lst_attached.item(i).data(32)]

    def set_attached(self, ids: List[str]):
        self.lst_attached.clear()
        for vid in ids or []:
            if not vid:
                continue
            it = QListWidgetItem(vid)
            it.setData(32, vid)
            self.lst_attached.addItem(it)
        self._emit_attached()

    def clear_attached(self):
        self.lst_attached.clear()
        self._emit_attached()

    def _prune_attached(self):
        valid = {self.lst_vs.item(i).data(32) for i in range(self.lst_vs.count())}
        changed = False
        for i in reversed(range(self.lst_attached.count())):
            vid = self.lst_attached.item(i).data(32)
            if vid not in valid:
                self.lst_attached.takeItem(i)
                changed = True
        if changed:
            self._emit_attached()

    def _emit_attached(self):
        self.attached_changed.emit(self.attached_ids())

    def _selected_vs_file_id(self) -> Optional[str]:
        sel = self.lst_files.selectedItems()
        if not sel:
            return None
        return sel[0].data(32)

    def show_selected_file_details(self):
        vs_file_id = self._selected_vs_file_id()
        if not vs_file_id:
            self.lbl_detail.setText("—")
            self.ed_vs_attrs.setPlainText("")
            self.ed_file_info.setPlainText("")
            return
        vs = self._cur_files.get(vs_file_id, {})
        file_id = vs.get("file_id", "")
        attrs = vs.get("attributes") or {}
        import json
        try:
            attrs_text = json.dumps(attrs, indent=2, ensure_ascii=False)
        except Exception:
            attrs_text = str(attrs)
        self.ed_vs_attrs.setPlainText(attrs_text)

        file_info = {}
        if file_id:
            with BusyPopup(self, "Načítám detail souboru..."):
                try:
                    # TODO: případně načíst detail souboru z Files API; placeholder kvůli stabilitě UI
                    file_info = {}
                except Exception as e:
                    self.logline.emit(f"Upload directory failed během detailu souboru: {e}")
                    msg_critical(self, "Upload", str(e))
                    file_info = {"error": str(e)}
        try:
            info_text = json.dumps(file_info, indent=2, ensure_ascii=False)
        except Exception:
            info_text = str(file_info)

        self.lbl_detail.setText(f"vs_file_id: {vs_file_id} | file_id: {file_id}")
        self.ed_file_info.setPlainText(info_text)

    def save_selected_attrs(self):
        if not self._need_client():
            return
        vs_id = self._selected_vs_id()
        vs_file_id = self._selected_vs_file_id()
        if not vs_id or not vs_file_id:
            return
        import json
        try:
            root = dialog_select_dir(self, "Vyber adresar k uploadu", os.getcwd())
            if not root:
                return
            root = os.path.abspath(root)
            deny_dirs = ["venv", ".venv", "__pycache__", ".git", ".github", "LOG", "cache", ".cache", "node_modules", ".idea", ".mypy_cache", ".pytest_cache"]
            deny_dir_contains = ["venv", "cache", "log", "android", "git"]
            deny_exts = [".pyc", ".pyo", ".exe", ".dll"]
            deny_globs = ["*.pyc", "*/.git/*", "*/__pycache__/*", "*/.github/*", "*/.cache/*", "*/LOG/*", "*/node_modules/*"]
            items = scan_tree(
                root,
                os.path.basename(root),
                deny_dirs=deny_dirs,
                deny_dir_contains=deny_dir_contains,
                deny_exts=deny_exts,
                allow_exts=sorted(self._allowed_upload_exts()),
                deny_globs=deny_globs,
                allow_globs=None,
                max_size_bytes=10 * 1024 * 1024,
            )
        except Exception as e:
            self.logline.emit(f"Upload directory failed during scan: {e}")
            msg_critical(self, "Upload", str(e))
            return

            msg_warning(self, "Atributy", f"Neplatný JSON: {e}")
            return
        try:
            with_retry(lambda: self.client.update_vector_store_file_attributes(vs_id, vs_file_id, new_attrs), self.s.retry, self.breaker)
            self.logline.emit(f"Atributy uloženy: {vs_file_id}")
            self.list_files()
        except Exception as e:
            msg_critical(self, "Atributy", str(e))

    # ---------- Upload directory ----------
    def _allowed_upload_exts(self) -> set[str]:
        # Pouzij kompatibilni pripony pro Files API / Vector Store / file_search.
        if ALLOWED_EXTS:
            return set(ALLOWED_EXTS)
        return {".txt", ".md", ".json", ".csv", ".yaml", ".yml"}

    def _select_vs(self, vs_id: str) -> None:
        if not vs_id:
            return
        for i in range(self.lst_vs.count()):
            it = self.lst_vs.item(i)
            if it and it.data(32) == vs_id:
                self.lst_vs.setCurrentItem(it)
                break

    def upload_directory(self):
        self.logline.emit("Upload directory invoked.")
        try:
            if not self._need_client():
                return
            if not self.api_key.strip():
                msg_critical(self, "Upload", "Chybí OPENAI_API_KEY – nastav jej v Nastavení.")
                self.logline.emit("Upload directory aborted: missing API key.")
                return
            if self._upload_worker or self._scan_worker:
                msg_warning(self, "Upload", "Upload už běží.")
                self.logline.emit("Upload directory aborted: worker already running.")
                return

            self.logline.emit("Opening directory picker...")
            root = dialog_select_dir(self, "Vyber adresář k uploadu", os.getcwd())
            if not root:
                self.logline.emit("Upload directory canceled by user (no directory).")
                return
            root = os.path.abspath(root)
            self.logline.emit(f"Selected root: {root}")

            deny_dirs = ["venv", ".venv", "__pycache__", ".git", ".github", "LOG", "cache", ".cache", "node_modules", ".idea", ".mypy_cache", ".pytest_cache"]
            deny_dir_contains = ["venv", "cache", "log", "android", "git"]
            deny_exts = [".pyc", ".pyo", ".exe", ".dll"]
            deny_globs = ["*.pyc", "*/.git/*", "*/__pycache__/*", "*/.github/*", "*/.cache/*", "*/LOG/*", "*/node_modules/*"]

            dlg = UploadProgressDialog("Upload directory", self)
            dlg.set_status("Skenuji adresar...")
            dlg.set_current(f"Root: {root}")
            dlg.add_log(f"Adresar: {root}")
            dlg.show()
            dlg.set_cancel_handler(lambda: self._cancel_upload_flow("Dialog ukončen uživatelem"))
            dlg.set_cancel_enabled(True)
            self._upload_dialog = dlg
            self.logline.emit("Upload directory started.")

            scan_worker = DirectoryScanWorker(
                root,
                os.path.basename(root),
                deny_dirs=deny_dirs,
                deny_dir_contains=deny_dir_contains,
                deny_exts=deny_exts,
                allow_exts=sorted(self._allowed_upload_exts()),
                deny_globs=deny_globs,
                allow_globs=None,
                max_size_bytes=10 * 1024 * 1024,
            )
            self._scan_worker = scan_worker
            self.logline.emit("Scan worker started.")
            self._keep_thread(scan_worker)

            scan_worker.status.connect(dlg.set_status)
            scan_worker.progress.connect(dlg.set_progress)
            scan_worker.logline.connect(dlg.add_log)

            def on_scan_done(items: list, err_msg: str):
                self._scan_worker = None
                if err_msg:
                    if "Canceled by user" in err_msg:
                        self.logline.emit("Upload directory scan canceled by user.")
                        self._cancel_upload_flow("Skenování zrušeno.")
                    else:
                        dlg.mark_done("Chyba při skenování.")
                        self.logline.emit(f"Upload directory failed during scan: {err_msg}")
                        msg_critical(self, "Upload", err_msg)
                    return

                uploadable = [it for it in items if it.uploadable]
                skipped = [it for it in items if not it.uploadable]
                dlg.add_log(f"Nalezeno souborů: {len(items)} | uploadovatelné: {len(uploadable)} | přeskočeno: {len(skipped)}")
                # shrnutí nejčastějších důvodů skipu (pro uživatele)
                if skipped:
                    from collections import Counter
                    top = Counter([it.reason for it in skipped]).most_common(3)
                    for reason, cnt in top:
                        dlg.add_log(f" - {reason}: {cnt}")
                for it in uploadable[:20]:
                    dlg.add_log(f" -> {it.rel_path} ({it.size} B)")
                if len(uploadable) > 20:
                    dlg.add_log(f"... další položky zkráceny ({len(uploadable)-20})")
                dlg.set_progress(0)
                dlg.set_status("Pripravuji upload...")

                if not uploadable:
                    dlg.mark_done("Nic k uploadu.")
                    msg_warning(self, "Upload", "Žádný vhodný soubor k uploadu.")
                    return

                name_default = f"{os.path.basename(root)}_{ts_code()}"
                vs_name, ok = dialog_input_text(self, "Create vector store", "Name", name_default)
                if not ok or not vs_name.strip():
                    dlg.mark_done("Zrušeno uživatelem.")
                    return

                worker = UploadDirectoryWorker(
                    self.api_key,
                    self.s.retry,
                    self.s.retry.circuit_breaker_failures,
                    self.s.retry.circuit_breaker_cooldown_s,
                    uploadable,
                    root,
                    vs_name.strip(),
                )
                self._upload_worker = worker
                self._keep_thread(worker)

                # Cancel/Storno/close: zabije celý proces (scan/upload)
                if self._upload_dialog:
                    self._upload_dialog.set_cancel_handler(lambda: self._cancel_upload_flow("Upload zrušen uživatelem"))
                    self._upload_dialog.set_cancel_enabled(True)

                worker.status.connect(dlg.set_status)
                worker.status.connect(dlg.set_current)
                worker.progress.connect(dlg.set_progress)
                worker.logline.connect(dlg.add_log)

                def on_done(vs_id: str, errors: list, uploaded: int, added: int, total: int, vs_file_ids: list[str], err_msg: str):
                    try:
                        if err_msg:
                            if "Canceled by user" in err_msg:
                                self.logline.emit("Upload directory canceled by user.")
                                try:
                                    dlg.mark_done("Zrušeno.")
                                except Exception:
                                    pass
                                return
                            dlg.mark_done("Chyba.")
                            self.logline.emit(f"Upload directory error: {err_msg}")
                            msg_critical(self, "Upload", err_msg)
                        else:
                            msg_parts = [f"Nahrano {uploaded}/{total} souboru", f"Pridano do store: {added}/{total}"]
                            if errors:
                                dlg.mark_done("Hotovo s chybami.")
                                self.logline.emit("Upload directory finished with errors.")
                                msg_warning(self, "Upload", "\n".join(msg_parts + ["Chyby:"] + [str(e) for e in errors][:5]))
                            else:
                                dlg.mark_done("Hotovo.")
                                self.logline.emit("Upload directory finished OK.")
                                msg_info(self, "Upload", "\n".join(msg_parts))
                            try:
                                self.refresh()
                                self._select_vs(vs_id)
                            except Exception:
                                pass
                    except Exception as e:
                        self.logline.emit(f"Upload directory finalize failed: {e}")
                        msg_critical(self, "Upload", str(e))
                    self._upload_worker = None
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    self._upload_dialog = None

                worker.done.connect(on_done)
                worker.start()

            scan_worker.done.connect(on_scan_done)
            scan_worker.start()
        except Exception as e:
            self.logline.emit(f"Upload directory failed: {e}")
            msg_critical(self, "Upload", str(e))
