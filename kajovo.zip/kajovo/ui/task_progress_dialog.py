from __future__ import annotations

from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit, QProgressBar
from PySide6.QtCore import Qt

from .theme import DARK_STYLESHEET
from .widgets import style_progress_bar, TitleBar, app_icon


class TaskProgressDialog(QDialog):
    def __init__(self, title: str, parent=None, *, show_subprogress: bool = True, allow_cancel: bool = False):
        super().__init__(parent)
        self._done = False
        self._allow_cancel = allow_cancel
        self._cancel_handler = None
        self._cancelled = False

        self.setWindowTitle(f"Kájovo NG — {title}")
        self.setWindowIcon(app_icon())
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setModal(True)
        self.resize(640, 360)
        self.setStyleSheet(DARK_STYLESHEET)

        v = QVBoxLayout(self)
        v.setContentsMargins(12, 12, 12, 12)
        v.setSpacing(10)

        self.titlebar = TitleBar(title, self)
        self.titlebar.request_close.connect(self.reject)
        v.addWidget(self.titlebar)

        self.lbl_title = QLabel(title)
        self.lbl_title.setStyleSheet("font-weight: 600;")
        self.lbl_title.hide()

        self.lbl_status = QLabel("...")
        self.lbl_status.setWordWrap(True)
        v.addWidget(self.lbl_status)

        self.pb = QProgressBar()
        style_progress_bar(self.pb)
        v.addWidget(self.pb)

        self.pb_sub = QProgressBar()
        style_progress_bar(self.pb_sub)
        v.addWidget(self.pb_sub)
        if not show_subprogress:
            self.pb_sub.hide()

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        v.addWidget(self.log, 1)

        row = QHBoxLayout()
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self._handle_cancel)
        self.btn_close = QPushButton("Close")
        self.btn_close.setEnabled(False)
        self.btn_close.clicked.connect(self.accept)
        row.addStretch(1)
        if self._allow_cancel:
            row.addWidget(self.btn_cancel)
        row.addWidget(self.btn_close)
        v.addLayout(row)

    def set_status(self, text: str):
        self.lbl_status.setText(text)

    def set_progress(self, value: int):
        self.pb.setValue(value)

    def set_subprogress(self, value: int):
        if self.pb_sub.isHidden():
            return
        self.pb_sub.setValue(value)

    def add_log(self, line: str):
        self.log.appendPlainText(line)

    def set_cancel_handler(self, fn):
        self._cancel_handler = fn

    def set_cancel_enabled(self, enabled: bool):
        if self._allow_cancel:
            self.btn_cancel.setEnabled(enabled)

    def mark_done(self, status: str = "Hotovo."):
        self._done = True
        if self._allow_cancel:
            self.btn_cancel.setEnabled(False)
        self.btn_close.setEnabled(True)
        self.set_status(status)

    def _handle_cancel(self):
        if not self._allow_cancel or self._cancelled:
            return
        self._cancelled = True
        if self._cancel_handler:
            try:
                self._cancel_handler()
            except Exception:
                pass
        self._done = True
        self.btn_close.setEnabled(True)
        self.btn_cancel.setEnabled(False)
        self.set_status("Rusim...")

    def closeEvent(self, event):
        if not self._done:
            if self._allow_cancel:
                self._handle_cancel()
            event.ignore()
            return
        super().closeEvent(event)

    def reject(self):
        if not self._done and self._allow_cancel:
            self._handle_cancel()
        super().reject()
