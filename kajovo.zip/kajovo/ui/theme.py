from __future__ import annotations

# Brand palette derived from the new Kájovo NG logo (Kajovo_new.png)
# teal:    #3DB8C0
# purple:  #8D79C4
# lilac:   #B69FDD
# coral:   #E04050
# gold:    #FDD380
# ink:     #0F111A
# slate:   #141826
# text:    #D6DDE7

DARK_STYLESHEET = """/* Base */
QWidget {
  background: #0F111A;
  color: #D6DDE7;
  font-family: Montserrat, Segoe UI, Arial;
  font-size: 10pt;
}

/* Text selection */
QLineEdit, QTextEdit, QPlainTextEdit {
  selection-background-color: #8D79C4;
  selection-color: #0F111A;
}

/* Inputs */
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QListWidget, QTableWidget, QSpinBox, QDoubleSpinBox {
  background: #141826;
  border: 1px solid #252B3D;
  border-radius: 10px;
  padding: 7px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QListWidget:focus, QTableWidget:focus, QSpinBox:focus, QDoubleSpinBox:focus {
  border: 1px solid #3DB8C0;
}
QComboBox::drop-down { border: 0px; width: 24px; }
QComboBox QAbstractItemView { background: #141826; selection-background-color: #3DB8C0; selection-color: #0F111A; border: 1px solid #252B3D; }

/* Buttons */
QPushButton {
  background: #141826;
  border: 1px solid #2A3147;
  border-radius: 10px;
  padding: 8px 12px;
}
QPushButton:hover {
  border-color: #3DB8C0;
}
QPushButton:pressed {
  background: #101423;
}

QPushButton#PrimaryButton {
  background: #3DB8C0;
  border: 1px solid #3DB8C0;
  color: #0F111A;
  font-weight: 700;
}
QPushButton#PrimaryButton:hover { background: #43C5CE; }

QPushButton#SecondaryButton {
  background: #8D79C4;
  border: 1px solid #8D79C4;
  color: #0F111A;
  font-weight: 700;
}
QPushButton#SecondaryButton:hover { background: #9A86D2; }

/* Group / tabs */
QGroupBox {
  border: 1px solid #252B3D;
  border-radius: 12px;
  margin-top: 10px;
}
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 8px 0 8px; color: #B69FDD; }

QTabWidget::pane { border: 1px solid #252B3D; border-radius: 12px; top: -1px; }
QTabBar::tab {
  background: #141826;
  padding: 9px 16px;
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
  margin-right: 6px;
  border: 1px solid #252B3D;
}
QTabBar::tab:selected {
  background: #101423;
  border: 1px solid #8D79C4;
}
QTabBar::tab:hover { border: 1px solid #3DB8C0; }

/* Tables */
QHeaderView::section {
  background: #101423;
  color: #D6DDE7;
  padding: 7px;
  border: 1px solid #252B3D;
}
QTableWidget::item:selected { background: #8D79C4; color: #0F111A; }

/* Lists */
QListWidget::item { padding: 6px; border-radius: 8px; }
QListWidget::item:selected { background: #3DB8C0; color: #0F111A; }

/* Progress */
QProgressBar {
  border: 1px solid #252B3D;
  border-radius: 9px;
  background: #141826;
  height: 16px;
}
QProgressBar::chunk {
  background: #3DB8C0;
  border-radius: 9px;
}

/* Checkbox */
QCheckBox::indicator {
  width: 16px;
  height: 16px;
  border-radius: 4px;
  border: 1px solid #3DB8C0;
  background: #141826;
}
QCheckBox::indicator:checked {
  border: 1px solid #3DB8C0;
  background: #3DB8C0;
}
QCheckBox::indicator:unchecked:hover { border: 1px solid #B69FDD; }
QCheckBox::indicator:checked:hover { border: 1px solid #B69FDD; background: #B69FDD; }

/* Scrollbars */
QScrollBar:vertical {
  background: #0F111A;
  width: 12px;
  margin: 0px;
}
QScrollBar::handle:vertical {
  background: #252B3D;
  border-radius: 6px;
  min-height: 24px;
}
QScrollBar::handle:vertical:hover { background: #3DB8C0; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }

QScrollBar:horizontal {
  background: #0F111A;
  height: 12px;
  margin: 0px;
}
QScrollBar::handle:horizontal {
  background: #252B3D;
  border-radius: 6px;
  min-width: 24px;
}
QScrollBar::handle:horizontal:hover { background: #3DB8C0; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }

/* Tooltips */
QToolTip {
  background: #101423;
  color: #D6DDE7;
  border: 1px solid #8D79C4;
  padding: 6px;
  border-radius: 8px;
}

/* Title bar */
QWidget#TitleBar {
  background: #101423;
  border: 1px solid #252B3D;
  border-radius: 12px;
}
QLabel#TitleLogo { background: transparent; }
QLabel#TitleLabel { color: #D6DDE7; font-weight: 700; }
QLabel#TitleSubtle { color: #B69FDD; }

QPushButton#TitleBtn {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 10px;
  padding: 4px 10px;
}
QPushButton#TitleBtn:hover {
  background: rgba(61, 184, 192, 28);
  border: 1px solid #3DB8C0;
}
QPushButton#TitleBtn:pressed { background: rgba(61, 184, 192, 18); }

QPushButton#TitleBtnClose:hover {
  background: #FDD380;
  border: 1px solid #FDD380;
  color: #0F111A;
}
"""
