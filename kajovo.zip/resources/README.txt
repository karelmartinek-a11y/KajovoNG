Place montserrat_regular.ttf and montserrat_bold.ttf here.
You can run scripts/fetch_fonts.ps1 to download from Google Fonts.
